export const BRAND = {
  purple: '#7047EB',
  turquoise: '#20C9B0',
  gold: '#FFC857',
  bg: '#F6F7FB',
  white: '#FFFFFF',
  navy: '#20243A',
  table: '#176B50',
  red: '#E5484D',
};
export interface Palette {
  bg: string; card: string; text: string; sub: string; border: string; primary: string; accent: string; gold: string;
  overlay: string; danger: string; gradient: [string, string]; dark: boolean;
}
export const light: Palette = {
  bg: BRAND.bg, card: '#FFFFFF', text: BRAND.navy, sub: '#6B7090', border: '#E6E8F2', primary: BRAND.purple,
  accent: BRAND.turquoise, gold: BRAND.gold, overlay: 'rgba(32,36,58,0.55)', danger: BRAND.red,
  gradient: [BRAND.purple, BRAND.turquoise], dark: false,
};
export const dark: Palette = {
  bg: '#14172B', card: '#1F2340', text: '#F2F3FA', sub: '#A3A8C8', border: '#2E3358', primary: '#8A67FF',
  accent: BRAND.turquoise, gold: BRAND.gold, overlay: 'rgba(0,0,0,0.65)', danger: '#FF6B70',
  gradient: ['#5B38D6', '#1AA793'], dark: true,
};
