import { useColorScheme } from 'react-native';
import { useApp } from '../store/useApp';
import { dark, light, Palette } from './colors';

export function useTheme(): Palette {
  const sys = useColorScheme();
  const pref = useApp((s) => s.settings.dark);
  const isDark = pref === null ? sys === 'dark' : pref;
  return isDark ? dark : light;
}
