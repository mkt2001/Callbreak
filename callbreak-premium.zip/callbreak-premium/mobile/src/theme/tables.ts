/** Table themes are full-screen background textures (assets/tables). */
export const TABLE_IMG: Record<string, any> = {
  table_wood: require('../../assets/tables/wood_orange.jpg'),
  table_green: require('../../assets/tables/felt_green.jpg'),
  table_walnut: require('../../assets/tables/wood_walnut.jpg'),
  table_blue: require('../../assets/tables/felt_blue.jpg'),
  table_purple: require('../../assets/tables/felt_purple.jpg'),
  table_ruby: require('../../assets/tables/felt_ruby.jpg'),
  table_neon: require('../../assets/tables/neon_grid.jpg'),
  table_ocean: require('../../assets/tables/ocean.jpg'),
  table_royal: require('../../assets/tables/royal.jpg'),
  table_luxe: require('../../assets/tables/luxe.jpg'),
};
export const tableImg = (id: string) => TABLE_IMG[id] ?? TABLE_IMG.table_wood;
