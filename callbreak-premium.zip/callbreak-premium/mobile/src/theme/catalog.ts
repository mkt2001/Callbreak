export type Kind = 'cardTheme' | 'cardBack' | 'table' | 'avatar' | 'frame' | 'badge' | 'sound';
export type Tier = 'common' | 'rare' | 'epic' | 'legendary';
export interface Item {
  id: string; kind: Kind; name: string; price: number; colors?: string[]; emoji?: string; animated?: boolean;
  tier?: Tier; vip?: boolean; emblem?: string;
}

export const TIER_COLOR: Record<Tier, string> = { common: '#8E93B5', rare: '#3B82F6', epic: '#A855F7', legendary: '#FFB020' };

export const CATALOG: Item[] = [
  // ---------- card faces ----------
  { id: 'classic', kind: 'cardTheme', name: 'Classic', price: 0, tier: 'common' },
  { id: 'retro', kind: 'cardTheme', name: 'Retro Paper', price: 600, tier: 'common' },
  { id: 'royal', kind: 'cardTheme', name: 'Royal Gold', price: 800, tier: 'rare' },
  { id: 'neon', kind: 'cardTheme', name: 'Neon Night', price: 1200, tier: 'rare' },
  { id: 'diamond', kind: 'cardTheme', name: 'Ice Diamond', price: 1500, tier: 'rare' },
  { id: 'rose', kind: 'cardTheme', name: 'Rose Gold', price: 1800, tier: 'rare' },
  { id: 'emerald', kind: 'cardTheme', name: 'Emerald', price: 2200, tier: 'epic' },
  { id: 'ruby', kind: 'cardTheme', name: 'Ruby', price: 2200, tier: 'epic' },
  { id: 'sakura', kind: 'cardTheme', name: 'Sakura', price: 2500, tier: 'epic' },
  { id: 'obsidian', kind: 'cardTheme', name: 'Obsidian Black', price: 3000, tier: 'epic' },
  { id: 'galaxy', kind: 'cardTheme', name: 'Galaxy', price: 4000, tier: 'legendary' },
  { id: 'aurum', kind: 'cardTheme', name: '24K Aurum', price: 6000, tier: 'legendary', vip: true },
  // ---------- card backs ----------
  { id: 'back_ruby', kind: 'cardBack', name: 'Ruby Classic', price: 0, tier: 'common', colors: ['#D9304F', '#8E1230'], emblem: '♦' },
  { id: 'back_purple', kind: 'cardBack', name: 'Violet Wave', price: 0, tier: 'common', colors: ['#7047EB', '#20C9B0'], emblem: '♠' },
  { id: 'back_navy', kind: 'cardBack', name: 'Midnight', price: 500, tier: 'common', colors: ['#20243A', '#4B5190'], emblem: '✦' },
  { id: 'back_gold', kind: 'cardBack', name: 'Golden Sun', price: 500, tier: 'common', colors: ['#FFC857', '#E08A1E'], emblem: '☀' },
  { id: 'back_crimson', kind: 'cardBack', name: 'Crimson', price: 700, tier: 'rare', colors: ['#C2185B', '#FF7043'], emblem: '♥' },
  { id: 'back_emerald', kind: 'cardBack', name: 'Emerald', price: 900, tier: 'rare', colors: ['#0F9D74', '#7BE0B5'], emblem: '♣' },
  { id: 'back_ocean', kind: 'cardBack', name: 'Deep Ocean', price: 1000, tier: 'rare', colors: ['#0B6B8A', '#1AA7C9'], emblem: '≈' },
  { id: 'back_sakura', kind: 'cardBack', name: 'Sakura', price: 1200, tier: 'rare', colors: ['#FF8FB1', '#FFD1DC'], emblem: '✿' },
  { id: 'back_carbon', kind: 'cardBack', name: 'Carbon', price: 1500, tier: 'epic', colors: ['#111318', '#3A3F4B'], emblem: '❖' },
  { id: 'back_neon', kind: 'cardBack', name: 'Neon Pulse', price: 1800, tier: 'epic', colors: ['#12123A', '#20C9B0'], emblem: '⚡' },
  { id: 'back_royal', kind: 'cardBack', name: 'Royal Crown', price: 2500, tier: 'epic', colors: ['#4B2BB0', '#FFC857'], emblem: '♛' },
  { id: 'back_galaxy', kind: 'cardBack', name: 'Galaxy', price: 3000, tier: 'legendary', colors: ['#1B0B4B', '#C026D3'], emblem: '✺' },
  { id: 'back_obsidian', kind: 'cardBack', name: 'Obsidian Gold', price: 4000, tier: 'legendary', colors: ['#0A0A0D', '#B8892B'], emblem: '♚', vip: true },
  { id: 'back_aurum', kind: 'cardBack', name: '24K Aurum', price: 6000, tier: 'legendary', colors: ['#FFE08A', '#C58A12'], emblem: '♔', vip: true },
  // ---------- tables (full-screen backgrounds) ----------
  { id: 'table_wood', kind: 'table', name: 'Classic Wood', price: 0, tier: 'common' },
  { id: 'table_green', kind: 'table', name: 'Green Felt', price: 0, tier: 'common' },
  { id: 'table_walnut', kind: 'table', name: 'Dark Walnut', price: 500, tier: 'common' },
  { id: 'table_blue', kind: 'table', name: 'Blue Velvet', price: 700, tier: 'rare' },
  { id: 'table_purple', kind: 'table', name: 'Royal Velvet', price: 900, tier: 'rare' },
  { id: 'table_ruby', kind: 'table', name: 'Ruby Velvet', price: 900, tier: 'rare' },
  { id: 'table_neon', kind: 'table', name: 'Neon Grid', price: 1500, tier: 'epic' },
  { id: 'table_ocean', kind: 'table', name: 'Ocean Waves', price: 1500, tier: 'epic' },
  { id: 'table_royal', kind: 'table', name: 'Royal Lattice', price: 3000, tier: 'legendary' },
  { id: 'table_luxe', kind: 'table', name: 'Black & Gold Luxe', price: 5000, tier: 'legendary', vip: true },
  // ---------- avatars / frames / badges / sounds ----------
  { id: 'av_cool', kind: 'avatar', name: 'Cool', price: 0, emoji: '😎' },
  { id: 'av_lion', kind: 'avatar', name: 'Lion', price: 0, emoji: '🦁' },
  { id: 'av_fox', kind: 'avatar', name: 'Fox', price: 0, emoji: '🦊' },
  { id: 'av_panda', kind: 'avatar', name: 'Panda', price: 0, emoji: '🐼' },
  { id: 'av_unicorn', kind: 'avatar', name: 'Unicorn', price: 1200, emoji: '🦄', animated: true },
  { id: 'av_dragon', kind: 'avatar', name: 'Dragon', price: 1500, emoji: '🐲', animated: true },
  { id: 'av_crown', kind: 'avatar', name: 'Royal', price: 2000, emoji: '👑', animated: true },
  { id: 'av_rocket', kind: 'avatar', name: 'Rocket', price: 1000, emoji: '🚀', animated: true },
  { id: 'frame_none', kind: 'frame', name: 'No frame', price: 0, colors: ['transparent'] },
  { id: 'frame_gold', kind: 'frame', name: 'Gold ring', price: 900, colors: ['#FFC857'] },
  { id: 'frame_neon', kind: 'frame', name: 'Neon ring', price: 1100, colors: ['#20C9B0'] },
  { id: 'frame_royal', kind: 'frame', name: 'Royal ring', price: 1500, colors: ['#7047EB'] },
  { id: 'badge_star', kind: 'badge', name: 'Star', price: 400, emoji: '⭐' },
  { id: 'badge_fire', kind: 'badge', name: 'On Fire', price: 600, emoji: '🔥' },
  { id: 'badge_crown', kind: 'badge', name: 'Crown', price: 900, emoji: '👑' },
  { id: 'snd_classic', kind: 'sound', name: 'Classic snap', price: 0 },
  { id: 'snd_soft', kind: 'sound', name: 'Soft felt', price: 600 },
  { id: 'snd_crisp', kind: 'sound', name: 'Crisp snap', price: 600 },
];
export const byId = (id: string) => CATALOG.find((i) => i.id === id)!;
export const VIP_PRICE = 5000;

export interface FaceStyle { bg: string; grad?: [string, string]; border: string; red: string; black: string; glow?: string }
export const FACE_STYLES: Record<string, FaceStyle> = {
  classic: { bg: '#FFFFFF', border: '#D9DCEA', red: '#D7263D', black: '#20243A' },
  retro: { bg: '#F3E9D2', border: '#BFA77A', red: '#B5452F', black: '#2F3B40' },
  royal: { bg: '#FFF8E6', border: '#E0B04A', red: '#B3261E', black: '#3B2A0A' },
  neon: { bg: '#161A33', border: '#20C9B0', red: '#FF5D8F', black: '#7BF1E0', glow: '#20C9B0' },
  diamond: { bg: '#F2FAFF', grad: ['#FFFFFF', '#CFE8FF'], border: '#7CC4FF', red: '#E11D48', black: '#0B3A66' },
  rose: { bg: '#FFF1EE', grad: ['#FFF7F3', '#F7C9BD'], border: '#D99484', red: '#C2410C', black: '#5B2A20' },
  emerald: { bg: '#EAFBF3', grad: ['#F3FFF9', '#BDEBD3'], border: '#1AA06E', red: '#B91C1C', black: '#064E3B' },
  ruby: { bg: '#FFF0F2', grad: ['#FFF8F9', '#F7B8C2'], border: '#D9304F', red: '#B80F2E', black: '#4A0A18' },
  sakura: { bg: '#FFF4F8', grad: ['#FFFFFF', '#FFD6E6'], border: '#F28BB0', red: '#D6336C', black: '#5B2A45' },
  obsidian: { bg: '#15161B', grad: ['#23252E', '#0C0D10'], border: '#C9A24A', red: '#FF6B81', black: '#F5D98B', glow: '#C9A24A' },
  galaxy: { bg: '#1A1040', grad: ['#2B1766', '#0E0A2A'], border: '#C084FC', red: '#FF7AC6', black: '#9AE6FF', glow: '#C084FC' },
  aurum: { bg: '#FFF0B8', grad: ['#FFF6CC', '#F3C969'], border: '#B8860B', red: '#9A1B1B', black: '#4A3200', glow: '#FFC857' },
};
