export type Kind = 'cardTheme' | 'cardBack' | 'table' | 'avatar' | 'frame' | 'badge' | 'sound';
export interface Item { id: string; kind: Kind; name: string; price: number; colors?: string[]; emoji?: string; animated?: boolean }

export const CATALOG: Item[] = [
  { id: 'classic', kind: 'cardTheme', name: 'Classic', price: 0 },
  { id: 'royal', kind: 'cardTheme', name: 'Royal Gold', price: 800 },
  { id: 'neon', kind: 'cardTheme', name: 'Neon Night', price: 1200 },
  { id: 'retro', kind: 'cardTheme', name: 'Retro Paper', price: 600 },
  { id: 'back_purple', kind: 'cardBack', name: 'Violet Wave', price: 0, colors: ['#7047EB', '#20C9B0'] },
  { id: 'back_gold', kind: 'cardBack', name: 'Golden Sun', price: 500, colors: ['#FFC857', '#E08A1E'] },
  { id: 'back_navy', kind: 'cardBack', name: 'Midnight', price: 500, colors: ['#20243A', '#4B5190'] },
  { id: 'back_crimson', kind: 'cardBack', name: 'Crimson', price: 700, colors: ['#C2185B', '#FF7043'] },
  { id: 'back_emerald', kind: 'cardBack', name: 'Emerald', price: 900, colors: ['#0F9D74', '#7BE0B5'] },
  { id: 'table_green', kind: 'table', name: 'Classic Green', price: 0, colors: ['#1E8F6A', '#176B50'] },
  { id: 'table_purple', kind: 'table', name: 'Royal Purple', price: 700, colors: ['#8A67FF', '#5B38D6'] },
  { id: 'table_navy', kind: 'table', name: 'Deep Navy', price: 700, colors: ['#2E3A7A', '#20243A'] },
  { id: 'table_crimson', kind: 'table', name: 'Ruby Lounge', price: 900, colors: ['#B3304F', '#7A1B33'] },
  { id: 'table_ocean', kind: 'table', name: 'Ocean', price: 1100, colors: ['#1AA7C9', '#0B6B8A'] },
  { id: 'av_cool', kind: 'avatar', name: 'Cool', price: 0, emoji: '😎' },
  { id: 'av_lion', kind: 'avatar', name: 'Lion', price: 0, emoji: '🦁' },
  { id: 'av_fox', kind: 'avatar', name: 'Fox', price: 0, emoji: '🦊' },
  { id: 'av_panda', kind: 'avatar', name: 'Panda', price: 0, emoji: '🐼' },
  { id: 'av_unicorn', kind: 'avatar', name: 'Unicorn', price: 1200, emoji: '🦄', animated: true },
  { id: 'av_dragon', kind: 'avatar', name: 'Dragon', price: 1500, emoji: '🐲', animated: true },
  { id: 'av_crown', kind: 'avatar', name: 'Royal', price: 2000, emoji: '👑', animated: true },
  { id: 'av_rocket', kind: 'avatar', name: 'Rocket', price: 1000, emoji: '🚀', animated: true },
  { id: 'frame_none', kind: 'frame', name: 'No frame', price: 0, colors: ['transparent'] },
  { id: 'frame_gold', kind: 'frame', name: 'Gold ring', price: 900, colors: ['#FFC857'] },
  { id: 'frame_neon', kind: 'frame', name: 'Neon ring', price: 1100, colors: ['#20C9B0'] },
  { id: 'frame_royal', kind: 'frame', name: 'Royal ring', price: 1500, colors: ['#7047EB'] },
  { id: 'badge_star', kind: 'badge', name: 'Star', price: 400, emoji: '⭐' },
  { id: 'badge_fire', kind: 'badge', name: 'On Fire', price: 600, emoji: '🔥' },
  { id: 'badge_crown', kind: 'badge', name: 'Crown', price: 900, emoji: '👑' },
  { id: 'snd_classic', kind: 'sound', name: 'Classic snap', price: 0 },
  { id: 'snd_soft', kind: 'sound', name: 'Soft felt', price: 600 },
  { id: 'snd_crisp', kind: 'sound', name: 'Crisp snap', price: 600 },
];
export const byId = (id: string) => CATALOG.find((i) => i.id === id)!;
export const VIP_PRICE = 5000;

export const FACE_STYLES: Record<string, { bg: string; border: string; red: string; black: string }> = {
  classic: { bg: '#FFFFFF', border: '#D9DCEA', red: '#D7263D', black: '#20243A' },
  royal: { bg: '#FFF8E6', border: '#E0B04A', red: '#B3261E', black: '#3B2A0A' },
  neon: { bg: '#161A33', border: '#20C9B0', red: '#FF5D8F', black: '#7BF1E0' },
  retro: { bg: '#F3E9D2', border: '#BFA77A', red: '#B5452F', black: '#2F3B40' },
};
