import { useCallback, useEffect, useRef, useState } from 'react';
import type { GameView } from '../shared/types';
import { connectSocket, currentSocket } from '../services/api';
import { sfx } from '../services/sound';
import type { GameController } from './types';

export interface OnlineEnd { totals: number[]; tricks: number; myBids: number[]; names: string[] }

/** Server-authoritative game: the client only renders the per-seat view and sends intents. */
export function useOnlineGame(onMatchEnd: (r: OnlineEnd) => void, onLeft: () => void): GameController {
  const [view, setView] = useState<GameView | null>(null);
  const [connected, setConnected] = useState(true);
  const bids = useRef<number[]>([]);
  const lastRound = useRef(0);
  const ended = useRef(false);

  useEffect(() => {
    let alive = true;
    let sock = currentSocket();
    const attach = (s: NonNullable<typeof sock>) => {
      const onState = (v: GameView) => {
        if (!alive) return;
        if (v.round !== lastRound.current) lastRound.current = v.round;
        setView(v);
        if (v.phase === 'matchEnd' && !ended.current) {
          ended.current = true;
          onMatchEnd({ totals: v.totals, tricks: v.players[v.mySeat].tricksWon, myBids: bids.current.slice(), names: v.players.map((p) => p.name) });
        }
      };
      const onDisc = () => setConnected(false);
      const onConn = () => { setConnected(true); s.emit('sync'); };
      const onGone = () => onLeft();
      s.on('state', onState); s.on('disconnect', onDisc); s.on('connect', onConn); s.on('game:abandoned', onGone);
      s.emit('sync');
      return () => { s.off('state', onState); s.off('disconnect', onDisc); s.off('connect', onConn); s.off('game:abandoned', onGone); };
    };
    let detach: (() => void) | undefined;
    if (sock) detach = attach(sock);
    else connectSocket().then((s) => { if (alive) detach = attach(s); }).catch(() => onLeft());
    return () => { alive = false; detach?.(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const bid = useCallback((v: number) => { bids.current.push(v); sfx('click'); currentSocket()?.emit('bid', { value: v }); }, []);
  const play = useCallback((id: string) => { sfx('play'); currentSocket()?.emit('play', { cardId: id }); }, []);
  const nextRound = useCallback(() => {}, []);
  return { view, bid, play, nextRound, hintCard: null, hintBid: null, connected, myBids: () => bids.current };
}
