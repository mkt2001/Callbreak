import type { GameView } from '../shared/types';
export interface GameController {
  view: GameView | null;
  bid: (v: number) => void;
  play: (cardId: string) => void;
  nextRound: () => void;
  hintCard: string | null;
  hintBid: number | null;
  connected: boolean;
  myBids: () => number[];
}
export interface GameParams {
  mode: 'quick' | 'practice' | 'private' | 'tournament' | 'online';
  online?: boolean;
  level?: 'beginner' | 'intermediate' | 'expert';
  hints?: boolean;
  variant?: 'normal' | 'super8' | 'blind';
  rounds?: 3 | 5;
}
