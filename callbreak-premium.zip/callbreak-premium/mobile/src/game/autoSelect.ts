import type { GameView } from '../shared/types';
import { TRUMP } from '../shared/constants';

/**
 * Suggests which card to pre-select when someone else has already led.
 * - can follow suit: smallest card that beats the current winner (if one is needed/possible), else the smallest card of the suit
 * - void in led suit: smallest spade (trump) that wins; if no trump can win, the smallest non-trump card
 * - leading yourself: returns null (you choose manually)
 */
export function autoSelectCard(view: GameView): string | null {
  if (view.phase !== 'playing' || view.trickDone || view.turn !== view.mySeat || view.trick.length === 0) return null;
  const legal = view.hand.filter((c) => view.legal.includes(c.id));
  if (!legal.length) return null;
  const lead = view.trick[0].card.suit;
  // current winning card
  let win = view.trick[0].card;
  for (const p of view.trick.slice(1)) {
    const c = p.card;
    if (c.suit === win.suit ? c.rank > win.rank : c.suit === TRUMP) win = c;
  }
  const beats = (c: { suit: string; rank: number }) => (c.suit === win.suit ? c.rank > win.rank : c.suit === TRUMP && win.suit !== TRUMP);
  const lowest = <T extends { rank: number }>(a: T[]) => a.slice().sort((x, y) => x.rank - y.rank)[0];

  const follow = legal.filter((c) => c.suit === lead);
  if (follow.length) {
    const winners = follow.filter(beats);
    return (winners.length ? lowest(winners) : lowest(follow)).id;
  }
  const trumps = legal.filter((c) => c.suit === TRUMP);
  if (trumps.length) {
    const winners = trumps.filter(beats);
    if (winners.length) return lowest(winners).id;
    const nonTrump = legal.filter((c) => c.suit !== TRUMP);
    return (nonTrump.length ? lowest(nonTrump) : lowest(trumps)).id;
  }
  return lowest(legal).id;
}
