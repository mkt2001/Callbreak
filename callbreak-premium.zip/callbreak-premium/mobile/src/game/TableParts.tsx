import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import type { GameView, PlayerView, Play } from '../shared/types';
import Avatar from '../components/Avatar';
import CardView, { CardBack } from '../components/CardView';
import { DarkPill, GreenBtn } from '../components/wood';
import { useTheme } from '../theme/ThemeContext';
import { sfx } from '../services/sound';

export const rel = (seat: number, my: number) => (seat - my + 4) % 4;
// relative position → direction on the table (0 bottom, 1 left, 2 top, 3 right)
const DIR = [{ x: 0, y: 1 }, { x: -1, y: 0 }, { x: 0, y: -1 }, { x: 1, y: 0 }];

/* ------------------------------------------------------------ trick */
function TrickCard({ play, r, w, collect }: { play: Play; r: number; w: number; collect: number | null }) {
  const h = w * 1.4;
  const p = useRef(new Animated.Value(0)).current;
  const c = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.spring(p, { toValue: 1, friction: 7, tension: 70, useNativeDriver: true }).start(); }, [p]);
  useEffect(() => { if (collect !== null) Animated.timing(c, { toValue: 1, duration: 480, delay: 650, useNativeDriver: true }).start(); }, [collect, c]);
  const d = DIR[r];
  const spot = { x: d.x * w * 0.85, y: d.y * h * 0.36 };
  const from = { x: d.x * w * 3.2, y: d.y * h * 2.2 };
  const cd = collect !== null ? DIR[collect] : { x: 0, y: 0 };
  const target = { x: cd.x * w * 4 - spot.x, y: cd.y * h * 2.2 - spot.y };
  const tx = Animated.add(p.interpolate({ inputRange: [0, 1], outputRange: [from.x, spot.x] }), c.interpolate({ inputRange: [0, 1], outputRange: [0, target.x] }));
  const ty = Animated.add(p.interpolate({ inputRange: [0, 1], outputRange: [from.y, spot.y] }), c.interpolate({ inputRange: [0, 1], outputRange: [0, target.y] }));
  const op = c.interpolate({ inputRange: [0, 0.8, 1], outputRange: [1, 1, 0] });
  return (
    <Animated.View style={{ position: 'absolute', opacity: op, transform: [{ translateX: tx }, { translateY: ty }, { rotate: `${(r - 1.5) * 4}deg` }] }}>
      <CardView card={play.card} w={w} animate={false} />
    </Animated.View>
  );
}
export function TrickArea({ view, w, winnerName }: { view: GameView; w: number; winnerName?: string }) {
  const h = w * 1.4;
  const collect = view.trickDone && view.lastTrickWinner !== null ? rel(view.lastTrickWinner, view.mySeat) : null;
  return (
    <View style={{ width: w * 4, height: h * 1.9, alignItems: 'center', justifyContent: 'center' }} pointerEvents="none">
      {view.trick.map((pl) => <TrickCard key={pl.card.id} play={pl} r={rel(pl.seat, view.mySeat)} w={w} collect={collect} />)}
      {view.trickDone && winnerName ? <DarkPill style={{ position: 'absolute', bottom: -6 }}><Text style={s.pillTxt}>{winnerName} wins the trick</Text></DarkPill> : null}
    </View>
  );
}

/* ------------------------------------------------------------ opponents */
function Fan({ count, base, size }: { count: number; base: number; size: number }) {
  const n = Math.min(count, 13);
  if (!n) return null;
  const cw = size * 0.42; const ch = cw * 1.4; const R = size * 0.62; const spread = 62;
  return (
    <>
      {Array.from({ length: n }, (_, i) => {
        const a = base + (n === 1 ? 0 : -spread / 2 + (spread * i) / (n - 1));
        return (
          <View key={i} style={{ position: 'absolute', left: size / 2 - cw / 2, top: size / 2 - ch / 2, transform: [{ rotate: `${a}deg` }, { translateY: R }] }}>
            <CardBack w={cw} />
          </View>
        );
      })}
    </>
  );
}
function useCountdown(active: boolean, deadline?: number) {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (!active || !deadline) { setLeft(0); return; }
    const tick = () => setLeft(Math.max(0, Math.ceil((deadline - Date.now()) / 1000)));
    tick(); const id = setInterval(tick, 500); return () => clearInterval(id);
  }, [active, deadline]);
  return left;
}
export const bidText = (p: PlayerView) => (p.bidHidden ? '?' : p.bid === null ? '–' : String(p.bid));

export function OppBlock({ p, r, active, deadline, count, size, onPress }: { p: PlayerView; r: number; active: boolean; deadline?: number; count: number; size: number; onPress: () => void }) {
  const left = useCountdown(active, deadline);
  const base = r === 2 ? 0 : r === 1 ? -90 : 90;
  const name = (
    <DarkPill><Text style={s.pillTxt} numberOfLines={1}>{p.name}</Text><View style={s.tag}><Text style={{ fontSize: 9, color: '#3B2A0A' }}>♠</Text></View></DarkPill>
  );
  const stat = (
    <DarkPill style={{ paddingVertical: 3 }}><Text style={s.pillTxt}>{p.tricksWon}/{bidText(p)}</Text><Text style={[s.pillTxt, { color: '#FFD08A', marginLeft: 6 }]}>{p.score}{left ? `  ⏱${left}` : ''}</Text></DarkPill>
  );
  const av = (
    <Pressable onPress={onPress} style={{ width: size, height: size }}>
      <Fan count={count} base={base} size={size} />
      <Avatar avatar={p.avatar} size={size} active={active} />
      {!p.connected ? <Text style={{ position: 'absolute', right: -4, top: -4, fontSize: 14 }}>💤</Text> : null}
    </Pressable>
  );
  if (r === 2) return <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}><View style={{ marginTop: 8 }}>{name}</View><View style={{ marginHorizontal: 8 }}>{av}</View><View style={{ marginTop: 8 }}>{stat}</View></View>;
  return <View style={{ alignItems: 'center' }}>{name}<View style={{ marginVertical: 5 }}>{av}</View>{stat}</View>;
}

export function MyPill({ p, active, deadline, onPress }: { p: PlayerView; active: boolean; deadline?: number; onPress: () => void }) {
  const left = useCountdown(active, deadline);
  return (
    <Pressable onPress={onPress} style={{ alignItems: 'flex-start' }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Avatar avatar={p.avatar} size={40} active={active} />
        <DarkPill style={{ marginLeft: 6 }}><Text style={s.pillTxt}>You</Text><View style={s.tag}><Text style={{ fontSize: 9, color: '#3B2A0A' }}>♠</Text></View></DarkPill>
      </View>
      <DarkPill style={{ paddingVertical: 3, marginTop: 4 }}><Text style={s.pillTxt}>{p.tricksWon}/{bidText(p)}</Text><Text style={[s.pillTxt, { color: '#FFD08A', marginLeft: 6 }]}>{p.score}{left ? `  ⏱${left}` : ''}</Text></DarkPill>
    </Pressable>
  );
}

/* ------------------------------------------------------------ bidding */
export function BiddingPanel({ view, hintBid, onBid, nameOfTurn, width }: { view: GameView; hintBid: number | null; onBid: (n: number) => void; nameOfTurn: string; width: number }) {
  const [sel, setSel] = useState(1);
  const mine = view.turn === view.mySeat;
  const [showHint, setShowHint] = useState(false);
  useEffect(() => { setSel(hintBid && showHint ? hintBid : 1); }, [view.round]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!mine) {
    return <DarkPill style={{ paddingHorizontal: 18, paddingVertical: 8 }}><Text style={[s.pillTxt, { fontSize: 14 }]}>{nameOfTurn} is bidding…</Text></DarkPill>;
  }
  const track = width - 64;
  const pos = ((sel - 1) / 12) * track;
  return (
    <View style={[s.bid, { width }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Text style={s.bidTitle}>Make your bid</Text>
        <View style={{ flex: 1 }} />
        <View style={s.chip}><Text style={{ color: '#8A4B1F', fontWeight: '900', fontSize: 12 }}>R{view.round}/{view.rounds}</Text></View>
      </View>
      <View style={{ marginTop: 6, marginHorizontal: 20, height: 40, justifyContent: 'center' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
          {Array.from({ length: 13 }, (_, i) => i + 1).map((n) => (
            <Pressable key={n} onPress={() => setSel(n)} hitSlop={6}><Text style={{ width: 20, textAlign: 'center', color: sel === n ? '#B23A1F' : '#7A4A2A', fontWeight: sel === n ? '900' : '600', fontSize: sel === n ? 16 : 13 }}>{n}</Text></Pressable>
          ))}
        </View>
        <View style={{ height: 12, borderRadius: 6, backgroundColor: '#D9CBB5', marginHorizontal: 10 }}>
          <View style={{ position: 'absolute', left: pos - 4, top: -6, width: 28, height: 24, borderRadius: 7, backgroundColor: '#A8381F', borderWidth: 2, borderColor: '#7C2412' }} />
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
        {hintBid !== null ? (
          <Pressable onPress={() => { sfx('click'); setShowHint(true); setSel(hintBid); }} style={s.round}><Text style={{ fontSize: 18 }}>💡</Text></Pressable>
        ) : <View style={{ width: 40 }} />}
        <View style={{ flex: 1 }} />
        <Pressable onPress={() => { sfx('click'); setSel(Math.max(1, sel - 1)); }} style={[s.step, sel <= 1 && { opacity: 0.4 }]}><Text style={s.stepTxt}>−</Text></Pressable>
        <Text style={s.val}>{sel}</Text>
        <Pressable onPress={() => { sfx('click'); setSel(Math.min(13, sel + 1)); }} style={[s.step, sel >= 13 && { opacity: 0.4 }]}><Text style={s.stepTxt}>+</Text></Pressable>
        <View style={{ flex: 1 }} />
        <GreenBtn small title="✓" onPress={() => onBid(sel)} style={{ width: 92 }} />
      </View>
      {hintBid !== null && showHint ? <Text style={{ color: '#2C7A1F', fontWeight: '800', fontSize: 11, position: 'absolute', left: 58, bottom: 14 }}>Suggested: {hintBid}</Text> : null}
    </View>
  );
}

/* ------------------------------------------------------------ misc */
export function ScoreTable({ view }: { view: GameView }) {
  const th = useTheme();
  const cell = { width: 74, textAlign: 'center' as const, color: th.text, fontSize: 13 };
  return (
    <View>
      <View style={{ flexDirection: 'row', marginBottom: 4 }}>
        <Text style={[cell, { width: 60, textAlign: 'left', color: th.sub }]}>Round</Text>
        {view.players.map((p) => <Text key={p.seat} style={[cell, { fontWeight: '900' }]} numberOfLines={1}>{p.seat === view.mySeat ? 'You' : p.name}</Text>)}
      </View>
      {view.roundScores.map((r, i) => (
        <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderTopWidth: 1, borderColor: th.border }}>
          <Text style={[cell, { width: 60, textAlign: 'left', color: th.sub }]}>{i + 1}</Text>
          {r.map((v, j) => <Text key={j} style={[cell, { color: v < 0 ? th.danger : th.text }]}>{v}</Text>)}
        </View>
      ))}
      <View style={{ flexDirection: 'row', paddingVertical: 5, borderTopWidth: 2, borderColor: th.primary }}>
        <Text style={[cell, { width: 60, textAlign: 'left', fontWeight: '900' }]}>Total</Text>
        {view.totals.map((v, j) => <Text key={j} style={[cell, { fontWeight: '900', color: th.primary }]}>{v}</Text>)}
      </View>
    </View>
  );
}

export function Hand({ view, cardW, selected, hintCard, onTap, animate, avail }: { view: GameView; cardW: number; selected: string | null; hintCard: string | null; onTap: (id: string) => void; animate: boolean; avail: number }) {
  const n = view.hand.length;
  const off = Math.min(cardW * 0.7, n > 1 ? (avail - cardW) / 12 : 0);
  const width = cardW + Math.max(0, n - 1) * off;
  const myTurn = view.phase === 'playing' && view.turn === view.mySeat && !view.trickDone;
  return (
    <View style={{ width, height: cardW * 1.4 + cardW * 0.3 }}>
      {view.hand.map((c, i) => (
        <View key={c.id} style={{ position: 'absolute', left: i * off, bottom: 0, zIndex: i }}>
          <CardView card={c} w={cardW} selected={selected === c.id} hinted={hintCard === c.id} disabled={myTurn ? !view.legal.includes(c.id) : false} delay={animate ? i * 45 : 0} animate={animate} onPress={() => onTap(c.id)} />
        </View>
      ))}
    </View>
  );
}

/** Shuffle (riffle) the deck in the middle of the table, then deal cards out to the four players. */
export function ShuffleDeal({ W, H, cardW, onDone }: { W: number; H: number; cardW: number; onDone: () => void }) {
  const t = useRef(new Animated.Value(0)).current;
  const d = useRef(new Animated.Value(0)).current;
  const [stage, setStage] = useState<'shuffle' | 'deal'>('shuffle');
  useEffect(() => {
    sfx('deal');
    Animated.timing(t, { toValue: 1, duration: 1500, useNativeDriver: true }).start(() => {
      setStage('deal'); sfx('deal');
      Animated.timing(d, { toValue: 1, duration: 1100, useNativeDriver: true }).start(() => { sfx('deal'); onDone(); });
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const w = cardW * 0.8;
  const dest = [{ x: 0, y: H * 0.34 }, { x: -W * 0.36, y: 0 }, { x: 0, y: -H * 0.34 }, { x: W * 0.36, y: 0 }];
  return (
    <View style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center' }]} pointerEvents="none">
      {stage === 'shuffle' && Array.from({ length: 12 }, (_, i) => {
        const side = i % 2 ? 1 : -1;
        const spread = t.interpolate({ inputRange: [0, 0.12, 0.25, 0.38, 0.5, 0.62, 0.75, 0.88, 1], outputRange: [0, 1, 0, 1, 0, 1, 0, 1, 0] });
        return (
          <Animated.View key={i} style={{ position: 'absolute', transform: [{ translateX: Animated.multiply(spread, side * (w * 0.55 + (i % 3) * 3)) }, { translateY: -i * 0.9 }, { rotate: spread.interpolate({ inputRange: [0, 1], outputRange: ['0deg', `${side * 9}deg`] }) }] }}>
            <CardBack w={w} />
          </Animated.View>
        );
      })}
      {stage === 'deal' && Array.from({ length: 16 }, (_, k) => {
        const to = dest[k % 4]; const start = (k / 16) * 0.62; const end = start + 0.38;
        const x = d.interpolate({ inputRange: [0, start, end, 1], outputRange: [0, 0, to.x, to.x] });
        const y = d.interpolate({ inputRange: [0, start, end, 1], outputRange: [0, 0, to.y, to.y] });
        const o = d.interpolate({ inputRange: [0, start, start + 0.01, end - 0.03, end, 1], outputRange: [1, 1, 1, 1, 0, 0] });
        const rot = d.interpolate({ inputRange: [start, end], outputRange: ['0deg', `${(k % 4) * 90}deg`], extrapolate: 'clamp' });
        return <Animated.View key={k} style={{ position: 'absolute', opacity: o, transform: [{ translateX: x }, { translateY: y }, { rotate: rot }] }}><CardBack w={w} /></Animated.View>;
      })}
      {stage === 'deal' ? <Animated.View style={{ position: 'absolute', opacity: d.interpolate({ inputRange: [0, 0.6, 0.7], outputRange: [1, 1, 0] }) }}><CardBack w={w} /></Animated.View> : null}
    </View>
  );
}

const s = StyleSheet.create({
  pillTxt: { color: '#fff', fontWeight: '800', fontSize: 12 },
  tag: { marginLeft: 5, backgroundColor: '#E4D39B', borderRadius: 4, paddingHorizontal: 3 },
  bid: { backgroundColor: '#FBF1DD', borderRadius: 20, borderWidth: 3, borderColor: '#B9622F', paddingHorizontal: 16, paddingVertical: 10, shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 10, elevation: 10 },
  bidTitle: { color: '#8A3B1B', fontWeight: '900', fontSize: 19 },
  chip: { backgroundColor: '#FBD98F', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3 },
  round: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#A8381F', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#7C2412' },
  step: { width: 40, height: 36, borderRadius: 10, backgroundColor: '#A8381F', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#7C2412' },
  stepTxt: { color: '#fff', fontSize: 22, fontWeight: '900', lineHeight: 24 },
  val: { width: 48, textAlign: 'center', fontSize: 30, fontWeight: '900', color: '#6B2812' },
});
