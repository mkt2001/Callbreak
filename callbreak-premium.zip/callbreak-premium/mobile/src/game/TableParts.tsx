import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import type { GameView, PlayerView, Play } from '../shared/types';
import { SUIT_SYMBOL } from '../shared/constants';
import Avatar from '../components/Avatar';
import CardView from '../components/CardView';
import { useTheme } from '../theme/ThemeContext';
import { BRAND } from '../theme/colors';
import Btn from '../components/Btn';

export const rel = (seat: number, my: number) => (seat - my + 4) % 4;
// relative position → direction on the table (0 bottom, 1 left, 2 top, 3 right)
const DIR = [{ x: 0, y: 1 }, { x: -1, y: 0 }, { x: 0, y: -1 }, { x: 1, y: 0 }];

function TrickCard({ play, r, w, collect }: { play: Play; r: number; w: number; collect: number | null }) {
  const p = useRef(new Animated.Value(0)).current;
  const c = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.spring(p, { toValue: 1, friction: 7, tension: 70, useNativeDriver: true }).start(); }, [p]);
  useEffect(() => { if (collect !== null) Animated.timing(c, { toValue: 1, duration: 480, delay: 650, useNativeDriver: true }).start(); }, [collect, c]);
  const d = DIR[r];
  const spot = { x: d.x * w * 0.78, y: d.y * w * 0.5 };
  const from = { x: d.x * w * 2.8, y: d.y * w * 2.4 };
  const cd = collect !== null ? DIR[collect] : { x: 0, y: 0 };
  const target = { x: cd.x * w * 3.4 - spot.x, y: cd.y * w * 2.8 - spot.y };
  const tx = Animated.add(p.interpolate({ inputRange: [0, 1], outputRange: [from.x, spot.x] }), c.interpolate({ inputRange: [0, 1], outputRange: [0, target.x] }));
  const ty = Animated.add(p.interpolate({ inputRange: [0, 1], outputRange: [from.y, spot.y] }), c.interpolate({ inputRange: [0, 1], outputRange: [0, target.y] }));
  const op = c.interpolate({ inputRange: [0, 0.8, 1], outputRange: [1, 1, 0] });
  return (
    <Animated.View style={{ position: 'absolute', opacity: op, transform: [{ translateX: tx }, { translateY: ty }, { rotate: `${(r - 1.5) * 4}deg` }] }}>
      <CardView card={play.card} w={w} animate={false} />
    </Animated.View>
  );
}

export function TrickArea({ view, w, winnerName }: { view: GameView; w: number; winnerName?: string }) {
  const h = w * 1.4;
  const collect = view.trickDone && view.lastTrickWinner !== null ? rel(view.lastTrickWinner, view.mySeat) : null;
  return (
    <View style={{ width: w * 3.6, height: h * 1.6, alignItems: 'center', justifyContent: 'center' }}>
      {view.trick.map((pl) => (
        <TrickCard key={pl.card.id} play={pl} r={rel(pl.seat, view.mySeat)} w={w} collect={collect} />
      ))}
      {view.trickDone && winnerName ? <Text style={s.winTxt}>{winnerName} wins the trick</Text> : null}
    </View>
  );
}

export function PlayerBadge({ p, my, active, onPress, deadline, compact }: { p: PlayerView; my: number; active: boolean; onPress?: () => void; deadline?: number; compact?: boolean }) {
  const th = useTheme();
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (!active || !deadline) { setLeft(0); return; }
    const tick = () => setLeft(Math.max(0, Math.ceil((deadline - Date.now()) / 1000)));
    tick(); const id = setInterval(tick, 500); return () => clearInterval(id);
  }, [active, deadline]);
  const me = p.seat === my;
  return (
    <Pressable onPress={onPress} style={[s.badge, { backgroundColor: th.dark ? 'rgba(31,35,64,0.92)' : 'rgba(255,255,255,0.94)', borderColor: active ? BRAND.gold : 'transparent' }]}>
      <Avatar avatar={p.avatar} size={compact ? 34 : 40} active={active} />
      <View style={{ marginLeft: 7 }}>
        <Text style={[s.name, { color: th.text }]} numberOfLines={1}>{me ? 'You' : p.name}{!p.connected ? ' 💤' : ''}</Text>
        <Text style={[s.meta, { color: th.sub }]}>Bid <Text style={{ color: th.primary, fontWeight: '900' }}>{p.bid ?? '–'}</Text>  ·  Won <Text style={{ color: th.text, fontWeight: '900' }}>{p.tricksWon}</Text></Text>
        <Text style={[s.meta, { color: th.sub }]}>Score <Text style={{ color: th.text, fontWeight: '900' }}>{p.score}</Text>{active && left > 0 ? `  ⏱ ${left}s` : ''}</Text>
      </View>
    </Pressable>
  );
}

export function BiddingPanel({ view, hintBid, onBid, nameOfTurn }: { view: GameView; hintBid: number | null; onBid: (n: number) => void; nameOfTurn: string }) {
  const th = useTheme();
  const [sel, setSel] = useState<number | null>(null);
  const mine = view.turn === view.mySeat;
  useEffect(() => { if (!mine) setSel(null); }, [mine]);
  return (
    <View style={[s.bidPanel, { backgroundColor: th.dark ? 'rgba(31,35,64,0.96)' : 'rgba(255,255,255,0.97)' }]}>
      <Text style={{ color: th.text, fontWeight: '900', fontSize: 15 }}>
        {mine ? 'Your bid — how many tricks will you win?' : `${nameOfTurn} is bidding…`}
      </Text>
      <View style={{ flexDirection: 'row', marginTop: 8, flexWrap: 'wrap', justifyContent: 'center' }}>
        {Array.from({ length: 13 }, (_, i) => i + 1).map((n) => {
          const on = sel === n;
          return (
            <Pressable key={n} disabled={!mine} onPress={() => setSel(n)} style={[s.num, { backgroundColor: on ? th.primary : th.dark ? '#2A2F55' : '#F0F1FA', borderColor: hintBid === n && mine ? th.accent : on ? th.gold : 'transparent', opacity: mine ? 1 : 0.5 }]}>
              <Text style={{ color: on ? '#fff' : th.text, fontWeight: '900', fontSize: 16 }}>{n}</Text>
            </Pressable>
          );
        })}
      </View>
      {mine && (
        <View style={{ marginTop: 8, flexDirection: 'row', alignItems: 'center' }}>
          {hintBid !== null && <Text style={{ color: th.accent, fontWeight: '800', marginRight: 12 }}>💡 Suggested: {hintBid}</Text>}
          <Btn title={sel ? `Confirm bid ${sel}` : 'Pick a number'} size="sm" variant="gold" disabled={!sel} onPress={() => { if (sel) { onBid(sel); setSel(null); } }} />
        </View>
      )}
    </View>
  );
}

export function ScoreTable({ view }: { view: GameView }) {
  const th = useTheme();
  const cell = { width: 74, textAlign: 'center' as const, color: th.text, fontSize: 13 };
  return (
    <View>
      <View style={{ flexDirection: 'row', marginBottom: 4 }}>
        <Text style={[cell, { width: 60, textAlign: 'left', color: th.sub }]}>Round</Text>
        {view.players.map((p) => <Text key={p.seat} style={[cell, { fontWeight: '900' }]} numberOfLines={1}>{p.seat === view.mySeat ? 'You' : p.name}</Text>)}
      </View>
      {view.roundScores.map((r, i) => (
        <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderTopWidth: 1, borderColor: th.border }}>
          <Text style={[cell, { width: 60, textAlign: 'left', color: th.sub }]}>{i + 1}</Text>
          {r.map((v, j) => <Text key={j} style={[cell, { color: v < 0 ? th.danger : th.text }]}>{v}</Text>)}
        </View>
      ))}
      <View style={{ flexDirection: 'row', paddingVertical: 5, borderTopWidth: 2, borderColor: th.primary }}>
        <Text style={[cell, { width: 60, textAlign: 'left', fontWeight: '900' }]}>Total</Text>
        {view.totals.map((v, j) => <Text key={j} style={[cell, { fontWeight: '900', color: th.primary }]}>{v}</Text>)}
      </View>
    </View>
  );
}

export const TrumpChip = () => (
  <View style={s.chip}><Text style={{ color: '#fff', fontWeight: '900', fontSize: 12 }}>♠ Trump</Text></View>
);

export function Hand({ view, cardW, selected, hintCard, onTap, animate, avail }: { view: GameView; cardW: number; selected: string | null; hintCard: string | null; onTap: (id: string) => void; animate: boolean; avail: number }) {
  const n = view.hand.length;
  const off = Math.min(cardW * 0.62, n > 1 ? (avail - cardW) / 12 : 0);
  const width = cardW + Math.max(0, n - 1) * off;
  const myTurn = view.phase === 'playing' && view.turn === view.mySeat && !view.trickDone;
  return (
    <View style={{ width, height: cardW * 1.4 + 22 }}>
      {view.hand.map((c, i) => {
        const legal = view.legal.includes(c.id);
        return (
          <View key={c.id} style={{ position: 'absolute', left: i * off, bottom: 0, zIndex: i }}>
            <CardView card={c} w={cardW} selected={selected === c.id} hinted={hintCard === c.id} disabled={myTurn ? !legal : false} delay={animate ? i * 45 : 0} animate={animate} onPress={() => onTap(c.id)} />
          </View>
        );
      })}
    </View>
  );
}
export const SUIT_NAME = SUIT_SYMBOL;
const s = StyleSheet.create({
  badge: { flexDirection: 'row', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 8, borderRadius: 16, borderWidth: 2, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 6, elevation: 4 },
  name: { fontWeight: '900', fontSize: 13, maxWidth: 96 },
  meta: { fontSize: 11, fontWeight: '600' },
  winTxt: { position: 'absolute', bottom: -4, color: '#fff', fontWeight: '900', fontSize: 13, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 4 },
  bidPanel: { borderRadius: 18, paddingVertical: 10, paddingHorizontal: 14, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 10, elevation: 8 },
  num: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', margin: 2.5, borderWidth: 2 },
  chip: { backgroundColor: 'rgba(32,36,58,0.7)', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 },
});
