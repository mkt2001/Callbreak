import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Difficulty, GameView, MatchState } from '../shared/types';
import { chooseBid, chooseCard, completeTrick, makeView, newMatch, nextRound as nextRoundFn, placeBid, playCard, mathRng } from '../shared/rules';
import { BOT_AVATARS, BOT_NAMES, RULE_PRESETS } from '../shared/constants';
import { useApp } from '../store/useApp';
import { sfx } from '../services/sound';
import type { GameController } from './types';

function pickBots() {
  const idx = [...BOT_NAMES.keys()].sort(() => mathRng() - 0.5).slice(0, 3);
  return idx.map((i) => ({ name: BOT_NAMES[i], avatar: BOT_AVATARS[i], isBot: true, connected: true }));
}

/** Local, fully offline match against three AI opponents. Seat 0 is always the human. */
export function useOfflineGame(level: Difficulty, hints: boolean, onMatchEnd: (r: { totals: number[]; tricks: number; myBids: number[]; names: string[] }) => void): GameController {
  const profileName = useApp((s) => s.profile.name);
  const avatar = useApp((s) => s.profile.avatar);
  const st = useRef<MatchState>(newMatch(RULE_PRESETS.standard, mathRng, Math.floor(mathRng() * 4)));
  const info = useRef([{ name: profileName, avatar, isBot: false, connected: true }, ...pickBots()]);
  const bids = useRef<number[]>([]);
  const ended = useRef(false);
  const [view, setView] = useState<GameView | null>(() => makeView(st.current, 0, info.current));
  const publish = useCallback(() => setView(makeView(st.current, 0, info.current)), []);

  useEffect(() => { sfx('deal'); }, [view?.round]);

  useEffect(() => {
    const m = st.current;
    let t: ReturnType<typeof setTimeout> | undefined;
    if (m.phase === 'bidding' && m.turn !== 0) {
      t = setTimeout(() => { placeBid(m, m.turn, chooseBid(m.hands[m.turn], level, m.bids, m.cfg.minBid, m.cfg.maxBid)); sfx('click'); publish(); }, 700);
    } else if (m.phase === 'playing') {
      if (m.trickDone) {
        t = setTimeout(() => { completeTrick(m); sfx('trick'); publish(); }, 1600);
      } else if (m.turn !== 0) {
        t = setTimeout(() => { const c = chooseCard(m, m.turn, level); playCard(m, m.turn, c.id); sfx('play'); publish(); }, 800);
      }
    } else if (m.phase === 'matchEnd' && !ended.current) {
      ended.current = true;
      onMatchEnd({ totals: m.totals.slice(), tricks: m.tricksTotal[0], myBids: bids.current.slice(), names: info.current.map((p) => p.name) });
    }
    return () => { if (t) clearTimeout(t); };
  }, [view]); // eslint-disable-line react-hooks/exhaustive-deps

  const bid = useCallback((v: number) => {
    const m = st.current;
    if (placeBid(m, 0, v) === null) { bids.current.push(v); sfx('click'); publish(); }
  }, [publish]);
  const play = useCallback((id: string) => {
    if (playCard(st.current, 0, id) === null) { sfx('play'); publish(); }
  }, [publish]);
  const nextRound = useCallback(() => { nextRoundFn(st.current); publish(); }, [publish]);

  const hint = useMemo(() => {
    const m = st.current;
    if (!hints || !view) return { card: null as string | null, bid: null as number | null };
    if (view.phase === 'bidding' && view.turn === 0) return { card: null, bid: chooseBid(m.hands[0], 'expert', m.bids, m.cfg.minBid, m.cfg.maxBid) };
    if (view.phase === 'playing' && view.turn === 0 && !view.trickDone) return { card: chooseCard(m, 0, 'expert').id, bid: null };
    return { card: null, bid: null };
  }, [view, hints]);

  return { view, bid, play, nextRound, hintCard: hint.card, hintBid: hint.bid, connected: true, myBids: () => bids.current };
}
