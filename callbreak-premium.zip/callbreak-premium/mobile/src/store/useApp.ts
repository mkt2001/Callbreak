import { useEffect, useState } from 'react';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { byId, CATALOG, VIP_PRICE } from '../theme/catalog';

export interface Settings {
  dark: boolean | null; // null = follow system
  sound: boolean; music: boolean; animations: boolean; vibration: boolean;
  cardTheme: string; cardBack: string; table: string; soundPack: string; lang: string;
  notifications: boolean; showOnline: boolean; publicProfile: boolean; server: string;
}
export interface Profile {
  id: string; name: string; avatar: string; frame: string; badge: string | null; email: string | null; token: string | null;
  guest: boolean; onboarded: boolean; loggedIn: boolean; coins: number; xp: number; vip: boolean; owned: string[];
}
export interface Stats {
  matches: number; wins: number; tricks: number; bidSum: number; bidCount: number; streak: number; bestStreak: number;
  highScore: number; achievements: string[]; practiceMatches: number; practiceWins: number;
}
export interface HistoryItem { id: string; date: number; mode: string; totals: number[]; rank: number; names: string[] }
export interface MatchResult {
  mode: 'quick' | 'practice' | 'private' | 'tournament' | 'online'; totals: number[]; tricks: number; myBids: number[]; names: string[];
}
export interface Missions { day: string; week: string; p: Record<string, number>; claimed: Record<string, boolean> }

export const MISSIONS = [
  { id: 'd_play', period: 'day', title: 'Play 3 matches', goal: 3, reward: 100, metric: 'matches' },
  { id: 'd_win', period: 'day', title: 'Win 1 match', goal: 1, reward: 150, metric: 'wins' },
  { id: 'd_tricks', period: 'day', title: 'Win 25 tricks', goal: 25, reward: 120, metric: 'tricks' },
  { id: 'w_play', period: 'week', title: 'Play 15 matches', goal: 15, reward: 600, metric: 'matches' },
  { id: 'w_win', period: 'week', title: 'Win 7 matches', goal: 7, reward: 900, metric: 'wins' },
  { id: 'w_tricks', period: 'week', title: 'Win 120 tricks', goal: 120, reward: 700, metric: 'tricks' },
] as const;
export const DAILY_COINS = [100, 150, 200, 300, 400, 500, 1000];
export const ACHIEVEMENTS: Record<string, { name: string; emoji: string; desc: string }> = {
  first_win: { name: 'First Win', emoji: '🏆', desc: 'Win your first match' },
  ten_matches: { name: 'Regular', emoji: '🎴', desc: 'Play 10 matches' },
  streak3: { name: 'Hat-trick', emoji: '🔥', desc: 'Win 3 matches in a row' },
  streak5: { name: 'Unstoppable', emoji: '⚡', desc: 'Win 5 matches in a row' },
  score20: { name: 'High Roller', emoji: '💎', desc: 'Score 20+ points in a match' },
  tricks100: { name: 'Trick Master', emoji: '🃏', desc: 'Win 100 tricks' },
  collector: { name: 'Collector', emoji: '🛍️', desc: 'Own 6 cosmetic items' },
};

export const todayStr = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const weekStr = (d = new Date()) => {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return `${t.getUTCFullYear()}-W${Math.ceil(((+t - +y0) / 86400000 + 1) / 7)}`;
};
export const xpForLevel = (lvl: number) => 100 + (lvl - 1) * 60;
export function levelInfo(xp: number) {
  let lvl = 1, rem = xp;
  while (rem >= xpForLevel(lvl)) { rem -= xpForLevel(lvl); lvl++; }
  return { level: lvl, into: rem, need: xpForLevel(lvl) };
}

const defaultSettings: Settings = {
  dark: null, sound: true, music: false, animations: true, vibration: true, cardTheme: 'classic', cardBack: 'back_purple',
  table: 'table_green', soundPack: 'snd_classic', lang: 'en', notifications: true, showOnline: true, publicProfile: true, server: '',
};
const defaultProfile: Profile = {
  id: '', name: 'Player', avatar: 'av_cool', frame: 'frame_none', badge: null, email: null, token: null, guest: true,
  onboarded: false, loggedIn: false, coins: 1000, xp: 0, vip: false,
  owned: CATALOG.filter((i) => i.price === 0).map((i) => i.id),
};
const defaultStats: Stats = {
  matches: 0, wins: 0, tricks: 0, bidSum: 0, bidCount: 0, streak: 0, bestStreak: 0, highScore: 0, achievements: [],
  practiceMatches: 0, practiceWins: 0,
};

interface State {
  settings: Settings; profile: Profile; stats: Stats; history: HistoryItem[];
  daily: { last: string | null; day: number };
  missions: Missions;
  tournament: { day: string; week: string; dayPts: number; weekPts: number; played: number };
  set: (p: Partial<Settings>) => void;
  setProfile: (p: Partial<Profile>) => void;
  signIn: (p: Partial<Profile>) => void;
  signOut: () => void;
  refreshPeriods: () => void;
  recordMatch: (r: MatchResult) => { coins: number; xp: number; rank: number; leveledUp: boolean; newAchievements: string[] };
  claimDaily: () => number;
  claimMission: (id: string) => boolean;
  buy: (id: string) => boolean;
  buyVip: () => boolean;
  equip: (id: string) => void;
  addCoins: (n: number) => void;
}

const rankOf = (totals: number[], seat = 0) => 1 + totals.filter((t) => t > totals[seat]).length;
const freshMissions = (): Missions => ({ day: todayStr(), week: weekStr(), p: {}, claimed: {} });

export const useApp = create<State>()(
  persist(
    (set, get) => ({
      settings: defaultSettings, profile: defaultProfile, stats: defaultStats, history: [],
      daily: { last: null, day: 0 }, missions: freshMissions(),
      tournament: { day: todayStr(), week: weekStr(), dayPts: 0, weekPts: 0, played: 0 },
      set: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      setProfile: (p) => set((s) => ({ profile: { ...s.profile, ...p } })),
      signIn: (p) => set((s) => ({ profile: { ...s.profile, ...p, loggedIn: true, id: p.id || s.profile.id || 'local-' + Date.now() } })),
      signOut: () => set((s) => ({ profile: { ...s.profile, loggedIn: false, token: null } })),
      refreshPeriods: () => {
        const s = get(); const d = todayStr(); const w = weekStr();
        const m = { ...s.missions, p: { ...s.missions.p }, claimed: { ...s.missions.claimed } };
        let changed = false;
        if (m.day !== d) { MISSIONS.filter((x) => x.period === 'day').forEach((x) => { delete m.p[x.id]; delete m.claimed[x.id]; }); m.day = d; changed = true; }
        if (m.week !== w) { MISSIONS.filter((x) => x.period === 'week').forEach((x) => { delete m.p[x.id]; delete m.claimed[x.id]; }); m.week = w; changed = true; }
        const t = { ...s.tournament };
        if (t.day !== d) { t.day = d; t.dayPts = 0; changed = true; }
        if (t.week !== w) { t.week = w; t.weekPts = 0; changed = true; }
        if (changed) set({ missions: m, tournament: t });
      },
      recordMatch: (r) => {
        get().refreshPeriods();
        const s = get();
        const rank = rankOf(r.totals);
        const win = rank === 1;
        const mult = r.mode === 'tournament' ? 2 : r.mode === 'practice' ? 0.5 : 1;
        let coins = Math.round([300, 150, 80, 40][rank - 1] * mult);
        const xp = Math.round([120, 80, 50, 30][rank - 1] * (r.mode === 'practice' ? 0.6 : 1));
        const streak = win ? s.stats.streak + 1 : 0;
        if (win && [3, 5, 10].includes(streak)) coins += streak === 3 ? 200 : streak === 5 ? 500 : 1500;
        const st: Stats = {
          ...s.stats, matches: s.stats.matches + 1, wins: s.stats.wins + (win ? 1 : 0), tricks: s.stats.tricks + r.tricks,
          bidSum: s.stats.bidSum + r.myBids.reduce((a, b) => a + b, 0), bidCount: s.stats.bidCount + r.myBids.length,
          streak, bestStreak: Math.max(s.stats.bestStreak, streak), highScore: Math.max(s.stats.highScore, r.totals[0]),
          practiceMatches: s.stats.practiceMatches + (r.mode === 'practice' ? 1 : 0),
          practiceWins: s.stats.practiceWins + (r.mode === 'practice' && win ? 1 : 0),
        };
        const got: string[] = [];
        const ach = (id: string, ok: boolean) => { if (ok && !st.achievements.includes(id)) { st.achievements = [...st.achievements, id]; got.push(id); coins += 100; } };
        ach('first_win', st.wins >= 1); ach('ten_matches', st.matches >= 10); ach('streak3', st.bestStreak >= 3);
        ach('streak5', st.bestStreak >= 5); ach('score20', r.totals[0] >= 20); ach('tricks100', st.tricks >= 100);
        const before = levelInfo(s.profile.xp).level;
        const after = levelInfo(s.profile.xp + xp).level;
        const m = { ...s.missions, p: { ...s.missions.p } };
        for (const mi of MISSIONS) {
          const add = mi.metric === 'matches' ? 1 : mi.metric === 'wins' ? (win ? 1 : 0) : r.tricks;
          m.p[mi.id] = Math.min(mi.goal, (m.p[mi.id] || 0) + add);
        }
        const t = { ...s.tournament };
        if (r.mode === 'tournament') { const pts = [10, 6, 3, 1][rank - 1]; t.dayPts += pts; t.weekPts += pts; t.played += 1; }
        const hist: HistoryItem = { id: String(Date.now()), date: Date.now(), mode: r.mode, totals: r.totals, rank, names: r.names };
        set({
          stats: st, missions: m, tournament: t, history: [hist, ...s.history].slice(0, 50),
          profile: { ...s.profile, coins: s.profile.coins + coins, xp: s.profile.xp + xp },
        });
        return { coins, xp, rank, leveledUp: after > before, newAchievements: got };
      },
      claimDaily: () => {
        const s = get(); const today = todayStr();
        if (s.daily.last === today) return 0;
        const y = new Date(); y.setDate(y.getDate() - 1);
        const day = s.daily.last === todayStr(y) ? s.daily.day % 7 : 0;
        const coins = DAILY_COINS[day];
        set({ daily: { last: today, day: day + 1 }, profile: { ...s.profile, coins: s.profile.coins + coins } });
        return coins;
      },
      claimMission: (id) => {
        get().refreshPeriods();
        const s = get(); const mi = MISSIONS.find((x) => x.id === id);
        if (!mi || s.missions.claimed[id] || (s.missions.p[id] || 0) < mi.goal) return false;
        set({ missions: { ...s.missions, claimed: { ...s.missions.claimed, [id]: true } }, profile: { ...s.profile, coins: s.profile.coins + mi.reward } });
        return true;
      },
      buy: (id) => {
        const s = get(); const it = byId(id);
        if (!it || s.profile.owned.includes(id) || s.profile.coins < it.price) return false;
        const owned = [...s.profile.owned, id];
        const stats = { ...s.stats };
        if (owned.length - CATALOG.filter((i) => i.price === 0).length >= 6 && !stats.achievements.includes('collector')) stats.achievements = [...stats.achievements, 'collector'];
        set({ profile: { ...s.profile, coins: s.profile.coins - it.price, owned }, stats });
        return true;
      },
      buyVip: () => {
        const s = get();
        if (s.profile.vip || s.profile.coins < VIP_PRICE) return false;
        set({ profile: { ...s.profile, vip: true, coins: s.profile.coins - VIP_PRICE, owned: Array.from(new Set([...s.profile.owned, 'frame_gold', 'badge_star'])) } });
        return true;
      },
      equip: (id) => {
        const s = get(); const it = byId(id);
        if (!it || !s.profile.owned.includes(id)) return;
        if (it.kind === 'cardTheme') set({ settings: { ...s.settings, cardTheme: id } });
        else if (it.kind === 'cardBack') set({ settings: { ...s.settings, cardBack: id } });
        else if (it.kind === 'table') set({ settings: { ...s.settings, table: id } });
        else if (it.kind === 'sound') set({ settings: { ...s.settings, soundPack: id } });
        else if (it.kind === 'avatar') set({ profile: { ...s.profile, avatar: id } });
        else if (it.kind === 'frame') set({ profile: { ...s.profile, frame: id } });
        else if (it.kind === 'badge') set({ profile: { ...s.profile, badge: s.profile.badge === id ? null : id } });
      },
      addCoins: (n) => set((s) => ({ profile: { ...s.profile, coins: s.profile.coins + n } })),
    }),
    { name: 'callbreak-premium-v1', storage: createJSONStorage(() => AsyncStorage) },
  ),
);

export function useHydrated() {
  const [h, setH] = useState(useApp.persist.hasHydrated());
  useEffect(() => {
    const un = useApp.persist.onFinishHydration(() => setH(true));
    setH(useApp.persist.hasHydrated());
    return un;
  }, []);
  return h;
}
