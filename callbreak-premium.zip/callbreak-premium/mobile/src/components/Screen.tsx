import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../theme/ThemeContext';
import { sfx } from '../services/sound';

interface Props { title?: string; children: React.ReactNode; right?: React.ReactNode; noBack?: boolean; onBack?: () => void }
export default function Screen({ title, children, right, noBack, onBack }: Props) {
  const th = useTheme();
  const nav = useNavigation<any>();
  return (
    <View style={{ flex: 1, backgroundColor: th.bg }}>
      <View style={[s.blob, { backgroundColor: th.primary, top: -140, left: -90 }]} />
      <View style={[s.blob, { backgroundColor: th.accent, bottom: -170, right: -80 }]} />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom', 'left', 'right']}>
        {title !== undefined && (
          <View style={s.header}>
            {!noBack ? (
              <Pressable onPress={() => { sfx('click'); onBack ? onBack() : nav.goBack(); }} style={[s.back, { backgroundColor: th.card, borderColor: th.border }]}>
                <Text style={{ color: th.text, fontSize: 18, fontWeight: '800' }}>‹</Text>
              </Pressable>
            ) : <View style={{ width: 36 }} />}
            <Text style={[s.title, { color: th.text }]} numberOfLines={1}>{title}</Text>
            <View style={{ minWidth: 36, alignItems: 'flex-end' }}>{right}</View>
          </View>
        )}
        <View style={{ flex: 1, paddingHorizontal: 16, paddingBottom: 8 }}>{children}</View>
      </SafeAreaView>
    </View>
  );
}
const s = StyleSheet.create({
  blob: { position: 'absolute', width: 340, height: 340, borderRadius: 170, opacity: 0.12 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, height: 48 },
  back: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  title: { flex: 1, fontSize: 20, fontWeight: '800', marginLeft: 12 },
});
