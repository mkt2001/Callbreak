import React from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../theme/ThemeContext';
import { sfx } from '../services/sound';

export function ToggleRow({ label, value, onChange, sub }: { label: string; value: boolean; onChange: (v: boolean) => void; sub?: string }) {
  const th = useTheme();
  return (
    <View style={s.row}>
      <View style={{ flex: 1 }}>
        <Text style={{ color: th.text, fontWeight: '800', fontSize: 14 }}>{label}</Text>
        {sub ? <Text style={{ color: th.sub, fontSize: 11 }}>{sub}</Text> : null}
      </View>
      <Switch value={value} onValueChange={(v) => { sfx('click'); onChange(v); }} trackColor={{ true: th.primary, false: th.border }} thumbColor="#fff" />
    </View>
  );
}
export function Seg<T extends string | number>({ options, value, onChange }: { options: { id: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  const th = useTheme();
  return (
    <View style={{ flexDirection: 'row', backgroundColor: th.dark ? '#2A2F55' : '#EEF0FA', borderRadius: 999, padding: 3 }}>
      {options.map((o) => (
        <Pressable key={String(o.id)} onPress={() => { sfx('click'); onChange(o.id); }} style={{ flex: 1, paddingVertical: 7, paddingHorizontal: 12, borderRadius: 999, alignItems: 'center', backgroundColor: value === o.id ? th.primary : 'transparent' }}>
          <Text style={{ color: value === o.id ? '#fff' : th.text, fontWeight: '800', fontSize: 12 }}>{o.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}
export function CoinPill({ coins }: { coins: number }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFC857', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 }}>
      <Text style={{ fontSize: 14 }}>🪙</Text>
      <Text style={{ color: '#20243A', fontWeight: '900', marginLeft: 5 }}>{coins.toLocaleString()}</Text>
    </View>
  );
}
export function XPBar({ into, need, width = 120 }: { into: number; need: number; width?: number }) {
  const th = useTheme();
  return (
    <View style={{ width, height: 8, borderRadius: 4, backgroundColor: th.border, overflow: 'hidden' }}>
      <LinearGradient colors={th.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ width: `${Math.min(100, (into / need) * 100)}%`, height: 8 }} />
    </View>
  );
}
export function H({ children }: { children: React.ReactNode }) {
  const th = useTheme();
  return <Text style={{ color: th.text, fontWeight: '900', fontSize: 16, marginBottom: 8 }}>{children}</Text>;
}
export function Tabs({ tabs, value, onChange }: { tabs: { id: string; label: string }[]; value: string; onChange: (id: string) => void }) {
  const th = useTheme();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
      {tabs.map((t) => (
        <Pressable key={t.id} onPress={() => { sfx('click'); onChange(t.id); }} style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, marginRight: 6, marginBottom: 4, backgroundColor: value === t.id ? th.primary : th.card, borderWidth: 1, borderColor: value === t.id ? th.primary : th.border }}>
          <Text style={{ color: value === t.id ? '#fff' : th.text, fontWeight: '800', fontSize: 12 }}>{t.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}
const s = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 7 } });
