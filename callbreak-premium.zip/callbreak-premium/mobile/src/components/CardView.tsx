import React, { useEffect, useRef } from 'react';
import { Animated as RNAnimated, PanResponder, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import type { Card } from '../shared/types';
import { RANK_LABEL, SUIT_SYMBOL } from '../shared/constants';
import { byId, FACE_STYLES } from '../theme/catalog';
import { useApp } from '../store/useApp';

export const label = (r: number) => RANK_LABEL[r] ?? String(r);

export function CardBack({ w = 56, back }: { w?: number; back?: string }) {
  const id = useApp((s) => s.settings.cardBack);
  const it = byId(back ?? id) ?? byId('back_ruby');
  const colors = (it.colors ?? ['#D9304F', '#8E1230']) as [string, string];
  const h = w * 1.4;
  return (
    <LinearGradient colors={colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: w, height: h, borderRadius: w * 0.12, borderWidth: Math.max(1.5, w * 0.04), borderColor: '#fff', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <View style={{ width: w * 0.78, height: h * 0.84, borderRadius: w * 0.08, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.65)', alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ position: 'absolute', width: w * 0.62, height: w * 0.62, borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)', transform: [{ rotate: '45deg' }] }} />
        <Text style={{ color: 'rgba(255,255,255,0.92)', fontSize: w * 0.46 }}>{it.emblem ?? '♠'}</Text>
      </View>
    </LinearGradient>
  );
}

interface Props {
  card: Card; w?: number; selected?: boolean; disabled?: boolean; hinted?: boolean; onPress?: () => void; onSwipeUp?: () => void; delay?: number; animate?: boolean; theme?: string;
}
export default function CardView({ card, w = 60, selected, disabled, hinted, onPress, onSwipeUp, delay = 0, animate = true, theme }: Props) {
  const stored = useApp((s) => s.settings.cardTheme);
  const f = FACE_STYLES[theme ?? stored] ?? FACE_STYLES.classic;
  const color = card.suit === 'H' || card.suit === 'D' ? f.red : f.black;
  const h = w * 1.4;
  const lift = useSharedValue(0);
  // touch handling: tap = select / play selected, swipe up = throw the card
  const drag = useRef(new RNAnimated.Value(0)).current;
  const cb = useRef({ onPress, onSwipeUp });
  cb.current = { onPress, onSwipeUp };
  const reset = () => RNAnimated.spring(drag, { toValue: 0, useNativeDriver: false, friction: 7 }).start();
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => !!cb.current.onPress,
    onMoveShouldSetPanResponder: () => !!cb.current.onPress,
    onPanResponderMove: (_e, g) => drag.setValue(Math.min(0, g.dy)),
    onPanResponderRelease: (_e, g) => {
      if (g.dy < -35 && Math.abs(g.dy) > Math.abs(g.dx)) { cb.current.onSwipeUp?.(); drag.setValue(0); }
      else { if (Math.hypot(g.dx, g.dy) < 10) cb.current.onPress?.(); reset(); }
    },
    onPanResponderTerminate: reset,
  })).current;
  useEffect(() => { lift.value = withSpring(selected ? -h * 0.2 : hinted ? -h * 0.1 : 0, { damping: 14 }); }, [selected, hinted, h]);
  const st = useAnimatedStyle(() => ({ transform: [{ translateY: lift.value }] }));
  const ring = selected ? '#FFC857' : hinted ? '#20C9B0' : f.border;
  const inner = (
    <>
      <View style={{ position: 'absolute', top: w * 0.03, left: w * 0.07, alignItems: 'center' }}>
        <Text style={{ color, fontWeight: '900', fontSize: w * 0.36, lineHeight: w * 0.38 }}>{label(card.rank)}</Text>
        <Text style={{ color, fontSize: w * 0.3, lineHeight: w * 0.3 }}>{SUIT_SYMBOL[card.suit]}</Text>
      </View>
      <Text style={{ position: 'absolute', right: w * 0.08, bottom: h * 0.04, color, fontSize: w * 0.66, opacity: 0.95 }}>{SUIT_SYMBOL[card.suit]}</Text>
      {disabled && <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(32,36,58,0.4)', borderRadius: w * 0.12 }]} />}
    </>
  );
  const box = { width: w, height: h, borderRadius: w * 0.12, borderColor: ring, borderWidth: selected || hinted ? 3 : 1.5, shadowColor: f.glow ?? '#000', shadowOpacity: f.glow ? 0.8 : 0.3, shadowRadius: f.glow ? 8 : 4, elevation: 5, overflow: 'hidden' as const };
  const body = f.grad
    ? <LinearGradient colors={f.grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={box}>{inner}</LinearGradient>
    : <View style={[box, { backgroundColor: f.bg }]}>{inner}</View>;
  const Wrapper: any = animate ? Animated.View : View;
  return (
    <Wrapper {...(animate ? { entering: FadeInDown.delay(delay).springify().damping(14) } : {})}>
      <Animated.View style={st}>
        {onPress ? <RNAnimated.View style={{ transform: [{ translateY: drag }] }} {...pan.panHandlers}>{body}</RNAnimated.View> : body}
      </Animated.View>
    </Wrapper>
  );
}
