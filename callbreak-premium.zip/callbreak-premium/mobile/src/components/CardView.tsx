import React, { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import type { Card } from '../shared/types';
import { RANK_LABEL, SUIT_SYMBOL } from '../shared/constants';
import { byId, FACE_STYLES } from '../theme/catalog';
import { useApp } from '../store/useApp';

export const label = (r: number) => RANK_LABEL[r] ?? String(r);

export function CardBack({ w = 56, back }: { w?: number; back?: string }) {
  const id = useApp((s) => s.settings.cardBack);
  const colors = (byId(back ?? id).colors ?? ['#7047EB', '#20C9B0']) as [string, string];
  const h = w * 1.4;
  return (
    <LinearGradient colors={colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: w, height: h, borderRadius: w * 0.12, borderWidth: 2, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' }}>
      <View style={{ width: w * 0.72, height: h * 0.8, borderRadius: w * 0.08, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.7)', alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: 'rgba(255,255,255,0.9)', fontSize: w * 0.5 }}>♠</Text>
      </View>
    </LinearGradient>
  );
}

interface Props {
  card: Card; w?: number; selected?: boolean; disabled?: boolean; hinted?: boolean; onPress?: () => void; delay?: number; animate?: boolean; theme?: string;
}
export default function CardView({ card, w = 60, selected, disabled, hinted, onPress, delay = 0, animate = true, theme }: Props) {
  const stored = useApp((s) => s.settings.cardTheme);
  const f = FACE_STYLES[theme ?? stored] ?? FACE_STYLES.classic;
  const color = card.suit === 'H' || card.suit === 'D' ? f.red : f.black;
  const h = w * 1.4;
  const lift = useSharedValue(0);
  useEffect(() => { lift.value = withSpring(selected ? -18 : hinted ? -8 : 0, { damping: 14 }); }, [selected, hinted]);
  const st = useAnimatedStyle(() => ({ transform: [{ translateY: lift.value }] }));
  const body = (
    <View style={[s.card, { width: w, height: h, borderRadius: w * 0.12, backgroundColor: f.bg, borderColor: selected ? '#FFC857' : hinted ? '#20C9B0' : f.border, borderWidth: selected || hinted ? 2.5 : 1.5 }]}>
      <View style={{ position: 'absolute', top: 2, left: w * 0.08, alignItems: 'center' }}>
        <Text style={{ color, fontWeight: '900', fontSize: w * 0.3, lineHeight: w * 0.32 }}>{label(card.rank)}</Text>
        <Text style={{ color, fontSize: w * 0.26, lineHeight: w * 0.27 }}>{SUIT_SYMBOL[card.suit]}</Text>
      </View>
      <Text style={{ color, fontSize: w * 0.62, marginTop: h * 0.18, opacity: 0.92 }}>{SUIT_SYMBOL[card.suit]}</Text>
      {disabled && <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(32,36,58,0.38)', borderRadius: w * 0.12 }]} />}
    </View>
  );
  const Wrapper: any = animate ? Animated.View : View;
  return (
    <Wrapper {...(animate ? { entering: FadeInDown.delay(delay).springify().damping(14) } : {})}>
      <Animated.View style={st}>
        {onPress ? <Pressable onPress={onPress} hitSlop={2}>{body}</Pressable> : body}
      </Animated.View>
    </Wrapper>
  );
}
const s = StyleSheet.create({
  card: { alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 4, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
});
