import React, { useEffect } from 'react';
import { Image } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';

export default function Logo({ size = 140, pulse = false }: { size?: number; pulse?: boolean }) {
  const k = useSharedValue(1);
  useEffect(() => {
    if (pulse) k.value = withRepeat(withSequence(withTiming(1.05, { duration: 1100 }), withTiming(1, { duration: 1100 })), -1);
  }, [pulse]);
  const st = useAnimatedStyle(() => ({ transform: [{ scale: k.value }] }));
  return (
    <Animated.View style={st}>
      <Image source={require('../../assets/logo.png')} style={{ width: size, height: size }} resizeMode="contain" />
    </Animated.View>
  );
}
