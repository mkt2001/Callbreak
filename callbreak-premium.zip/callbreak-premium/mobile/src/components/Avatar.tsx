import React, { useEffect } from 'react';
import { Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { byId } from '../theme/catalog';
import { useTheme } from '../theme/ThemeContext';

/** `avatar` can be a catalog id (av_*) or a raw emoji (bots). */
export default function Avatar({ avatar, size = 44, frame = 'frame_none', active = false, animate = true }: { avatar: string; size?: number; frame?: string; active?: boolean; animate?: boolean }) {
  const th = useTheme();
  const item = avatar.startsWith('av_') ? byId(avatar) : undefined;
  const emoji = item?.emoji ?? avatar;
  const fr = byId(frame)?.colors?.[0] ?? 'transparent';
  const y = useSharedValue(0);
  useEffect(() => {
    if (item?.animated && animate) y.value = withRepeat(withSequence(withTiming(-3, { duration: 700 }), withTiming(0, { duration: 700 })), -1);
  }, [item?.animated, animate]);
  const st = useAnimatedStyle(() => ({ transform: [{ translateY: y.value }] }));
  const ring = active ? '#FFC857' : fr;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: th.dark ? '#2A2F55' : '#EEF0FA', alignItems: 'center', justifyContent: 'center', borderWidth: ring === 'transparent' ? 0 : 3, borderColor: ring, shadowColor: ring, shadowOpacity: ring === 'transparent' ? 0 : 0.7, shadowRadius: 8, elevation: ring === 'transparent' ? 0 : 6 }}>
      <Animated.View style={st}><Text style={{ fontSize: size * 0.52 }}>{emoji}</Text></Animated.View>
    </View>
  );
}
