import React from 'react';
import { Pressable, StyleSheet, Text, ViewStyle, StyleProp } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { sfx } from '../services/sound';
import { BRAND } from '../theme/colors';
import { useTheme } from '../theme/ThemeContext';

interface Props {
  title: string; onPress?: () => void; variant?: 'primary' | 'gold' | 'ghost' | 'danger' | 'turq';
  size?: 'sm' | 'md' | 'lg'; disabled?: boolean; style?: StyleProp<ViewStyle>; icon?: string; silent?: boolean;
}
const GRAD: Record<string, [string, string]> = {
  primary: [BRAND.purple, '#8E6BFF'], gold: [BRAND.gold, '#FFAE3D'], danger: ['#E5484D', '#FF7A7F'], turq: [BRAND.turquoise, '#4FE3CC'], ghost: ['transparent', 'transparent'],
};
export default function Btn({ title, onPress, variant = 'primary', size = 'md', disabled, style, icon, silent }: Props) {
  const th = useTheme();
  const h = size === 'lg' ? 52 : size === 'md' ? 42 : 32;
  const fs = size === 'lg' ? 18 : size === 'md' ? 15 : 13;
  const ghost = variant === 'ghost';
  const textColor = variant === 'gold' ? BRAND.navy : ghost ? th.text : '#fff';
  return (
    <Pressable
      disabled={disabled}
      onPress={() => { if (!silent) sfx('click'); onPress?.(); }}
      style={({ pressed }) => [{ opacity: disabled ? 0.45 : pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] }, style]}
    >
      <LinearGradient
        colors={GRAD[variant]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={[s.btn, { height: h, paddingHorizontal: size === 'sm' ? 14 : 22 }, ghost && { borderWidth: 1.5, borderColor: th.border, backgroundColor: th.card }, !ghost && s.shadow]}
      >
        <Text style={{ color: textColor, fontWeight: '800', fontSize: fs }}>{icon ? `${icon}  ` : ''}{title}</Text>
      </LinearGradient>
    </Pressable>
  );
}
const s = StyleSheet.create({
  btn: { borderRadius: 999, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' },
  shadow: { shadowColor: '#20243A', shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 4 },
});
