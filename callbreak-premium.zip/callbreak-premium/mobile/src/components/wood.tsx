import React from 'react';
import { ImageBackground, Pressable, StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Avatar from './Avatar';
import { sfx } from '../services/sound';
import { tableImg } from '../theme/tables';

/** Full-strength themed background (wood by default). */
export function Wood({ children, table = 'table_wood' }: { children: React.ReactNode; table?: string }) {
  return <ImageBackground source={tableImg(table)} resizeMode="cover" style={{ flex: 1 }}>{children}</ImageBackground>;
}

/** Brown-red wooden panel with a darker bottom lip – used for menu cards. */
export function WoodCard({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const body = (
    <View style={[s.lip, style]}>
      <LinearGradient colors={['#B4503A', '#9A3D2C']} style={s.face}>{children}</LinearGradient>
    </View>
  );
  if (!onPress) return body;
  return (
    <Pressable onPress={() => { sfx('click'); onPress(); }} style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.97 : 1 }] })}>{body}</Pressable>
  );
}

/** Square wooden icon button (leaderboard, store, settings …). */
export function WoodIcon({ icon, onPress, dot, size = 46 }: { icon: string; onPress: () => void; dot?: boolean; size?: number }) {
  return (
    <Pressable onPress={() => { sfx('click'); onPress(); }} style={({ pressed }) => ({ marginLeft: 8, transform: [{ scale: pressed ? 0.94 : 1 }] })}>
      <View style={[s.iconLip, { width: size, height: size + 4 }]}>
        <LinearGradient colors={['#C45A40', '#A24630']} style={[s.iconFace, { width: size, height: size }]}>
          <Text style={{ fontSize: size * 0.48 }}>{icon}</Text>
        </LinearGradient>
      </View>
      {dot ? <View style={s.dot} /> : null}
    </Pressable>
  );
}

export function DarkPill({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[s.pill, style]}>{children}</View>;
}

export function GreenBtn({ title, onPress, style, small, disabled }: { title: string; onPress: () => void; style?: StyleProp<ViewStyle>; small?: boolean; disabled?: boolean }) {
  return (
    <Pressable disabled={disabled} onPress={() => { sfx('click'); onPress(); }} style={({ pressed }) => [{ opacity: disabled ? 0.5 : 1, transform: [{ scale: pressed ? 0.96 : 1 }] }, style]}>
      <View style={{ backgroundColor: '#157A0E', borderRadius: 14, paddingBottom: 4 }}>
        <LinearGradient colors={['#3EDB1B', '#1FA312']} style={{ borderRadius: 14, height: small ? 34 : 42, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontWeight: '900', fontSize: small ? 14 : 18, letterSpacing: 1, textShadowColor: 'rgba(0,0,0,0.3)', textShadowRadius: 2 }}>{title}</Text>
        </LinearGradient>
      </View>
    </Pressable>
  );
}

/** Profile pill: avatar, name, coins and a green + that opens the store. */
export function ProfilePill({ name, avatar, frame, coins, vip, onProfile, onPlus }: { name: string; avatar: string; frame: string; coins: number; vip?: boolean; onProfile: () => void; onPlus: () => void }) {
  return (
    <View style={s.profile}>
      <Pressable onPress={() => { sfx('click'); onProfile(); }} style={s.avatarWrap}>
        <Avatar avatar={avatar} frame={frame} size={46} />
      </Pressable>
      <View style={{ marginLeft: 8, flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={s.online} />
          <Text style={s.pname} numberOfLines={1}>{name}{vip ? ' 👑' : ''}</Text>
          <View style={s.spadeTag}><Text style={{ fontSize: 10, color: '#3B2A0A' }}>♠</Text></View>
        </View>
        <View style={s.coinRow}>
          <Text style={{ fontSize: 14 }}>🪙</Text>
          <Text style={s.coinTxt}>{coins.toLocaleString()}</Text>
          <Pressable onPress={() => { sfx('click'); onPlus(); }} style={s.plus}><Text style={{ color: '#fff', fontWeight: '900', fontSize: 16, lineHeight: 18 }}>+</Text></Pressable>
        </View>
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  lip: { backgroundColor: '#5A1740', borderRadius: 22, paddingBottom: 6, shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 6 },
  face: { borderRadius: 22, borderWidth: 2, borderColor: 'rgba(255,214,170,0.55)', overflow: 'hidden' },
  iconLip: { backgroundColor: '#5A1740', borderRadius: 14 },
  iconFace: { borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'rgba(255,214,170,0.55)' },
  dot: { position: 'absolute', top: -5, right: -5, width: 16, height: 16, borderRadius: 8, backgroundColor: '#E5252A', borderWidth: 2, borderColor: '#fff' },
  pill: { backgroundColor: 'rgba(58,34,22,0.82)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5, flexDirection: 'row', alignItems: 'center' },
  profile: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#B4503A', borderRadius: 30, paddingRight: 10, paddingLeft: 4, height: 56, minWidth: 220, borderWidth: 2, borderColor: 'rgba(255,214,170,0.55)', shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 6, elevation: 5 },
  avatarWrap: { borderRadius: 26, borderWidth: 3, borderColor: '#fff', backgroundColor: '#fff' },
  online: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#35E21B', marginRight: 5 },
  pname: { color: '#fff', fontWeight: '800', fontSize: 14, maxWidth: 100 },
  spadeTag: { marginLeft: 5, backgroundColor: '#E4D39B', borderRadius: 4, paddingHorizontal: 4 },
  coinRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(58,20,10,0.55)', borderRadius: 14, marginTop: 2, paddingLeft: 6, height: 24 },
  coinTxt: { color: '#fff', fontWeight: '900', fontSize: 15, marginLeft: 4, flex: 1 },
  plus: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#22B30E', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
});
