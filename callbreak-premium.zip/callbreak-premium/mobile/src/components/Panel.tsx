import React from 'react';
import { StyleProp, View, ViewStyle } from 'react-native';
import { useTheme } from '../theme/ThemeContext';

export default function Panel({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const th = useTheme();
  return (
    <View style={[{ backgroundColor: th.card, borderRadius: 20, padding: 14, borderWidth: 1, borderColor: th.border, shadowColor: '#20243A', shadowOpacity: 0.08, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 3 }, style]}>
      {children}
    </View>
  );
}
