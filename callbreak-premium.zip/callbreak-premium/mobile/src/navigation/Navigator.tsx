import React from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useTheme } from '../theme/ThemeContext';
import SplashScreen from '../screens/SplashScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import { LoginScreen, RegisterScreen } from '../screens/AuthScreens';
import HomeScreen from '../screens/HomeScreen';
import ModeSelectScreen from '../screens/ModeSelectScreen';
import MatchmakingScreen from '../screens/MatchmakingScreen';
import { PrivateRoomScreen, JoinRoomScreen } from '../screens/RoomScreens';
import TableScreen from '../screens/TableScreen';
import MatchResultsScreen from '../screens/MatchResultsScreen';
import LeaderboardScreen from '../screens/LeaderboardScreen';
import ProfileScreen from '../screens/ProfileScreen';
import RewardsScreen from '../screens/RewardsScreen';
import StoreScreen from '../screens/StoreScreen';
import SettingsScreen from '../screens/SettingsScreen';
import HistoryScreen from '../screens/HistoryScreen';
import HelpScreen from '../screens/HelpScreen';
import TournamentScreen from '../screens/TournamentScreen';

const Stack = createNativeStackNavigator();

export default function Navigator() {
  const th = useTheme();
  const base = th.dark ? DarkTheme : DefaultTheme;
  return (
    <NavigationContainer theme={{ ...base, colors: { ...base.colors, background: th.bg, card: th.card, text: th.text, primary: th.primary, border: th.border } }}>
      <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false, animation: 'fade', orientation: 'landscape' }}>
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ModeSelect" component={ModeSelectScreen} />
        <Stack.Screen name="Matchmaking" component={MatchmakingScreen} />
        <Stack.Screen name="PrivateRoom" component={PrivateRoomScreen} />
        <Stack.Screen name="JoinRoom" component={JoinRoomScreen} />
        <Stack.Screen name="Table" component={TableScreen} options={{ gestureEnabled: false, animation: 'fade' }} />
        <Stack.Screen name="MatchResults" component={MatchResultsScreen} options={{ gestureEnabled: false }} />
        <Stack.Screen name="Leaderboard" component={LeaderboardScreen} />
        <Stack.Screen name="Profile" component={ProfileScreen} />
        <Stack.Screen name="Rewards" component={RewardsScreen} />
        <Stack.Screen name="Store" component={StoreScreen} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
        <Stack.Screen name="History" component={HistoryScreen} />
        <Stack.Screen name="Help" component={HelpScreen} />
        <Stack.Screen name="Tournament" component={TournamentScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
