import { useApp } from '../store/useApp';

const dict: Record<string, Record<string, string>> = {
  en: {
    quick: 'Quick Play', friends: 'Play with Friends', private: 'Private Room', practice: 'Practice', tournament: 'Tournament',
    rewards: 'Rewards', missions: 'Missions', leaderboard: 'Leaderboard', history: 'History', store: 'Store', settings: 'Settings',
    play: 'Play', bid: 'Bid', welcome: 'Welcome', coins: 'Coins', level: 'Level',
  },
  hi: {
    quick: 'क्विक प्ले', friends: 'दोस्तों के साथ', private: 'प्राइवेट रूम', practice: 'अभ्यास', tournament: 'टूर्नामेंट',
    rewards: 'इनाम', missions: 'मिशन', leaderboard: 'लीडरबोर्ड', history: 'इतिहास', store: 'स्टोर', settings: 'सेटिंग्स',
    play: 'खेलें', bid: 'बिड', welcome: 'स्वागत है', coins: 'सिक्के', level: 'लेवल',
  },
  ne: {
    quick: 'छिटो खेल', friends: 'साथीसँग', private: 'निजी कोठा', practice: 'अभ्यास', tournament: 'प्रतियोगिता',
    rewards: 'पुरस्कार', missions: 'मिसन', leaderboard: 'लिडरबोर्ड', history: 'इतिहास', store: 'स्टोर', settings: 'सेटिङ',
    play: 'खेल्नुस्', bid: 'बिड', welcome: 'स्वागत छ', coins: 'सिक्का', level: 'स्तर',
  },
};
export const LANGS = [{ id: 'en', name: 'English' }, { id: 'hi', name: 'हिन्दी' }, { id: 'ne', name: 'नेपाली' }];
export function useT() {
  const lang = useApp((s) => s.settings.lang);
  return (k: string) => dict[lang]?.[k] ?? dict.en[k] ?? k;
}
