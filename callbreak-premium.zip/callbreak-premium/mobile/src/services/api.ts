import { io, Socket } from 'socket.io-client';
import { useApp } from '../store/useApp';

export const serverUrl = () => (useApp.getState().settings.server || process.env.EXPO_PUBLIC_SERVER_URL || '').trim().replace(/\/$/, '');
export const hasServer = () => !!serverUrl();

export async function api<T = any>(path: string, opts: { method?: string; body?: any; token?: string | null } = {}): Promise<T> {
  const url = serverUrl();
  if (!url) throw new Error('no-server');
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 7000);
  try {
    const res = await fetch(url + path, {
      method: opts.method || (opts.body ? 'POST' : 'GET'),
      headers: { 'Content-Type': 'application/json', ...(opts.token ? { Authorization: `Bearer ${opts.token}` } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      signal: ctl.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error || `http-${res.status}`);
    return data as T;
  } finally { clearTimeout(timer); }
}

let socket: Socket | null = null;
let socketUrl = '';
export function currentSocket() { return socket; }

/** Connects (or reuses) the game socket. Rejects when the server is unreachable. */
export function connectSocket(): Promise<Socket> {
  const url = serverUrl();
  if (!url) return Promise.reject(new Error('no-server'));
  if (socket && socketUrl === url && socket.connected) return Promise.resolve(socket);
  if (socket) { socket.removeAllListeners(); socket.disconnect(); }
  socketUrl = url;
  const token = useApp.getState().profile.token;
  const s = io(url, { transports: ['websocket'], auth: { token }, reconnection: true, reconnectionAttempts: Infinity, reconnectionDelay: 800, timeout: 6000 });
  socket = s;
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => { s.off('connect', ok); reject(new Error('timeout')); }, 7000);
    const ok = () => { clearTimeout(t); resolve(s); };
    s.once('connect', ok);
    s.once('connect_error', () => { /* socket.io keeps retrying; timeout rejects */ });
  });
}
export function closeSocket() { if (socket) { socket.removeAllListeners(); socket.disconnect(); socket = null; } }
