import { useEffect, useState } from 'react';
import { hasServer, serverUrl } from './api';

/** Real server latency (GET /health). Offline mode when no server is configured. */
export function usePing(): { online: boolean; ms: number | null } {
  const [st, setSt] = useState<{ online: boolean; ms: number | null }>({ online: false, ms: null });
  useEffect(() => {
    let alive = true;
    const run = async () => {
      if (!hasServer()) return alive && setSt({ online: false, ms: null });
      const t0 = Date.now();
      try {
        const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 5000);
        const r = await fetch(serverUrl() + '/health', { signal: ctl.signal }); clearTimeout(to);
        if (alive) setSt({ online: r.ok, ms: Date.now() - t0 });
      } catch { if (alive) setSt({ online: false, ms: null }); }
    };
    run(); const id = setInterval(run, 20000);
    return () => { alive = false; clearInterval(id); };
  }, []);
  return st;
}
