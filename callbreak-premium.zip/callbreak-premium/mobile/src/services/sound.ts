import { Audio, AVPlaybackSource } from 'expo-av';
import { useApp } from '../store/useApp';

const files: Record<string, AVPlaybackSource> = {
  click: require('../../assets/sounds/click.wav'),
  deal: require('../../assets/sounds/deal.wav'),
  play: require('../../assets/sounds/play.wav'),
  trick: require('../../assets/sounds/trick.wav'),
  victory: require('../../assets/sounds/victory.wav'),
  defeat: require('../../assets/sounds/defeat.wav'),
};
export type SfxName = 'click' | 'deal' | 'play' | 'trick' | 'victory' | 'defeat';
const cache: Record<string, Audio.Sound> = {};
let music: Audio.Sound | null = null;
let ready = false;

async function init() {
  if (ready) return;
  ready = true;
  try { await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, shouldDuckAndroid: true }); } catch {}
}

export async function sfx(name: SfxName) {
  const { sound, soundPack } = useApp.getState().settings;
  if (!sound) return;
  try {
    await init();
    let s = cache[name];
    if (!s) { s = (await Audio.Sound.createAsync(files[name])).sound; cache[name] = s; }
    const rate = soundPack === 'snd_soft' ? 0.82 : soundPack === 'snd_crisp' ? 1.25 : 1;
    await s.setRateAsync(rate, true);
    await s.replayAsync();
  } catch {}
}

export async function syncMusic() {
  const on = useApp.getState().settings.music;
  try {
    await init();
    if (on && !music) {
      const { sound } = await Audio.Sound.createAsync(require('../../assets/sounds/music.wav'), { isLooping: true, volume: 0.35, shouldPlay: true });
      music = sound;
    } else if (!on && music) {
      await music.stopAsync(); await music.unloadAsync(); music = null;
    }
  } catch {}
}
