import React from 'react';
import { FlatList, Text, View } from 'react-native';
import Screen from '../components/Screen';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';

export default function HistoryScreen() {
  const th = useTheme();
  const hist = useApp((s) => s.history);
  return (
    <Screen title="Game history">
      {!hist.length ? <Text style={{ color: th.sub, marginTop: 30, textAlign: 'center', fontWeight: '700' }}>No matches yet. Finish a game and it shows up here.</Text> : (
        <FlatList data={hist} keyExtractor={(h) => h.id} showsVerticalScrollIndicator={false} renderItem={({ item: h }) => (
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: th.card, borderRadius: 16, padding: 10, marginBottom: 6, borderWidth: 1, borderColor: th.border }}>
            <Text style={{ fontSize: 22, width: 40 }}>{h.rank === 1 ? '🏆' : h.rank === 2 ? '🥈' : h.rank === 3 ? '🥉' : '🎴'}</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: th.text, fontWeight: '800' }}>{h.rank === 1 ? 'Won' : `Finished #${h.rank}`} · {h.mode}</Text>
              <Text style={{ color: th.sub, fontSize: 11 }}>{new Date(h.date).toLocaleString()}</Text>
            </View>
            <Text style={{ color: th.sub, fontSize: 12, marginRight: 12 }}>{h.totals.map((t, i) => `${i === 0 ? 'You' : h.names[i]} ${t}`).join(' · ')}</Text>
          </View>
        )} />
      )}
    </Screen>
  );
}
