import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import Avatar from '../components/Avatar';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { closeSocket, connectSocket, currentSocket, hasServer } from '../services/api';
import { BOT_AVATARS, BOT_NAMES } from '../shared/constants';

const MAX_WAIT = 9000;
export default function MatchmakingScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const rp = (useRoute().params ?? {}) as any;
  const mode = (rp.mode ?? 'quick') as 'quick' | 'tournament';
  const variant = rp.variant ?? 'normal'; const rounds = rp.rounds ?? 5;
  const p = useApp((s) => s.profile);
  const [slots, setSlots] = useState<{ name: string; avatar: string; ai?: boolean }[]>([{ name: p.name, avatar: p.avatar }]);
  const [status, setStatus] = useState('Looking for players…');
  const started = useRef(false);

  useEffect(() => {
    let alive = true; const timers: ReturnType<typeof setTimeout>[] = [];
    const goOffline = () => {
      if (!alive || started.current) return; started.current = true;
      // AI replacement: fill the remaining seats, then start.
      setStatus('Adding AI players to start quickly…');
      let n = slots.length;
      [0, 1, 2].forEach((i) => timers.push(setTimeout(() => {
        if (!alive) return;
        setSlots((s) => [...s, { name: BOT_NAMES[(i + 2) % 8], avatar: BOT_AVATARS[(i + 2) % 8], ai: true }]);
        n++;
      }, 500 * (i + 1))));
      timers.push(setTimeout(() => alive && nav.replace('Table', { mode, level: 'intermediate', variant, rounds }), 2300));
    };
    (async () => {
      if (!hasServer()) { timers.push(setTimeout(goOffline, 1200)); return; }
      try {
        const s = await connectSocket();
        s.emit('quick:join', { ranked: mode === 'tournament', variant, rounds });
        s.on('room', (r: { players: { name: string; avatar: string; isBot: boolean }[] }) => alive && setSlots(r.players.map((x) => ({ name: x.name, avatar: x.avatar, ai: x.isBot }))));
        s.once('game:start', () => { if (!alive || started.current) return; started.current = true; nav.replace('Table', { mode, online: true, variant, rounds }); });
        timers.push(setTimeout(() => { if (!started.current) { s.emit('quick:cancel'); goOffline(); } }, MAX_WAIT + 4000));
      } catch { goOffline(); }
    })();
    return () => { alive = false; timers.forEach(clearTimeout); currentSocket()?.off('room'); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const cancel = () => { currentSocket()?.emit('quick:cancel'); started.current = true; nav.goBack(); };
  return (
    <Screen title={mode === 'tournament' ? 'Ranked match' : 'Quick match'} onBack={cancel}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Panel style={{ width: 520, alignItems: 'center' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}><ActivityIndicator color={th.primary} /><Text style={{ color: th.text, fontWeight: '900', fontSize: 17, marginLeft: 8 }}>{status}</Text></View>
          <View style={{ flexDirection: 'row', marginVertical: 16 }}>
            {[0, 1, 2, 3].map((i) => {
              const sl = slots[i];
              return (
                <View key={i} style={{ width: 100, alignItems: 'center' }}>
                  {sl ? <Avatar avatar={sl.avatar} size={56} /> : <View style={{ width: 56, height: 56, borderRadius: 28, borderWidth: 2, borderStyle: 'dashed', borderColor: th.border, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: th.sub, fontSize: 20 }}>?</Text></View>}
                  <Text style={{ color: th.text, fontWeight: '800', marginTop: 4 }} numberOfLines={1}>{sl ? (i === 0 ? 'You' : sl.name) : 'Searching'}</Text>
                  {sl?.ai ? <Text style={{ color: th.sub, fontSize: 10 }}>AI</Text> : null}
                </View>
              );
            })}
          </View>
          <Btn title="Cancel" variant="ghost" onPress={cancel} />
        </Panel>
      </View>
    </Screen>
  );
}
