import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';

const SLIDES = [
  { e: '🎯', t: 'Bid smart', d: 'Before each round, say how many tricks (1–13) you can win. Hit your bid to score; miss it and you lose that many points.' },
  { e: '♠️', t: 'Spades are trump', d: 'Follow the leading suit when you can. If you cannot, a spade beats every other suit. Highest trump wins the trick.' },
  { e: '🏆', t: 'Play, win, collect', d: 'Five rounds per match. Earn coins and XP, finish missions and unlock card skins, tables and avatars.' },
];
export default function OnboardingScreen() {
  const th = useTheme();
  const nav = useNavigation<any>();
  const [i, setI] = useState(0);
  const set = useApp((s) => s.setProfile);
  const finish = () => { set({ onboarded: true }); nav.reset({ index: 0, routes: [{ name: 'Login' }] }); };
  const sl = SLIDES[i];
  return (
    <Screen>
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontSize: 110, width: 200, textAlign: 'center' }}>{sl.e}</Text>
        <View style={{ width: 340 }}>
          <Text style={{ color: th.text, fontSize: 30, fontWeight: '900' }}>{sl.t}</Text>
          <Text style={{ color: th.sub, fontSize: 15, marginTop: 8, lineHeight: 22 }}>{sl.d}</Text>
          <View style={{ flexDirection: 'row', marginTop: 16, alignItems: 'center' }}>
            {SLIDES.map((_, k) => <View key={k} style={{ width: k === i ? 22 : 8, height: 8, borderRadius: 4, marginRight: 5, backgroundColor: k === i ? th.primary : th.border }} />)}
            <View style={{ flex: 1 }} />
            <Btn title="Skip" variant="ghost" size="sm" onPress={finish} style={{ marginRight: 8 }} />
            <Btn title={i === SLIDES.length - 1 ? "Let's play" : 'Next'} onPress={() => (i === SLIDES.length - 1 ? finish() : setI(i + 1))} />
          </View>
        </View>
      </View>
    </Screen>
  );
}
