import React, { useState } from 'react';
import { Image, ScrollView, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Avatar from '../components/Avatar';
import CardView, { CardBack } from '../components/CardView';
import { CoinPill, Tabs } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { CATALOG, Item, Kind, TIER_COLOR, VIP_PRICE } from '../theme/catalog';
import { tableImg } from '../theme/tables';

const TABS: { id: Kind | 'vip'; label: string }[] = [
  { id: 'vip', label: '👑 VIP' }, { id: 'cardTheme', label: 'Card faces' }, { id: 'cardBack', label: 'Card backs' }, { id: 'table', label: 'Tables' },
  { id: 'avatar', label: 'Avatars' }, { id: 'frame', label: 'Frames' }, { id: 'badge', label: 'Badges' }, { id: 'sound', label: 'Card sounds' },
];
function Preview({ it }: { it: Item }) {
  if (it.kind === 'cardTheme') return <View style={{ flexDirection: 'row' }}><CardView card={{ id: 'S14', suit: 'S', rank: 14 }} w={42} animate={false} theme={it.id} /><View style={{ marginLeft: -14 }}><CardView card={{ id: 'H12', suit: 'H', rank: 12 }} w={42} animate={false} theme={it.id} /></View></View>;
  if (it.kind === 'cardBack') return <CardBack w={46} back={it.id} />;
  if (it.kind === 'table') return <Image source={tableImg(it.id)} style={{ width: 104, height: 62, borderRadius: 12, borderWidth: 2, borderColor: 'rgba(255,255,255,0.5)' }} />;
  if (it.kind === 'avatar') return <Avatar avatar={it.id} size={52} />;
  if (it.kind === 'frame') return <Avatar avatar="av_cool" frame={it.id} size={52} animate={false} />;
  if (it.kind === 'badge') return <Text style={{ fontSize: 36 }}>{it.emoji}</Text>;
  return <Text style={{ fontSize: 36 }}>🔊</Text>;
}
export default function StoreScreen() {
  const th = useTheme();
  const p = useApp((s) => s.profile); const st = useApp((s) => s.settings);
  const buy = useApp((s) => s.buy); const equip = useApp((s) => s.equip); const buyVip = useApp((s) => s.buyVip);
  const [tab, setTab] = useState<string>('cardTheme'); const [msg, setMsg] = useState('');
  const equipped = (it: Item) => st.cardTheme === it.id || st.cardBack === it.id || st.table === it.id || st.soundPack === it.id || p.avatar === it.id || p.frame === it.id || p.badge === it.id;
  return (
    <Screen title="Premium store" right={<CoinPill coins={p.coins} />}>
      <Tabs tabs={TABS} value={tab} onChange={(t) => { setTab(t); setMsg(''); }} />
      <Text style={{ color: th.sub, fontSize: 11, marginBottom: 6 }}>Everything here is cosmetic and bought with virtual coins only. Nothing changes your chances of winning.</Text>
      {msg ? <Text style={{ color: th.accent, fontWeight: '800', marginBottom: 4 }}>{msg}</Text> : null}
      <ScrollView showsVerticalScrollIndicator={false}>
        {tab === 'vip' ? (
          <LinearGradient colors={['#FFC857', '#FF9F43']} style={{ borderRadius: 22, padding: 18 }}>
            <Text style={{ fontSize: 30 }}>👑</Text>
            <Text style={{ color: '#20243A', fontWeight: '900', fontSize: 22 }}>VIP Membership</Text>
            <Text style={{ color: '#20243A', marginTop: 4, lineHeight: 20 }}>Ad-free play · premium tournaments · advanced statistics · gold avatar ring and star badge · VIP name tag. Purely cosmetic and convenience perks – no gameplay advantage.</Text>
            <View style={{ marginTop: 12, flexDirection: 'row' }}>
              <Btn title={p.vip ? 'You are VIP' : `Unlock for 🪙 ${VIP_PRICE}`} variant="primary" disabled={p.vip} onPress={() => setMsg(buyVip() ? 'Welcome to VIP!' : 'Not enough coins yet – play matches and claim rewards.')} />
            </View>
          </LinearGradient>
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {CATALOG.filter((i) => i.kind === tab).map((it) => {
              const owned = p.owned.includes(it.id); const on = equipped(it);
              return (
                <View key={it.id} style={{ width: 150, marginRight: 8, marginBottom: 8, backgroundColor: th.card, borderRadius: 18, padding: 10, alignItems: 'center', borderWidth: 2, borderColor: on ? th.primary : th.border }}>
                  <View style={{ height: 74, alignItems: 'center', justifyContent: 'center' }}><Preview it={it} /></View>
                  <Text style={{ color: th.text, fontWeight: '800', fontSize: 12, marginTop: 4 }} numberOfLines={1}>{it.name}</Text>
                  <Text style={{ color: it.tier ? TIER_COLOR[it.tier] : th.sub, fontWeight: '900', fontSize: 10, marginBottom: 4 }}>{it.tier ? it.tier.toUpperCase() : ''}{it.vip ? ' · VIP' : ''}</Text>
                  {owned
                    ? <Btn size="sm" variant={on ? 'ghost' : 'turq'} title={on ? 'Equipped' : it.kind === 'badge' ? 'Wear' : 'Equip'} disabled={on && it.kind !== 'badge'} onPress={() => equip(it.id)} />
                    : <Btn size="sm" variant="gold" title={it.vip && !p.vip ? '👑 VIP only' : `🪙 ${it.price}`} disabled={!!it.vip && !p.vip} onPress={() => setMsg(buy(it.id) ? `${it.name} unlocked!` : 'Not enough coins yet.')} />}
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </Screen>
  );
}
