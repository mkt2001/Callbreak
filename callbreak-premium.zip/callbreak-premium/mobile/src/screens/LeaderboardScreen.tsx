import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Text, View } from 'react-native';
import Screen from '../components/Screen';
import Avatar from '../components/Avatar';
import { Tabs } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { useApp, levelInfo } from '../store/useApp';
import { api, hasServer } from '../services/api';
import { BOT_AVATARS, BOT_NAMES } from '../shared/constants';

export interface Entry { id: string; name: string; avatar: string; level: number; points: number; me?: boolean }
const TABS = [{ id: 'global', label: 'Global' }, { id: 'weekly', label: 'Weekly' }, { id: 'monthly', label: 'Monthly' }, { id: 'friends', label: 'Friends' }, { id: 'regional', label: 'Regional' }];

/** Offline sample board so the screen is never empty. Real data comes from the server. */
export function sampleBoard(scope: string, me: Entry): Entry[] {
  const scale = { global: 1, weekly: 0.18, monthly: 0.4, friends: 0.25, regional: 0.6 }[scope] ?? 1;
  const n = scope === 'friends' ? 5 : 20;
  const list: Entry[] = Array.from({ length: n }, (_, i) => ({
    id: 'bot' + i, name: BOT_NAMES[i % 8] + (i >= 8 ? i : ''), avatar: BOT_AVATARS[i % 8], level: Math.max(1, 30 - i), points: Math.round((4200 - i * 170) * scale),
  }));
  return [...list, me].sort((a, b) => b.points - a.points);
}
export default function LeaderboardScreen() {
  const th = useTheme();
  const p = useApp((s) => s.profile); const st = useApp((s) => s.stats);
  const [tab, setTab] = useState('global'); const [rows, setRows] = useState<Entry[]>([]); const [loading, setLoading] = useState(true); const [live, setLive] = useState(false);
  const me: Entry = { id: p.id || 'me', name: p.name, avatar: p.avatar, level: levelInfo(p.xp).level, points: st.wins * 25 + st.matches * 5, me: true };
  useEffect(() => {
    let alive = true; setLoading(true);
    (async () => {
      try {
        if (!hasServer()) throw new Error('no-server');
        const r = await api<{ rows: Entry[] }>(`/leaderboard?scope=${tab}`, { token: p.token });
        if (alive) { setRows(r.rows.map((x) => ({ ...x, me: x.id === p.id }))); setLive(true); }
      } catch { if (alive) { setRows(sampleBoard(tab, me)); setLive(false); } }
      finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, [tab]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <Screen title="Leaderboard">
      <Tabs tabs={TABS} value={tab} onChange={setTab} />
      {!live && !loading ? <Text style={{ color: th.sub, fontSize: 11, marginBottom: 4 }}>Sample rankings – connect a server for live boards.</Text> : null}
      {loading ? <ActivityIndicator color={th.primary} style={{ marginTop: 30 }} /> : (
        <FlatList data={rows} keyExtractor={(x) => x.id} showsVerticalScrollIndicator={false} renderItem={({ item, index }) => (
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: item.me ? (th.dark ? '#2F2A63' : '#EDE8FF') : th.card, borderRadius: 16, padding: 8, marginBottom: 6, borderWidth: 1, borderColor: item.me ? th.primary : th.border }}>
            <Text style={{ width: 40, textAlign: 'center', fontWeight: '900', color: th.text, fontSize: 16 }}>{index < 3 ? ['🥇', '🥈', '🥉'][index] : index + 1}</Text>
            <Avatar avatar={item.avatar} size={34} />
            <Text style={{ flex: 1, marginLeft: 10, color: th.text, fontWeight: '800' }}>{item.me ? `${item.name} (you)` : item.name}</Text>
            <Text style={{ color: th.sub, fontWeight: '700', width: 70 }}>Lv {item.level}</Text>
            <Text style={{ color: th.primary, fontWeight: '900', width: 80, textAlign: 'right' }}>{item.points.toLocaleString()}</Text>
          </View>
        )} />
      )}
    </Screen>
  );
}
