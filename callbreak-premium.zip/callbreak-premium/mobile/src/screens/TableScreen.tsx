import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, Vibration, View, useWindowDimensions, BackHandler } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp, levelInfo } from '../store/useApp';
import { byId } from '../theme/catalog';
import { useTheme } from '../theme/ThemeContext';
import { useOfflineGame } from '../game/useOfflineGame';
import { useOnlineGame } from '../game/useOnlineGame';
import { BiddingPanel, Hand, PlayerBadge, ScoreTable, TrickArea, TrumpChip, rel } from '../game/TableParts';
import { SUIT_SYMBOL } from '../shared/constants';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { sfx, syncMusic } from '../services/sound';
import { closeSocket, currentSocket } from '../services/api';
import type { GameParams } from '../game/types';
import type { PlayerView } from '../shared/types';

export default function TableScreen() {
  const nav = useNavigation<any>();
  const params = (useRoute().params ?? { mode: 'quick' }) as GameParams;
  const th = useTheme();
  const { width: W, height: H } = useWindowDimensions();
  const settings = useApp((s) => s.settings);
  const set = useApp((s) => s.set);
  const recordMatch = useApp((s) => s.recordMatch);

  const finish = useCallback((r: { totals: number[]; tricks: number; myBids: number[]; names: string[] }) => {
    const res = recordMatch({ mode: params.mode, ...r });
    setTimeout(() => {
      sfx(res.rank === 1 ? 'victory' : 'defeat');
      nav.replace('MatchResults', { ...r, ...res, mode: params.mode });
    }, 1400);
  }, [params.mode]); // eslint-disable-line react-hooks/exhaustive-deps

  const left = useCallback(() => nav.reset({ index: 0, routes: [{ name: 'Home' }] }), [nav]);
  const g = params.online
    ? useOnlineGame(finish, left)
    // eslint-disable-next-line react-hooks/rules-of-hooks
    : useOfflineGame(params.level ?? 'intermediate', !!params.hints, finish);

  const [selected, setSelected] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [board, setBoard] = useState(false);
  const [info, setInfo] = useState<PlayerView | null>(null);
  const [toast, setToast] = useState('');
  const [bidsBanner, setBidsBanner] = useState(false);
  const view = g.view;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { setMenu(true); return true; });
    return () => sub.remove();
  }, []);
  useEffect(() => { if (view?.turn !== view?.mySeat || view?.phase !== 'playing') setSelected(null); }, [view?.turn, view?.phase]);
  useEffect(() => {
    if (view?.phase === 'playing' && view.hand.length === 13 && view.trick.length === 0) {
      setBidsBanner(true); const t = setTimeout(() => setBidsBanner(false), 2600); return () => clearTimeout(t);
    }
  }, [view?.round, view?.phase === 'playing']); // eslint-disable-line react-hooks/exhaustive-deps

  const say = (m: string) => { setToast(m); setTimeout(() => setToast(''), 1600); };

  const onTap = (id: string) => {
    if (!view || view.phase !== 'playing' || view.turn !== view.mySeat || view.trickDone) return say('Wait for your turn');
    if (!view.legal.includes(id)) {
      if (settings.vibration) Vibration.vibrate(40);
      const lead = view.trick[0]?.card.suit;
      return say(lead ? `Follow ${SUIT_SYMBOL[lead]} or play a higher card if you can` : 'Illegal card');
    }
    if (selected === id) { g.play(id); setSelected(null); } else { sfx('click'); setSelected(id); }
  };

  const geo = useMemo(() => {
    const side = 118;
    const avail = Math.max(260, W - side * 2 - 12);
    const cardW = Math.max(40, Math.min(72, avail / 7, (H * 0.27) / 1.4));
    const handH = cardW * 1.4 + 24;
    return { side, avail, cardW, handH };
  }, [W, H]);

  if (!view) return <View style={{ flex: 1, backgroundColor: th.bg }} />;
  const my = view.mySeat;
  const bySeatRel = (r: number) => view.players.find((p) => rel(p.seat, my) === r)!;
  const tableColors = (byId(settings.table).colors ?? ['#1E8F6A', '#176B50']) as [string, string];
  const myTurn = view.turn === my;
  const turnName = view.players[view.turn].name;
  const winnerName = view.lastTrickWinner !== null ? (view.lastTrickWinner === my ? 'You' : view.players[view.lastTrickWinner].name) : undefined;
  const status = view.phase === 'bidding' ? '' : view.trickDone ? '' : myTurn ? 'Your turn — tap a card, tap again to play' : `${turnName}'s turn`;

  const quit = () => {
    setMenu(false);
    if (params.online) { currentSocket()?.emit('room:leave'); closeSocket(); }
    left();
  };
  const badge = (r: number, style: any) => {
    const p = bySeatRel(r);
    return <View key={r} style={style}><PlayerBadge p={p} my={my} active={view.turn === p.seat && (view.phase === 'bidding' || (view.phase === 'playing' && !view.trickDone))} deadline={view.deadline} onPress={() => setInfo(p)} compact={H < 340} /></View>;
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0E1A2B' }}>
      <LinearGradient colors={[th.dark ? '#14172B' : '#2A2F55', '#0E1A2B']} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom', 'left', 'right']}>
        {/* felt */}
        <LinearGradient colors={tableColors} style={[s.felt, { left: geo.side, right: geo.side, top: 54, bottom: geo.handH + 6 }]}>
          <View style={s.feltRing} />
          <View style={{ position: 'absolute', top: 8, left: 12 }}><TrumpChip /></View>
          <View style={{ position: 'absolute', top: 8, right: 12, flexDirection: 'row' }}>
            <View style={s.chip}><Text style={s.chipTxt}>Round {view.round}/{view.rounds}</Text></View>
          </View>
          {bidsBanner && (
            <View style={[s.chip, { position: 'absolute', top: 34, flexDirection: 'row', paddingHorizontal: 12 }]}>
              <Text style={s.chipTxt}>Bids: {view.players.map((p) => `${p.seat === my ? 'You' : p.name} ${p.bid}`).join('  ·  ')}</Text>
            </View>
          )}
          {view.phase === 'playing' || view.phase === 'roundEnd' || view.phase === 'matchEnd'
            ? <TrickArea view={view} w={Math.min(48, geo.cardW * 0.8)} winnerName={winnerName} />
            : <BiddingPanel view={view} hintBid={g.hintBid} onBid={g.bid} nameOfTurn={turnName} />}
          {status ? <Text style={s.status}>{status}</Text> : null}
          {toast ? <View style={s.toast}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{toast}</Text></View> : null}
        </LinearGradient>

        {/* top bar */}
        <View style={s.topLeft}>
          <Pressable style={s.iconBtn} onPress={() => { sfx('click'); setMenu(true); }}><Text style={s.icon}>☰</Text></Pressable>
          <Pressable style={s.iconBtn} onPress={() => { set({ sound: !settings.sound }); }}><Text style={s.icon}>{settings.sound ? '🔊' : '🔇'}</Text></Pressable>
        </View>
        <View style={s.topRight}>
          {!g.connected && <View style={[s.chip, { backgroundColor: '#E5484D', marginRight: 6 }]}><Text style={s.chipTxt}>Reconnecting…</Text></View>}
          <Pressable style={s.iconBtn} onPress={() => { sfx('click'); setBoard(true); }}><Text style={s.icon}>📊</Text></Pressable>
        </View>

        {/* opponents */}
        {badge(2, { position: 'absolute', top: 6, alignSelf: 'center' })}
        {badge(1, { position: 'absolute', left: 6, top: '38%' })}
        {badge(3, { position: 'absolute', right: 6, top: '38%' })}

        {/* me */}
        <View style={{ position: 'absolute', left: 6, bottom: 8 }}>
          <PlayerBadge p={bySeatRel(0)} my={my} active={myTurn && view.phase !== 'roundEnd'} deadline={view.deadline} onPress={() => setInfo(bySeatRel(0))} compact />
        </View>
        <View style={{ position: 'absolute', bottom: 4, left: 0, right: 0, alignItems: 'center' }} pointerEvents="box-none">
          <Hand view={view} cardW={geo.cardW} selected={selected} hintCard={g.hintCard} onTap={onTap} animate={settings.animations} avail={geo.avail} />
        </View>
        <View style={{ position: 'absolute', right: 8, bottom: 14, width: geo.side - 14 }}>
          <Btn title="Play card" variant="gold" disabled={!selected || !(view.phase === 'playing' && myTurn && !view.trickDone)} onPress={() => { if (selected) { g.play(selected); setSelected(null); } }} />
        </View>

        {/* round results */}
        <Modal visible={view.phase === 'roundEnd'} transparent animationType="fade">
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ minWidth: 420 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Round {view.round} complete</Text>
              <ScoreTable view={view} />
              <View style={{ marginTop: 10, alignItems: 'center' }}>
                {params.online ? <Text style={{ color: th.sub, fontWeight: '700' }}>Next round starts automatically…</Text> : <Btn title="Next round" variant="gold" onPress={g.nextRound} />}
              </View>
            </Panel>
          </View>
        </Modal>
        {/* scoreboard */}
        <Modal visible={board} transparent animationType="fade" onRequestClose={() => setBoard(false)}>
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ minWidth: 420 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Scoreboard</Text>
              <ScoreTable view={view} />
              <View style={{ marginTop: 10, alignItems: 'center' }}><Btn title="Close" size="sm" onPress={() => setBoard(false)} /></View>
            </Panel>
          </View>
        </Modal>
        {/* game menu */}
        <Modal visible={menu} transparent animationType="fade" onRequestClose={() => setMenu(false)}>
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ width: 320 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Game menu</Text>
              <Btn title="Resume" onPress={() => setMenu(false)} style={s.mBtn} />
              <Btn title={settings.sound ? 'Sound: On' : 'Sound: Off'} variant="ghost" onPress={() => set({ sound: !settings.sound })} style={s.mBtn} />
              <Btn title={settings.music ? 'Music: On' : 'Music: Off'} variant="ghost" onPress={() => { set({ music: !settings.music }); setTimeout(syncMusic, 50); }} style={s.mBtn} />
              <Btn title="Scoreboard" variant="ghost" onPress={() => { setMenu(false); setBoard(true); }} style={s.mBtn} />
              <Btn title="Leave game" variant="danger" onPress={quit} style={s.mBtn} />
            </Panel>
          </View>
        </Modal>
        {/* player info */}
        <Modal visible={!!info} transparent animationType="fade" onRequestClose={() => setInfo(null)}>
          <Pressable style={[s.modal, { backgroundColor: th.overlay }]} onPress={() => setInfo(null)}>
            {info && (
              <Panel style={{ width: 260, alignItems: 'center' }}>
                <Text style={{ fontSize: 40 }}>{info.avatar.startsWith('av_') ? byId(info.avatar).emoji : info.avatar}</Text>
                <Text style={[s.mTitle, { color: th.text }]}>{info.seat === my ? 'You' : info.name}</Text>
                <Text style={{ color: th.sub }}>{info.isBot ? 'AI opponent' : 'Human player'}{info.seat === my ? ` · Level ${levelInfo(useApp.getState().profile.xp).level}` : ''}</Text>
                <Text style={{ color: th.text, marginTop: 6, fontWeight: '700' }}>Bid {info.bid ?? '–'} · Won {info.tricksWon} · Score {info.score}</Text>
              </Panel>
            )}
          </Pressable>
        </Modal>
      </SafeAreaView>
    </View>
  );
}
const s = StyleSheet.create({
  felt: { position: 'absolute', borderRadius: 120, alignItems: 'center', justifyContent: 'center', borderWidth: 6, borderColor: 'rgba(255,255,255,0.14)', overflow: 'hidden' },
  feltRing: { position: 'absolute', left: 14, right: 14, top: 14, bottom: 14, borderRadius: 110, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.18)' },
  chip: { backgroundColor: 'rgba(32,36,58,0.62)', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 },
  chipTxt: { color: '#fff', fontWeight: '800', fontSize: 12 },
  status: { position: 'absolute', bottom: 8, color: '#fff', fontWeight: '800', fontSize: 12, backgroundColor: 'rgba(0,0,0,0.28)', paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
  toast: { position: 'absolute', bottom: 34, backgroundColor: 'rgba(229,72,77,0.92)', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999 },
  topLeft: { position: 'absolute', top: 6, left: 6, flexDirection: 'row' },
  topRight: { position: 'absolute', top: 6, right: 6, flexDirection: 'row', alignItems: 'center' },
  iconBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center', marginRight: 6 },
  icon: { color: '#fff', fontSize: 15 },
  modal: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  mTitle: { fontSize: 18, fontWeight: '900', marginBottom: 8, textAlign: 'center' },
  mBtn: { marginTop: 8 },
});
