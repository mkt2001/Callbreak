import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, Vibration, View, useWindowDimensions, BackHandler } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp, levelInfo } from '../store/useApp';
import { byId } from '../theme/catalog';
import { useTheme } from '../theme/ThemeContext';
import { useOfflineGame } from '../game/useOfflineGame';
import { useOnlineGame } from '../game/useOnlineGame';
import { BiddingPanel, Hand, MyPill, OppBlock, ScoreTable, ShuffleDeal, TrickArea, rel } from '../game/TableParts';
import { SUIT_SYMBOL } from '../shared/constants';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { DarkPill, GreenBtn, Wood, WoodIcon } from '../components/wood';
import { sfx, syncMusic } from '../services/sound';
import { closeSocket, currentSocket } from '../services/api';
import { autoSelectCard } from '../game/autoSelect';
import type { GameParams } from '../game/types';
import type { PlayerView } from '../shared/types';

const VARIANT_LABEL = { normal: '', super8: 'Super 8', blind: 'Blind Bid' } as const;

export default function TableScreen() {
  const nav = useNavigation<any>();
  const params = (useRoute().params ?? { mode: 'quick' }) as GameParams;
  const th = useTheme();
  const { width: W, height: H } = useWindowDimensions();
  const settings = useApp((s) => s.settings);
  const set = useApp((s) => s.set);
  const recordMatch = useApp((s) => s.recordMatch);

  const finish = useCallback((r: { totals: number[]; tricks: number; myBids: number[]; names: string[] }) => {
    const res = recordMatch({ mode: params.mode, ...r });
    setTimeout(() => {
      sfx(res.rank === 1 ? 'victory' : 'defeat');
      nav.replace('MatchResults', { ...r, ...res, mode: params.mode, variant: params.variant, rounds: params.rounds, level: params.level });
    }, 1400);
  }, [params.mode]); // eslint-disable-line react-hooks/exhaustive-deps

  const left = useCallback(() => nav.reset({ index: 0, routes: [{ name: 'Home' }] }), [nav]);
  const [dealing, setDealing] = useState(true);
  const cfg = useMemo(() => ({ variant: params.variant ?? 'normal', rounds: params.rounds ?? 5 }), [params.variant, params.rounds]);
  const g = params.online
    ? useOnlineGame(finish, left)
    // eslint-disable-next-line react-hooks/rules-of-hooks
    : useOfflineGame(params.level ?? 'intermediate', !!params.hints, finish, cfg, dealing);

  const [selected, setSelected] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [board, setBoard] = useState(false);
  const [info, setInfo] = useState<PlayerView | null>(null);
  const [toast, setToast] = useState('');
  const [bidsBanner, setBidsBanner] = useState(false);
  const lastRound = useRef(0);
  const view = g.view;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { setMenu(true); return true; });
    return () => sub.remove();
  }, []);
  // every new round starts with the shuffle + deal animation
  useEffect(() => {
    if (!view || view.round === lastRound.current) return;
    lastRound.current = view.round; setDealing(true);
  }, [view?.round]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (dealing && !settings.animations) setDealing(false); }, [dealing, settings.animations]);

  useEffect(() => { if (view?.turn !== view?.mySeat || view?.phase !== 'playing') setSelected(null); }, [view?.turn, view?.phase]);
  // Auto-select when someone else has led. When I lead, nothing is selected and I choose manually.
  useEffect(() => {
    if (!view) return;
    if (view.phase === 'playing' && view.turn === view.mySeat && !view.trickDone) setSelected(settings.autoSelect ? autoSelectCard(view) : null);
  }, [view?.turn, view?.trick.length, view?.phase, view?.round, view?.trickDone]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!dealing && view?.phase === 'playing' && view.hand.length === 13 && view.trick.length === 0 && view.variant !== 'blind') {
      setBidsBanner(true); const t = setTimeout(() => setBidsBanner(false), 2600); return () => clearTimeout(t);
    }
  }, [view?.round, view?.phase === 'playing', dealing]); // eslint-disable-line react-hooks/exhaustive-deps

  const say = (m: string) => { setToast(m); setTimeout(() => setToast(''), 1600); };
  const onTap = (id: string) => {
    if (!view || view.phase !== 'playing' || view.turn !== view.mySeat || view.trickDone) return say('Wait for your turn');
    if (!view.legal.includes(id)) {
      if (settings.vibration) Vibration.vibrate(40);
      const lead = view.trick[0]?.card.suit;
      return say(lead ? `Follow ${SUIT_SYMBOL[lead]} or play a higher card if you can` : 'Illegal card');
    }
    if (selected === id) { g.play(id); setSelected(null); } else { sfx('click'); setSelected(id); }
  };

  const geo = useMemo(() => {
    const cardW = Math.max(44, Math.min(92, W * 0.092, (H * 0.33) / 1.4));
    const cardH = cardW * 1.4;
    const handTop = H - cardH * 0.9;
    const trickW = Math.max(38, Math.min(58, (handTop - 110) / (1.4 * 1.9)));
    return { cardW, cardH, handTop, trickW, avail: W * 0.9, centerY: (104 + handTop) / 2 };
  }, [W, H]);

  if (!view) return <Wood table={settings.table}><View style={{ flex: 1 }} /></Wood>;
  const my = view.mySeat;
  const bySeatRel = (r: number) => view.players.find((p) => rel(p.seat, my) === r)!;
  const myTurn = view.turn === my;
  const turnName = view.players[view.turn].name;
  const winnerName = view.lastTrickWinner !== null ? (view.lastTrickWinner === my ? 'You' : view.players[view.lastTrickWinner].name) : undefined;
  const status = view.phase === 'bidding' ? '' : view.trickDone ? '' : myTurn
    ? (selected && view.trick.length ? 'Card auto-selected — tap it again (or Play) to throw' : 'Your turn — tap a card, tap again to play') : `${turnName}'s turn`;
  const active = (p: PlayerView) => view.turn === p.seat && (view.phase === 'bidding' || (view.phase === 'playing' && !view.trickDone));
  const quit = () => {
    setMenu(false);
    if (params.online) { currentSocket()?.emit('room:leave'); closeSocket(); }
    left();
  };
  const oppSize = H < 340 ? 46 : 56;
  const bidW = Math.min(540, W * 0.66);
  const showBid = !dealing && view.phase === 'bidding';
  const showTrick = !dealing && view.phase !== 'bidding';
  const variantLabel = VARIANT_LABEL[view.variant];

  return (
    <Wood table={settings.table}>
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom', 'left', 'right']}>
        {/* round + trump chips (tap for scoreboard) */}
        <View style={{ position: 'absolute', top: 6, left: 10 }}>
          <Pressable onPress={() => { sfx('click'); setBoard(true); }}>
            <DarkPill style={{ borderRadius: 14, paddingVertical: 6 }}>
              <Text style={{ fontSize: 18, marginRight: 6 }}>📋</Text>
              <View><Text style={s.chipSmall}>Round</Text><Text style={s.chipBig}>{view.round}/{view.rounds}</Text></View>
            </DarkPill>
          </Pressable>
          <View style={{ flexDirection: 'row', marginTop: 4 }}>
            <DarkPill style={{ paddingVertical: 3 }}><Text style={s.chipSmall}>♠ Trump</Text></DarkPill>
            {variantLabel ? <DarkPill style={{ paddingVertical: 3, marginLeft: 4 }}><Text style={s.chipSmall}>{variantLabel}</Text></DarkPill> : null}
          </View>
        </View>
        <View style={{ position: 'absolute', top: 6, right: 10, flexDirection: 'row', alignItems: 'center' }}>
          {!g.connected && <DarkPill style={{ backgroundColor: '#B3261E', marginRight: 6 }}><Text style={s.chipSmall}>Reconnecting…</Text></DarkPill>}
          <WoodIcon icon="⚙️" size={42} onPress={() => setMenu(true)} />
        </View>

        {/* opponents with fanned card backs */}
        <View style={{ position: 'absolute', top: 4, left: 0, right: 0, alignItems: 'center' }} pointerEvents="box-none">
          <OppBlock p={bySeatRel(2)} r={2} active={active(bySeatRel(2))} deadline={view.deadline} count={dealing ? 0 : bySeatRel(2).cards} size={oppSize} onPress={() => setInfo(bySeatRel(2))} />
        </View>
        <View style={{ position: 'absolute', left: 10, top: H * 0.27 }}>
          <OppBlock p={bySeatRel(1)} r={1} active={active(bySeatRel(1))} deadline={view.deadline} count={dealing ? 0 : bySeatRel(1).cards} size={oppSize} onPress={() => setInfo(bySeatRel(1))} />
        </View>
        <View style={{ position: 'absolute', right: 10, top: H * 0.27 }}>
          <OppBlock p={bySeatRel(3)} r={3} active={active(bySeatRel(3))} deadline={view.deadline} count={dealing ? 0 : bySeatRel(3).cards} size={oppSize} onPress={() => setInfo(bySeatRel(3))} />
        </View>

        {/* centre: trick cards or bidding */}
        {showTrick && (
          <View style={{ position: 'absolute', left: W / 2 - geo.trickW * 2, top: geo.centerY - geo.trickW * 1.4 * 0.95 }} pointerEvents="none">
            <TrickArea view={view} w={geo.trickW} winnerName={winnerName} />
          </View>
        )}
        {showBid && (
          <View style={{ position: 'absolute', left: W / 2 - bidW / 2, top: Math.max(66, H * 0.2), alignItems: 'center', width: bidW }}>
            <BiddingPanel view={view} hintBid={g.hintBid} onBid={g.bid} nameOfTurn={turnName} width={bidW} />
          </View>
        )}
        {bidsBanner && (
          <DarkPill style={{ position: 'absolute', top: 104, alignSelf: 'center' }}>
            <Text style={s.chipSmall}>Bids: {view.players.map((p) => `${p.seat === my ? 'You' : p.name} ${p.bid ?? '–'}`).join('  ·  ')}</Text>
          </DarkPill>
        )}
        {!dealing && status ? <DarkPill style={{ position: 'absolute', alignSelf: 'center', top: geo.handTop - 34 }}><Text style={s.chipSmall}>{status}</Text></DarkPill> : null}
        {toast ? <View style={[s.toast, { top: geo.handTop - 66 }]}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{toast}</Text></View> : null}

        {/* my hand – big overlapping cards, slightly cropped at the bottom edge */}
        {!dealing && (
          <>
            <View style={{ position: 'absolute', left: 0, right: 0, bottom: -geo.cardH * 0.1, alignItems: 'center' }} pointerEvents="box-none">
              <Hand view={view} cardW={geo.cardW} selected={selected} hintCard={g.hintCard} onTap={onTap} animate={settings.animations} avail={geo.avail} />
            </View>
            <View style={{ position: 'absolute', left: 10, bottom: geo.cardH * 0.78 }}>
              <MyPill p={bySeatRel(0)} active={myTurn && view.phase !== 'roundEnd'} deadline={view.deadline} onPress={() => setInfo(bySeatRel(0))} />
            </View>
            <View style={{ position: 'absolute', right: 12, bottom: geo.cardH * 0.82, width: 110 }}>
              <GreenBtn title="PLAY" disabled={!selected || !(view.phase === 'playing' && myTurn && !view.trickDone)} onPress={() => { if (selected) { g.play(selected); setSelected(null); } }} />
            </View>
          </>
        )}

        {dealing && settings.animations && <ShuffleDeal W={W} H={H} cardW={geo.cardW} onDone={() => setDealing(false)} />}

        {/* round results */}
        <Modal visible={view.phase === 'roundEnd'} transparent animationType="fade">
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ minWidth: 420 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Round {view.round} complete</Text>
              <ScoreTable view={view} />
              <View style={{ marginTop: 10, alignItems: 'center' }}>
                {params.online ? <Text style={{ color: th.sub, fontWeight: '700' }}>Next round starts automatically…</Text> : <Btn title="Next round" variant="gold" onPress={g.nextRound} />}
              </View>
            </Panel>
          </View>
        </Modal>
        {/* scoreboard */}
        <Modal visible={board} transparent animationType="fade" onRequestClose={() => setBoard(false)}>
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ minWidth: 420 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Scoreboard</Text>
              <ScoreTable view={view} />
              <View style={{ marginTop: 10, alignItems: 'center' }}><Btn title="Close" size="sm" onPress={() => setBoard(false)} /></View>
            </Panel>
          </View>
        </Modal>
        {/* game menu */}
        <Modal visible={menu} transparent animationType="fade" onRequestClose={() => setMenu(false)}>
          <View style={[s.modal, { backgroundColor: th.overlay }]}>
            <Panel style={{ width: 320 }}>
              <Text style={[s.mTitle, { color: th.text }]}>Game menu</Text>
              <Btn title="Resume" onPress={() => setMenu(false)} style={s.mBtn} />
              <Btn title={settings.sound ? 'Sound: On' : 'Sound: Off'} variant="ghost" onPress={() => set({ sound: !settings.sound })} style={s.mBtn} />
              <Btn title={settings.music ? 'Music: On' : 'Music: Off'} variant="ghost" onPress={() => { set({ music: !settings.music }); setTimeout(syncMusic, 50); }} style={s.mBtn} />
              <Btn title="Scoreboard" variant="ghost" onPress={() => { setMenu(false); setBoard(true); }} style={s.mBtn} />
              <Btn title="Leave game" variant="danger" onPress={quit} style={s.mBtn} />
            </Panel>
          </View>
        </Modal>
        {/* player info */}
        <Modal visible={!!info} transparent animationType="fade" onRequestClose={() => setInfo(null)}>
          <Pressable style={[s.modal, { backgroundColor: th.overlay }]} onPress={() => setInfo(null)}>
            {info && (
              <Panel style={{ width: 260, alignItems: 'center' }}>
                <Text style={{ fontSize: 40 }}>{info.avatar.startsWith('av_') ? byId(info.avatar).emoji : info.avatar}</Text>
                <Text style={[s.mTitle, { color: th.text }]}>{info.seat === my ? 'You' : info.name}</Text>
                <Text style={{ color: th.sub }}>{info.isBot ? 'AI opponent' : 'Human player'}{info.seat === my ? ` · Level ${levelInfo(useApp.getState().profile.xp).level}` : ''}</Text>
                <Text style={{ color: th.text, marginTop: 6, fontWeight: '700' }}>Bid {info.bidHidden ? '?' : info.bid ?? '–'} · Won {info.tricksWon} · Score {info.score}</Text>
              </Panel>
            )}
          </Pressable>
        </Modal>
      </SafeAreaView>
    </Wood>
  );
}
const s = StyleSheet.create({
  chipSmall: { color: '#fff', fontWeight: '800', fontSize: 11 },
  chipBig: { color: '#FFD08A', fontWeight: '900', fontSize: 15, lineHeight: 16 },
  toast: { position: 'absolute', alignSelf: 'center', backgroundColor: 'rgba(179,38,30,0.94)', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999 },
  modal: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  mTitle: { fontSize: 18, fontWeight: '900', marginBottom: 8, textAlign: 'center' },
  mBtn: { marginTop: 8 },
});
