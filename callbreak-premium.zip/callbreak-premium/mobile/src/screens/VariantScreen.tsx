import React, { useState } from 'react';
import { Alert, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { DarkPill, GreenBtn, ProfilePill, Wood, WoodCard, WoodIcon } from '../components/wood';
import { useApp } from '../store/useApp';
import { sfx } from '../services/sound';

type Variant = 'normal' | 'super8' | 'blind';
const VARIANTS: { id: Variant; e: string; t: string; d: string; info: string }[] = [
  { id: 'normal', e: '♠️♥️', t: 'Normal', d: 'A classic Callbreak with standard rules.', info: 'Bid 1–13 tricks, spades are trump, follow suit. Hit your bid to score it (+0.1 per extra trick), miss it and lose the bid.' },
  { id: 'super8', e: '8️⃣', t: 'Super 8 Bid', d: 'Win all 8 hands every round.', info: 'No bidding: everyone is automatically committed to 8 tricks each round. Win 8 or more to score 8 (+0.1 per extra), win fewer and lose 8.' },
  { id: 'blind', e: '🙈', t: 'Blind Bid', d: "Everyone's bids stay secret until the round ends.", info: 'You still bid, but other players\' bids are hidden during play and revealed when the round finishes. No reading the table!' },
];
const LEVELS = [{ id: 'beginner', l: 'Easy' }, { id: 'intermediate', l: 'Medium' }, { id: 'expert', l: 'Expert' }] as const;
const TITLE = { practice: 'Practice', online: 'Play Online', private: 'Play Privately' } as const;

export default function VariantScreen() {
  const nav = useNavigation<any>();
  const { height: H } = useWindowDimensions();
  const target = ((useRoute().params as any)?.target ?? 'practice') as keyof typeof TITLE;
  const p = useApp((s) => s.profile);
  const [rounds, setRounds] = useState<3 | 5>(5);
  const [level, setLevel] = useState<'beginner' | 'intermediate' | 'expert'>('intermediate');
  const [hints, setHints] = useState(true);

  const play = (variant: Variant) => {
    if (target === 'practice') nav.navigate('Table', { mode: 'practice', variant, rounds, level, hints });
    else if (target === 'online') nav.navigate('Matchmaking', { mode: 'quick', variant, rounds });
    else nav.navigate('PrivateRoom', { variant, rounds });
  };
  const cardH = Math.max(150, Math.min(210, H - 190));
  const Check = ({ on, label }: { on: boolean; label: string }) => (
    <Pressable onPress={() => { sfx('click'); setRounds(label.startsWith('5') ? 5 : 3); }} style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: 12 }}>
      <View style={{ width: 34, height: 28, borderRadius: 9, borderWidth: 3, borderColor: '#E39A55', backgroundColor: 'rgba(0,0,0,0.12)', alignItems: 'center', justifyContent: 'center' }}>
        {on ? <View style={{ width: 22, height: 17, borderRadius: 5, backgroundColor: '#35D81A' }} /> : null}
      </View>
      <Text style={{ color: '#fff', fontSize: 20, fontWeight: '700', marginLeft: 8 }}>{label}</Text>
    </Pressable>
  );
  return (
    <Wood>
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom', 'left', 'right']}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 16, paddingTop: 6 }}>
          <ProfilePill name={p.name} avatar={p.avatar} frame={p.frame} coins={p.coins} vip={p.vip} onProfile={() => nav.navigate('Profile')} onPlus={() => nav.navigate('Store')} />
          <View style={{ flex: 1, alignItems: 'center', paddingTop: 6 }}><DarkPill style={{ paddingHorizontal: 18 }}><Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>{TITLE[target]}</Text></DarkPill></View>
          <View style={{ flexDirection: 'row' }}>
            <WoodIcon icon="📖" onPress={() => nav.navigate('Help')} />
            <WoodIcon icon="✖️" onPress={() => nav.goBack()} />
          </View>
        </View>

        <View style={{ alignItems: 'center', marginTop: 4 }}>
          <View style={{ flexDirection: 'row', backgroundColor: 'rgba(70,28,18,0.85)', borderRadius: 20, paddingVertical: 8, paddingHorizontal: 12, borderWidth: 2, borderColor: 'rgba(40,10,10,0.8)' }}>
            <Check on={rounds === 5} label="5 Round" />
            <View style={{ width: 1, backgroundColor: 'rgba(255,255,255,0.25)' }} />
            <Check on={rounds === 3} label="3 Round" />
          </View>
        </View>

        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ flexDirection: 'row' }}>
            {VARIANTS.map((v) => (
              <WoodCard key={v.id} style={{ width: 196, height: cardH, marginHorizontal: 8 }}>
                <View style={{ height: cardH - 6, alignItems: 'center', padding: 10 }}>
                  <Pressable onPress={() => Alert.alert(v.t, v.info)} style={{ position: 'absolute', top: 8, right: 8, width: 22, height: 22, borderRadius: 11, backgroundColor: '#F5DDB0', alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: '#7A3B22', fontWeight: '900', fontSize: 13 }}>i</Text>
                  </Pressable>
                  <Text style={{ fontSize: cardH * 0.24, marginTop: 4 }}>{v.e}</Text>
                  <Text style={{ color: '#fff', fontWeight: '900', fontSize: 20, marginTop: 2, textShadowColor: 'rgba(0,0,0,0.35)', textShadowRadius: 3 }}>{v.t}</Text>
                  <Text style={{ color: 'rgba(255,228,205,0.95)', fontSize: 11.5, textAlign: 'center', marginTop: 2, flex: 1 }}>{v.d}</Text>
                  <GreenBtn title="PLAY" onPress={() => play(v.id)} />
                </View>
              </WoodCard>
            ))}
          </View>
        </View>

        {target === 'practice' ? (
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingBottom: 8 }}>
            {LEVELS.map((l) => (
              <Pressable key={l.id} onPress={() => { sfx('click'); setLevel(l.id); }} style={{ marginHorizontal: 4, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 999, backgroundColor: level === l.id ? '#FFC857' : 'rgba(58,34,22,0.82)' }}>
                <Text style={{ color: level === l.id ? '#3B2A0A' : '#fff', fontWeight: '800', fontSize: 12 }}>{l.l}</Text>
              </Pressable>
            ))}
            <Pressable onPress={() => { sfx('click'); setHints(!hints); }} style={{ marginLeft: 10, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 999, backgroundColor: hints ? '#35D81A' : 'rgba(58,34,22,0.82)' }}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>💡 Hints {hints ? 'ON' : 'OFF'}</Text>
            </Pressable>
          </View>
        ) : target === 'private' ? (
          <View style={{ alignItems: 'center', paddingBottom: 8 }}>
            <Pressable onPress={() => { sfx('click'); nav.navigate('JoinRoom'); }} style={{ paddingHorizontal: 18, paddingVertical: 7, borderRadius: 999, backgroundColor: 'rgba(58,34,22,0.82)' }}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>Have a room code? Join a room ›</Text>
            </Pressable>
          </View>
        ) : null}
      </SafeAreaView>
    </Wood>
  );
}
