import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import Logo from '../components/Logo';
import { CardBack } from '../components/CardView';
import { useApp, useHydrated } from '../store/useApp';
import { BRAND } from '../theme/colors';

export default function SplashScreen() {
  const nav = useNavigation<any>();
  const hydrated = useHydrated();
  const bar = useRef(new Animated.Value(0)).current;
  const fan = useRef(new Animated.Value(0)).current;
  const done = useRef(false);

  useEffect(() => {
    Animated.timing(bar, { toValue: 1, duration: 2400, useNativeDriver: false }).start();
    Animated.spring(fan, { toValue: 1, friction: 6, tension: 40, useNativeDriver: true }).start();
  }, [bar, fan]);

  useEffect(() => {
    if (!hydrated) return;
    const t = setTimeout(() => {
      if (done.current) return; done.current = true;
      const p = useApp.getState().profile;
      nav.reset({ index: 0, routes: [{ name: !p.onboarded ? 'Onboarding' : !p.loggedIn ? 'Login' : 'Home' }] });
    }, 2600);
    return () => clearTimeout(t);
  }, [hydrated, nav]);

  const rot = (deg: number) => fan.interpolate({ inputRange: [0, 1], outputRange: ['0deg', `${deg}deg`] });
  return (
    <LinearGradient colors={['#20243A', '#3B2A8C', '#0F7F6E']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.root}>
      <View style={s.row}>
        <View style={s.fanWrap}>
          {[-18, 0, 18].map((d, i) => (
            <Animated.View key={d} style={{ position: 'absolute', transform: [{ rotate: rot(d) }, { translateY: 8 }] , zIndex: i }}>
              <CardBack w={70} back={['back_gold', 'back_purple', 'back_crimson'][i]} />
            </Animated.View>
          ))}
        </View>
        <View style={{ alignItems: 'center' }}>
          <Logo size={190} pulse />
          <Text style={s.tag}>The ultimate card game</Text>
        </View>
        <View style={s.fanWrap}>
          {[18, 0, -18].map((d, i) => (
            <Animated.View key={d} style={{ position: 'absolute', transform: [{ rotate: rot(d) }, { translateY: 8 }], zIndex: i }}>
              <CardBack w={70} back={['back_emerald', 'back_navy', 'back_gold'][i]} />
            </Animated.View>
          ))}
        </View>
      </View>
      <View style={s.track}><Animated.View style={[s.fill, { width: bar.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} /></View>
      <Text style={s.load}>Shuffling the deck…</Text>
    </LinearGradient>
  );
}
const s = StyleSheet.create({
  root: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  fanWrap: { width: 170, height: 130, alignItems: 'center', justifyContent: 'center' },
  tag: { color: '#E8E9FF', fontWeight: '700', marginTop: -6, letterSpacing: 1 },
  track: { width: 260, height: 8, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.2)', overflow: 'hidden', marginTop: 14 },
  fill: { height: 8, backgroundColor: BRAND.gold, borderRadius: 4 },
  load: { color: 'rgba(255,255,255,0.75)', marginTop: 6, fontSize: 12, fontWeight: '600' },
});
