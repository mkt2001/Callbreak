import React, { useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import Avatar from '../components/Avatar';
import { H } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { api, hasServer } from '../services/api';
import { sampleBoard, Entry } from './LeaderboardScreen';

export default function TournamentScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const t = useApp((s) => s.tournament); const p = useApp((s) => s.profile); const refresh = useApp((s) => s.refreshPeriods);
  const [rows, setRows] = useState<Entry[]>([]);
  useEffect(() => {
    refresh();
    const me: Entry = { id: p.id || 'me', name: p.name, avatar: p.avatar, level: 1, points: t.weekPts, me: true };
    (async () => {
      try { if (!hasServer()) throw new Error('x'); const r = await api<{ rows: Entry[] }>('/leaderboard?scope=tournament', { token: p.token }); setRows(r.rows.map((x) => ({ ...x, me: x.id === p.id }))); }
      catch { setRows(sampleBoard('weekly', me).slice(0, 8).map((e) => ({ ...e, points: Math.round(e.points / 40) + (e.me ? t.weekPts : 0) })).sort((a, b) => b.points - a.points)); }
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const Card = ({ title, sub, pts, lock }: { title: string; sub: string; pts?: number; lock?: boolean }) => (
    <Panel style={{ marginBottom: 8, opacity: lock ? 0.7 : 1 }}>
      <Text style={{ color: th.text, fontWeight: '900', fontSize: 16 }}>{title}{lock ? '  🔒 VIP' : ''}</Text>
      <Text style={{ color: th.sub, fontSize: 12 }}>{sub}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
        <Text style={{ color: th.primary, fontWeight: '900', flex: 1 }}>{pts !== undefined ? `Your points: ${pts}` : 'Double coins & exclusive badge'}</Text>
        <Btn size="sm" variant="gold" title={lock ? 'VIP only' : 'Play ranked'} disabled={lock} onPress={() => nav.navigate('Matchmaking', { mode: 'tournament' })} />
      </View>
    </Panel>
  );
  return (
    <Screen title="Tournaments">
      <View style={{ flex: 1, flexDirection: 'row' }}>
        <ScrollView style={{ width: 330 }} showsVerticalScrollIndicator={false}>
          <Card title="Daily tournament" sub="Resets every day. 1st = 10 pts, 2nd = 6, 3rd = 3." pts={t.dayPts} />
          <Card title="Weekly tournament" sub="Climb the weekly ladder. Matches played: this week counts." pts={t.weekPts} />
          <Card title="Premium tournament" sub="Bigger prize pool of cosmetics" lock={!p.vip} />
        </ScrollView>
        <Panel style={{ flex: 1, marginLeft: 12 }}>
          <H>Tournament leaderboard</H>
          <ScrollView showsVerticalScrollIndicator={false}>
            {rows.map((r, i) => (
              <View key={r.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 5, backgroundColor: r.me ? (th.dark ? '#2F2A63' : '#EDE8FF') : 'transparent', borderRadius: 10, paddingHorizontal: 6 }}>
                <Text style={{ width: 30, color: th.text, fontWeight: '900' }}>{i + 1}</Text>
                <Avatar avatar={r.avatar} size={28} animate={false} />
                <Text style={{ flex: 1, marginLeft: 8, color: th.text, fontWeight: '800' }}>{r.me ? `${r.name} (you)` : r.name}</Text>
                <Text style={{ color: th.primary, fontWeight: '900' }}>{r.points}</Text>
              </View>
            ))}
          </ScrollView>
        </Panel>
      </View>
    </Screen>
  );
}
