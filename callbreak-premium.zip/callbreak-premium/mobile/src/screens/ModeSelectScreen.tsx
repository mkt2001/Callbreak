import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { Seg, ToggleRow } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { sfx } from '../services/sound';

const MODES = [
  { id: 'classic', e: '♠️', name: 'Classic Callbreak', d: 'Four players, 52 cards, 13 each, five rounds. Spades are trump. Offline vs AI.' },
  { id: 'quick', e: '⚡', name: 'Quick Match', d: 'Auto-matchmaking with real players. AI fills empty seats so you start fast.' },
  { id: 'private', e: '🔒', name: 'Private Room', d: 'Create a room, share the code or link, and play with friends.' },
  { id: 'practice', e: '🎓', name: 'Practice', d: 'Three AI opponents, three difficulty levels, optional hints and practice stats.' },
  { id: 'tournament', e: '🏅', name: 'Tournament', d: 'Daily and weekly ranked matches with a tournament leaderboard.' },
];
export default function ModeSelectScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const focus = (useRoute().params as any)?.focus as string | undefined;
  const [sel, setSel] = useState(focus ?? 'classic');
  const [level, setLevel] = useState<'beginner' | 'intermediate' | 'expert'>('intermediate');
  const [hints, setHints] = useState(sel === 'practice');
  const st = useApp((s) => s.stats);
  const m = MODES.find((x) => x.id === sel)!;
  const start = () => {
    if (sel === 'classic') nav.navigate('Table', { mode: 'quick', level });
    else if (sel === 'practice') nav.navigate('Table', { mode: 'practice', level, hints });
    else if (sel === 'quick') nav.navigate('Matchmaking', { mode: 'quick' });
    else if (sel === 'private') nav.navigate('PrivateRoom');
    else nav.navigate('Tournament');
  };
  return (
    <Screen title="Game modes">
      <View style={{ flex: 1, flexDirection: 'row' }}>
        <ScrollView style={{ width: 250 }} showsVerticalScrollIndicator={false}>
          {MODES.map((x) => (
            <Pressable key={x.id} onPress={() => { sfx('click'); setSel(x.id); setHints(x.id === 'practice'); }} style={{ flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 16, marginBottom: 6, backgroundColor: sel === x.id ? th.primary : th.card, borderWidth: 1, borderColor: sel === x.id ? th.primary : th.border }}>
              <Text style={{ fontSize: 22, marginRight: 10 }}>{x.e}</Text>
              <Text style={{ color: sel === x.id ? '#fff' : th.text, fontWeight: '800' }}>{x.name}</Text>
            </Pressable>
          ))}
        </ScrollView>
        <Panel style={{ flex: 1, marginLeft: 12 }}>
          <Text style={{ fontSize: 36 }}>{m.e}</Text>
          <Text style={{ color: th.text, fontWeight: '900', fontSize: 22 }}>{m.name}</Text>
          <Text style={{ color: th.sub, marginTop: 4, lineHeight: 19 }}>{m.d}</Text>
          {(sel === 'classic' || sel === 'practice') && (
            <View style={{ marginTop: 12 }}>
              <Text style={{ color: th.text, fontWeight: '800', marginBottom: 6 }}>AI difficulty</Text>
              <Seg value={level} onChange={setLevel} options={[{ id: 'beginner', label: 'Beginner' }, { id: 'intermediate', label: 'Intermediate' }, { id: 'expert', label: 'Expert' }]} />
              {sel === 'practice' && <ToggleRow label="Show hints" sub="Highlights a suggested bid and card" value={hints} onChange={setHints} />}
              {sel === 'practice' && <Text style={{ color: th.sub, fontSize: 12, marginTop: 4 }}>Practice stats: {st.practiceMatches} matches · {st.practiceWins} wins</Text>}
            </View>
          )}
          <View style={{ flex: 1 }} />
          <Btn title="Start" size="lg" onPress={start} />
        </Panel>
      </View>
    </Screen>
  );
}
