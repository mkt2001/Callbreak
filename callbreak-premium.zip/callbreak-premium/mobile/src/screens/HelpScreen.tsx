import React from 'react';
import { Linking, ScrollView, Text } from 'react-native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { H } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';

const FAQ: [string, string][] = [
  ['How does a round work?', 'Every player gets 13 cards and bids 1–13. Play 13 tricks. A match is 5 rounds.'],
  ['What must I play?', 'Follow the suit that was led. If you can beat the current winner in that suit you must. If you have none of that suit you may play any card (some regional presets force a trump).'],
  ['Which card wins?', 'The highest spade wins if any spade is played, otherwise the highest card of the led suit. The winner leads next.'],
  ['How is scoring done?', 'Win at least your bid: you score the bid plus 0.1 for each extra trick. Fall short: you lose the bid. Totals add up across rounds.'],
  ['Are coins real money?', 'No. Coins are virtual, can only buy cosmetics, and can never be cashed out.'],
  ['I lost connection', 'The app reconnects automatically and puts you back in your seat. If you stay away, an AI plays for you.'],
];
export default function HelpScreen() {
  const th = useTheme();
  return (
    <Screen title="Help & support">
      <ScrollView showsVerticalScrollIndicator={false}>
        {FAQ.map(([q, a]) => (
          <Panel key={q} style={{ marginBottom: 8 }}><H>{q}</H><Text style={{ color: th.sub, lineHeight: 20 }}>{a}</Text></Panel>
        ))}
        <Btn title="Contact support" onPress={() => Linking.openURL('mailto:support@example.com?subject=Callbreak%20Premium%20support')} style={{ marginVertical: 8 }} />
        <Text style={{ color: th.sub, textAlign: 'center', fontSize: 11 }}>Callbreak Premium v1.0.0</Text>
      </ScrollView>
    </Screen>
  );
}
