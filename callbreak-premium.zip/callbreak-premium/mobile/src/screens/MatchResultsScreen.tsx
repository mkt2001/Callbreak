import React, { useEffect } from 'react';
import { Text, View } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { useTheme } from '../theme/ThemeContext';
import { ACHIEVEMENTS } from '../store/useApp';

export default function MatchResultsScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const r = useRoute().params as any;
  const order = [0, 1, 2, 3].sort((a, b) => r.totals[b] - r.totals[a]);
  const medals = ['🥇', '🥈', '🥉', '4️⃣'];
  const again = () => (r.mode === 'practice' || r.mode === 'quick' ? nav.replace('Table', { mode: r.mode, level: 'intermediate' }) : nav.reset({ index: 0, routes: [{ name: 'Home' }] }));
  useEffect(() => {}, []);
  return (
    <Screen noBack>
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ width: 240, alignItems: 'center' }}>
          <Text style={{ fontSize: 64 }}>{r.rank === 1 ? '🏆' : r.rank === 2 ? '🎉' : '💪'}</Text>
          <Text style={{ color: th.text, fontWeight: '900', fontSize: 26 }}>{r.rank === 1 ? 'You won!' : `You finished #${r.rank}`}</Text>
          <Text style={{ color: th.primary, fontWeight: '900', marginTop: 6 }}>+{r.coins} 🪙   +{r.xp} XP</Text>
          {r.leveledUp ? <Text style={{ color: th.accent, fontWeight: '900', marginTop: 4 }}>⬆️ Level up!</Text> : null}
          {r.newAchievements?.map((a: string) => <Text key={a} style={{ color: th.text, fontWeight: '800', marginTop: 4 }}>{ACHIEVEMENTS[a]?.emoji} {ACHIEVEMENTS[a]?.name}</Text>)}
        </View>
        <Panel style={{ width: 360 }}>
          <Text style={{ color: th.text, fontWeight: '900', fontSize: 16, marginBottom: 6 }}>Final scores</Text>
          {order.map((seat, i) => (
            <View key={seat} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 7, borderTopWidth: i ? 1 : 0, borderColor: th.border }}>
              <Text style={{ fontSize: 20, width: 34 }}>{medals[i]}</Text>
              <Text style={{ flex: 1, color: th.text, fontWeight: seat === 0 ? '900' : '700' }}>{seat === 0 ? 'You' : r.names[seat]}</Text>
              <Text style={{ color: r.totals[seat] < 0 ? th.danger : th.primary, fontWeight: '900', fontSize: 16 }}>{r.totals[seat]}</Text>
            </View>
          ))}
          <View style={{ flexDirection: 'row', marginTop: 12 }}>
            <Btn title="Play again" variant="gold" style={{ flex: 1, marginRight: 8 }} onPress={again} />
            <Btn title="Home" variant="ghost" style={{ flex: 1 }} onPress={() => nav.reset({ index: 0, routes: [{ name: 'Home' }] })} />
          </View>
        </Panel>
      </View>
    </Screen>
  );
}
