import React, { useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { CoinPill, H } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { DAILY_COINS, MISSIONS, todayStr, useApp } from '../store/useApp';

export default function RewardsScreen() {
  const th = useTheme();
  const daily = useApp((s) => s.daily); const m = useApp((s) => s.missions); const coins = useApp((s) => s.profile.coins); const streak = useApp((s) => s.stats.streak);
  const claimDaily = useApp((s) => s.claimDaily); const claimMission = useApp((s) => s.claimMission); const refresh = useApp((s) => s.refreshPeriods);
  const [msg, setMsg] = useState('');
  useEffect(() => { refresh(); }, [refresh]);
  const can = daily.last !== todayStr();
  const y = new Date(); y.setDate(y.getDate() - 1);
  const cur = can ? (daily.last === todayStr(y) ? daily.day % 7 : 0) : (daily.day - 1 + 7) % 7;
  return (
    <Screen title="Rewards & missions" right={<CoinPill coins={coins} />}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Panel>
          <H>Daily login reward</H>
          <View style={{ flexDirection: 'row' }}>
            {DAILY_COINS.map((c, i) => {
              const claimed = !can ? i <= cur : i < cur; const today = can && i === cur;
              return (
                <View key={i} style={{ flex: 1, marginRight: 6, alignItems: 'center', paddingVertical: 8, borderRadius: 14, backgroundColor: today ? th.gold : claimed ? (th.dark ? '#1D3B38' : '#DDF7F2') : th.dark ? '#2A2F55' : '#F0F1FA', borderWidth: today ? 2 : 0, borderColor: th.primary }}>
                  <Text style={{ color: today ? '#20243A' : th.sub, fontWeight: '800', fontSize: 11 }}>Day {i + 1}</Text>
                  <Text style={{ fontSize: 18 }}>{claimed ? '✅' : '🪙'}</Text>
                  <Text style={{ color: today ? '#20243A' : th.text, fontWeight: '900' }}>{c}</Text>
                </View>
              );
            })}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
            <Btn title={can ? 'Claim today' : 'Come back tomorrow'} variant="gold" disabled={!can} onPress={() => { const c = claimDaily(); setMsg(c ? `+${c} coins!` : ''); }} />
            {msg ? <Text style={{ color: th.accent, fontWeight: '900', marginLeft: 12 }}>{msg}</Text> : null}
            <View style={{ flex: 1 }} />
            <Text style={{ color: th.sub, fontWeight: '700' }}>🔥 Win streak: {streak} (bonus at 3, 5, 10)</Text>
          </View>
        </Panel>
        {(['day', 'week'] as const).map((per) => (
          <View key={per} style={{ marginTop: 12 }}>
            <H>{per === 'day' ? 'Daily challenges' : 'Weekly missions'}</H>
            {MISSIONS.filter((x) => x.period === per).map((x) => {
              const v = m.p[x.id] || 0; const done = v >= x.goal; const claimed = !!m.claimed[x.id];
              return (
                <View key={x.id} style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: th.card, borderRadius: 16, padding: 10, marginBottom: 6, borderWidth: 1, borderColor: th.border }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: th.text, fontWeight: '800' }}>{x.title}</Text>
                    <View style={{ height: 6, borderRadius: 3, backgroundColor: th.border, marginTop: 5, overflow: 'hidden' }}><View style={{ width: `${Math.min(100, (v / x.goal) * 100)}%`, height: 6, backgroundColor: th.accent }} /></View>
                    <Text style={{ color: th.sub, fontSize: 11, marginTop: 2 }}>{v}/{x.goal}</Text>
                  </View>
                  <Btn size="sm" variant={claimed ? 'ghost' : 'gold'} title={claimed ? 'Claimed' : `🪙 ${x.reward}`} disabled={!done || claimed} onPress={() => claimMission(x.id)} />
                </View>
              );
            })}
          </View>
        ))}
      </ScrollView>
    </Screen>
  );
}
