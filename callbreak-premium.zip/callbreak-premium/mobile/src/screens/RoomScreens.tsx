import React, { useEffect, useRef, useState } from 'react';
import { Share, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import Avatar from '../components/Avatar';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { connectSocket, currentSocket, hasServer } from '../services/api';

interface RoomPlayer { name: string; avatar: string; isHost: boolean; isBot: boolean }
interface Room { code: string; players: RoomPlayer[]; host: boolean }

function Seats({ players }: { players: RoomPlayer[] }) {
  const th = useTheme();
  return (
    <View style={{ flexDirection: 'row', marginVertical: 12 }}>
      {[0, 1, 2, 3].map((i) => {
        const p = players[i];
        return (
          <View key={i} style={{ width: 100, alignItems: 'center' }}>
            {p ? <Avatar avatar={p.avatar} size={52} /> : <View style={{ width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderStyle: 'dashed', borderColor: th.border }} />}
            <Text style={{ color: th.text, fontWeight: '800', marginTop: 4 }} numberOfLines={1}>{p ? p.name : 'Open seat'}</Text>
            <Text style={{ color: th.sub, fontSize: 10 }}>{p?.isHost ? 'Host' : p?.isBot ? 'AI' : ''}</Text>
          </View>
        );
      })}
    </View>
  );
}
function useLobby(onStart: () => void) {
  const [room, setRoom] = useState<Room | null>(null);
  useEffect(() => {
    const s = currentSocket(); if (!s) return;
    const onRoom = (r: Room) => setRoom(r);
    const onStartEv = () => onStart();
    s.on('room', onRoom); s.on('game:start', onStartEv);
    return () => { s.off('room', onRoom); s.off('game:start', onStartEv); };
  }, [onStart]);
  return { room, setRoom };
}

export function PrivateRoomScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const me = useApp((s) => s.profile);
  const [offline, setOffline] = useState(false);
  const [err, setErr] = useState('');
  const localCode = useRef(Math.random().toString(36).slice(2, 8).toUpperCase()).current;
  const { room, setRoom } = useLobby(() => nav.replace('Table', { mode: 'private', online: true }));

  useEffect(() => {
    (async () => {
      if (!hasServer()) return setOffline(true);
      try {
        const s = await connectSocket();
        s.emit('room:create', {}, (r: { ok: boolean; room?: Room; error?: string }) => (r.ok && r.room ? setRoom(r.room) : setErr(r.error ?? 'Could not create room')));
      } catch { setOffline(true); }
    })();
    return () => { currentSocket()?.emit('room:leave'); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const code = room?.code ?? localCode;
  const players = room?.players ?? [{ name: me.name, avatar: me.avatar, isHost: true, isBot: false }];
  const share = () => Share.share({ message: `Join my Callbreak Premium room! Code: ${code}\ncallbreak://join/${code}` });
  return (
    <Screen title="Play with friends">
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Panel style={{ width: 560, alignItems: 'center' }}>
          <Text style={{ color: th.sub, fontWeight: '700' }}>Room code</Text>
          <Text style={{ color: th.primary, fontWeight: '900', fontSize: 40, letterSpacing: 8 }}>{code}</Text>
          {offline ? <Text style={{ color: th.sub, fontSize: 12, textAlign: 'center' }}>No server configured – friends can't join yet. Start now with AI, or set a server URL in Settings.</Text> : null}
          {err ? <Text style={{ color: th.danger, fontWeight: '700' }}>{err}</Text> : null}
          <Seats players={players} />
          <View style={{ flexDirection: 'row' }}>
            <Btn title="Share invite link" variant="turq" onPress={share} style={{ marginRight: 10 }} />
            <Btn title={offline ? 'Start vs AI' : 'Start (AI fills empty seats)'} variant="gold" disabled={!offline && !(room?.host)} onPress={() => (offline ? nav.replace('Table', { mode: 'private', level: 'intermediate' }) : currentSocket()?.emit('room:start'))} />
          </View>
          <Text style={{ color: th.sub, fontSize: 11, marginTop: 8 }}>Host controls: only the host can start the match.</Text>
        </Panel>
      </View>
    </Screen>
  );
}

export function JoinRoomScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const [code, setCode] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const { room, setRoom } = useLobby(() => nav.replace('Table', { mode: 'private', online: true }));
  const join = async () => {
    setErr(''); setBusy(true);
    try {
      if (!hasServer()) throw new Error('Joining friends needs an online server. Set it in Settings → Server.');
      const s = await connectSocket();
      s.emit('room:join', { code: code.trim().toUpperCase() }, (r: { ok: boolean; room?: Room; error?: string }) => { setBusy(false); if (r.ok && r.room) setRoom(r.room); else setErr(r.error ?? 'Room not found'); });
    } catch (e: any) { setBusy(false); setErr(e.message === 'timeout' ? 'Server not reachable' : e.message); }
  };
  return (
    <Screen title="Join a room" onBack={() => { currentSocket()?.emit('room:leave'); nav.goBack(); }}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Panel style={{ width: 460, alignItems: 'center' }}>
          {!room ? (
            <>
              <Text style={{ color: th.text, fontWeight: '900', fontSize: 18 }}>Enter the 6-character code</Text>
              <TextInput value={code} onChangeText={(t) => setCode(t.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))} autoCapitalize="characters" placeholder="ABC123" placeholderTextColor={th.sub} style={{ marginVertical: 12, width: 240, textAlign: 'center', fontSize: 30, letterSpacing: 6, fontWeight: '900', color: th.text, backgroundColor: th.dark ? '#2A2F55' : '#F0F1FA', borderRadius: 16, height: 56 }} />
              {err ? <Text style={{ color: th.danger, fontWeight: '700', marginBottom: 8, textAlign: 'center' }}>{err}</Text> : null}
              <Btn title={busy ? 'Joining…' : 'Join room'} disabled={code.length !== 6 || busy} onPress={join} />
            </>
          ) : (
            <>
              <Text style={{ color: th.text, fontWeight: '900', fontSize: 18 }}>Room {room.code}</Text>
              <Seats players={room.players} />
              <Text style={{ color: th.sub, fontWeight: '700' }}>Waiting for the host to start…</Text>
            </>
          )}
        </Panel>
      </View>
    </Screen>
  );
}
