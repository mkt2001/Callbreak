import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Logo from '../components/Logo';
import Panel from '../components/Panel';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { api, hasServer } from '../services/api';

function useAuth() {
  const nav = useNavigation<any>();
  const signIn = useApp((s) => s.signIn);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const go = () => nav.reset({ index: 0, routes: [{ name: 'Home' }] });
  const run = async (path: string, body: any, fallbackName: string, email: string | null) => {
    setBusy(true); setMsg('');
    try {
      if (!hasServer()) throw new Error('no-server');
      const r = await api<{ token: string; user: { id: string; name: string; email?: string } }>(path, { body });
      signIn({ id: r.user.id, name: r.user.name, email: r.user.email ?? email, token: r.token, guest: path.includes('guest') });
      go();
    } catch (e: any) {
      if (e.message === 'no-server' || e.name === 'AbortError' || e.message === 'Network request failed' || e.message === 'Failed to fetch') {
        // Offline-first: the account lives on this device until a server is configured.
        signIn({ name: fallbackName, email, token: null, guest: !email });
        go();
      } else setMsg(String(e.message).replace(/-/g, ' '));
    } finally { setBusy(false); }
  };
  return { nav, busy, msg, setMsg, run };
}
const Field = ({ ph, v, set, secure, kb }: { ph: string; v: string; set: (t: string) => void; secure?: boolean; kb?: any }) => {
  const th = useTheme();
  return <TextInput value={v} onChangeText={set} placeholder={ph} placeholderTextColor={th.sub} secureTextEntry={secure} autoCapitalize="none" keyboardType={kb} style={{ backgroundColor: th.dark ? '#2A2F55' : '#F0F1FA', color: th.text, borderRadius: 14, paddingHorizontal: 14, height: 42, marginBottom: 8, fontWeight: '600' }} />;
};

export function LoginScreen() {
  const th = useTheme();
  const { nav, busy, msg, setMsg, run } = useAuth();
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('');
  return (
    <Screen>
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ width: 230, alignItems: 'center' }}>
          <Logo size={190} pulse />
          <Text style={{ color: th.sub, fontWeight: '700', textAlign: 'center' }}>Bid. Play. Break the call.</Text>
        </View>
        <Panel style={{ width: 360 }}>
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <Text style={{ color: th.text, fontWeight: '900', fontSize: 20, marginBottom: 8 }}>Welcome back</Text>
            <Field ph="Email" v={email} set={setEmail} kb="email-address" />
            <Field ph="Password" v={pw} set={setPw} secure />
            {msg ? <Text style={{ color: th.danger, fontWeight: '700', marginBottom: 6 }}>{msg}</Text> : null}
            <Btn title={busy ? 'Signing in…' : 'Sign in'} disabled={busy || !email.includes('@') || pw.length < 6} onPress={() => run('/auth/login', { email, password: pw }, email.split('@')[0], email)} />
            <View style={{ flexDirection: 'row', marginTop: 8 }}>
              <Btn title="Play as guest" variant="turq" size="sm" style={{ flex: 1, marginRight: 6 }} onPress={() => run('/auth/guest', {}, 'Guest' + Math.floor(1000 + Math.random() * 9000), null)} />
              <Btn title="Google" variant="ghost" size="sm" style={{ flex: 1 }} onPress={() => setMsg('Google sign-in needs your Google client ID – see README → "Google login".')} />
            </View>
            <Pressable onPress={() => nav.navigate('Register')} style={{ marginTop: 10 }}>
              <Text style={{ color: th.primary, fontWeight: '800', textAlign: 'center' }}>New here? Create an account</Text>
            </Pressable>
          </ScrollView>
        </Panel>
      </View>
    </Screen>
  );
}

export function RegisterScreen() {
  const th = useTheme();
  const { busy, msg, run } = useAuth();
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [pw, setPw] = useState('');
  return (
    <Screen title="Create account">
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Panel style={{ width: 380 }}>
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <Field ph="Display name" v={name} set={setName} />
            <Field ph="Email" v={email} set={setEmail} kb="email-address" />
            <Field ph="Password (min 6 characters)" v={pw} set={setPw} secure />
            {msg ? <Text style={{ color: th.danger, fontWeight: '700', marginBottom: 6 }}>{msg}</Text> : null}
            <Btn title={busy ? 'Creating…' : 'Create account'} disabled={busy || name.trim().length < 2 || !email.includes('@') || pw.length < 6} onPress={() => run('/auth/register', { name: name.trim(), email, password: pw }, name.trim(), email)} />
            <Text style={{ color: th.sub, fontSize: 11, marginTop: 8, textAlign: 'center' }}>Virtual coins only. No real-money gambling, no cash-outs.</Text>
          </ScrollView>
        </Panel>
      </View>
    </Screen>
  );
}
