import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Avatar from '../components/Avatar';
import { CoinPill, XPBar } from '../components/ui';
import { useApp, levelInfo, todayStr } from '../store/useApp';
import { useTheme } from '../theme/ThemeContext';
import { useT } from '../services/i18n';
import { sfx } from '../services/sound';

const MODES = [
  { k: 'quick', e: '⚡', sub: 'Jump into a match', c: ['#7047EB', '#9B7BFF'] as [string, string], go: ['Matchmaking', { mode: 'quick' }] },
  { k: 'friends', e: '👥', sub: 'Invite & share a link', c: ['#20C9B0', '#5BE3CE'] as [string, string], go: ['PrivateRoom'] },
  { k: 'private', e: '🔒', sub: 'Join with a room code', c: ['#FF8A5B', '#FFB36B'] as [string, string], go: ['JoinRoom'] },
  { k: 'practice', e: '🎓', sub: 'Learn vs AI with hints', c: ['#3B82F6', '#6AA8FF'] as [string, string], go: ['ModeSelect', { focus: 'practice' }] },
  { k: 'tournament', e: '🏅', sub: 'Daily & weekly ranked', c: ['#F5A524', '#FFD166'] as [string, string], go: ['Tournament'] },
];
export default function HomeScreen() {
  const th = useTheme(); const t = useT(); const nav = useNavigation<any>();
  const p = useApp((s) => s.profile); const daily = useApp((s) => s.daily);
  const li = levelInfo(p.xp);
  const canClaim = daily.last !== todayStr();
  const secondary = [
    { k: 'rewards', e: '🎁', to: 'Rewards', dot: canClaim }, { k: 'missions', e: '🎯', to: 'Rewards' }, { k: 'leaderboard', e: '📈', to: 'Leaderboard' },
    { k: 'history', e: '🕘', to: 'History' }, { k: 'store', e: '🛍️', to: 'Store' },
  ];
  return (
    <Screen>
      <View style={{ flexDirection: 'row', alignItems: 'center', height: 56 }}>
        <Pressable onPress={() => nav.navigate('Profile')} style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
          <Avatar avatar={p.avatar} frame={p.frame} size={44} />
          <View style={{ marginLeft: 10 }}>
            <Text style={{ color: th.text, fontWeight: '900', fontSize: 16 }}>{p.name} {p.badge ? '⭐' : ''}{p.vip ? ' 👑' : ''}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: th.sub, fontWeight: '800', fontSize: 12, marginRight: 8 }}>{t('level')} {li.level}</Text>
              <XPBar into={li.into} need={li.need} />
              <Text style={{ color: th.sub, fontSize: 10, marginLeft: 6 }}>{li.into}/{li.need} XP</Text>
            </View>
          </View>
        </Pressable>
        <CoinPill coins={p.coins} />
        <Pressable onPress={() => { sfx('click'); nav.navigate('Settings'); }} style={{ marginLeft: 10, width: 38, height: 38, borderRadius: 19, backgroundColor: th.card, borderWidth: 1, borderColor: th.border, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>⚙️</Text>
        </Pressable>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'baseline', marginTop: 4 }}>
        <Text style={{ color: th.text, fontWeight: '900', fontSize: 18, flex: 1 }}>Choose your game</Text>
        <Pressable onPress={() => nav.navigate('ModeSelect')}><Text style={{ color: th.primary, fontWeight: '800' }}>All modes ›</Text></Pressable>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, marginTop: 8 }} contentContainerStyle={{ paddingRight: 8 }}>
        {MODES.map((m) => (
          <Pressable key={m.k} onPress={() => { sfx('click'); nav.navigate(...(m.go as [string, any?])); }} style={({ pressed }) => ({ marginRight: 12, transform: [{ scale: pressed ? 0.97 : 1 }] })}>
            <LinearGradient colors={m.c} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: 148, height: 138, borderRadius: 24, padding: 14, justifyContent: 'space-between', shadowColor: m.c[0], shadowOpacity: 0.4, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 6 }}>
              <Text style={{ fontSize: 38 }}>{m.e}</Text>
              <View>
                <Text style={{ color: '#fff', fontWeight: '900', fontSize: 16 }}>{t(m.k)}</Text>
                <Text style={{ color: 'rgba(255,255,255,0.9)', fontSize: 11, fontWeight: '600' }}>{m.sub}</Text>
              </View>
            </LinearGradient>
          </Pressable>
        ))}
      </ScrollView>

      <View style={{ flexDirection: 'row', marginTop: 14 }}>
        {secondary.map((x) => (
          <Pressable key={x.k} onPress={() => { sfx('click'); nav.navigate(x.to); }} style={{ flex: 1, marginRight: 8, backgroundColor: th.card, borderRadius: 18, borderWidth: 1, borderColor: th.border, paddingVertical: 10, alignItems: 'center' }}>
            <Text style={{ fontSize: 22 }}>{x.e}</Text>
            <Text style={{ color: th.text, fontWeight: '800', fontSize: 11, marginTop: 2 }}>{x.k === 'rewards' ? 'Daily reward' : t(x.k)}</Text>
            {x.dot ? <View style={{ position: 'absolute', top: 8, right: 14, width: 10, height: 10, borderRadius: 5, backgroundColor: th.danger }} /> : null}
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
