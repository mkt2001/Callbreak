import React from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { DarkPill, ProfilePill, Wood, WoodCard, WoodIcon } from '../components/wood';
import { useApp, todayStr } from '../store/useApp';
import { usePing } from '../services/ping';

export default function HomeScreen() {
  const nav = useNavigation<any>();
  const { height: H } = useWindowDimensions();
  const p = useApp((s) => s.profile); const daily = useApp((s) => s.daily);
  const ping = usePing();
  const cardH = Math.max(96, Math.min(132, (H - 150) / 2));
  const cards = [
    { e: '🤖', t: 'Practice', sub: 'Play against AI', go: () => nav.navigate('Variant', { target: 'practice' }) },
    { e: '🌐', t: 'Play Online', sub: 'Real players, AI fills seats', go: () => nav.navigate('Variant', { target: 'online' }) },
    { e: '🎴', t: 'Play Privately', sub: 'Friends & room code', go: () => nav.navigate('Variant', { target: 'private' }) },
    { e: '🏆', t: 'Tournament', sub: 'Daily & weekly ranked', go: () => nav.navigate('Tournament') },
  ];
  return (
    <Wood>
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom', 'left', 'right']}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 16, paddingTop: 6 }}>
          <ProfilePill name={p.name} avatar={p.avatar} frame={p.frame} coins={p.coins} vip={p.vip} onProfile={() => nav.navigate('Profile')} onPlus={() => nav.navigate('Store')} />
          <View style={{ flex: 1, alignItems: 'center' }}>
            <DarkPill style={{ borderTopLeftRadius: 0, borderTopRightRadius: 0, marginTop: -6, paddingTop: 10 }}>
              <Text style={{ color: ping.online ? '#6BE05A' : '#FFD08A', fontSize: 12, fontWeight: '800' }}>● {ping.online ? 'Online' : 'Offline mode · AI play'}</Text>
              {ping.ms !== null ? <Text style={{ color: '#fff', fontSize: 12, fontWeight: '700', marginLeft: 10 }}>{ping.ms}ms</Text> : null}
            </DarkPill>
          </View>
          <View style={{ flexDirection: 'row' }}>
            <WoodIcon icon="📈" onPress={() => nav.navigate('Leaderboard')} />
            <WoodIcon icon="🛍️" onPress={() => nav.navigate('Store')} />
            <WoodIcon icon="🎁" dot={daily.last !== todayStr()} onPress={() => nav.navigate('Rewards')} />
            <WoodIcon icon="⚙️" onPress={() => nav.navigate('Settings')} />
          </View>
        </View>

        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', width: 500, justifyContent: 'space-between' }}>
            {cards.map((c) => (
              <WoodCard key={c.t} onPress={c.go} style={{ width: 242, height: cardH, marginBottom: 14 }}>
                <View style={{ height: cardH - 6, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 }}>
                  <Text style={{ fontSize: cardH * 0.34 }}>{c.e}</Text>
                  <Text style={{ color: '#fff', fontWeight: '900', fontSize: 21, marginTop: 2, textShadowColor: 'rgba(0,0,0,0.35)', textShadowRadius: 3 }}>{c.t}</Text>
                  <Text style={{ color: 'rgba(255,225,200,0.95)', fontWeight: '700', fontSize: 11 }}>{c.sub}</Text>
                </View>
              </WoodCard>
            ))}
          </View>
        </View>
        {/* left edge tab → profile & stats */}
        <View style={{ position: 'absolute', left: 0, top: '42%' }}>
          <WoodIcon icon="👤" size={42} onPress={() => nav.navigate('Profile')} />
        </View>
      </SafeAreaView>
    </Wood>
  );
}
