import React, { useState } from 'react';
import { Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import Screen from '../components/Screen';
import Avatar from '../components/Avatar';
import Panel from '../components/Panel';
import { H, XPBar } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { ACHIEVEMENTS, levelInfo, useApp } from '../store/useApp';
import { CATALOG } from '../theme/catalog';

export default function ProfileScreen() {
  const th = useTheme();
  const p = useApp((s) => s.profile); const st = useApp((s) => s.stats); const hist = useApp((s) => s.history);
  const setProfile = useApp((s) => s.setProfile); const equip = useApp((s) => s.equip);
  const [name, setName] = useState(p.name);
  const li = levelInfo(p.xp);
  const winPct = st.matches ? Math.round((st.wins / st.matches) * 100) : 0;
  const avgBid = st.bidCount ? (st.bidSum / st.bidCount).toFixed(1) : '–';
  const grid = [['Matches', st.matches], ['Wins', st.wins], ['Win %', `${winPct}%`], ['Tricks', st.tricks], ['Avg bid', avgBid], ['Best streak', st.bestStreak], ['Highest score', st.highScore]];
  return (
    <Screen title="Profile">
      <View style={{ flex: 1, flexDirection: 'row' }}>
        <Panel style={{ width: 250, alignItems: 'center' }}>
          <Avatar avatar={p.avatar} frame={p.frame} size={78} />
          <TextInput value={name} onChangeText={setName} onBlur={() => name.trim().length >= 2 && setProfile({ name: name.trim() })} maxLength={14} style={{ color: th.text, fontWeight: '900', fontSize: 20, textAlign: 'center', marginTop: 6, minWidth: 140 }} />
          <Text style={{ color: th.sub, fontWeight: '700' }}>{p.vip ? '👑 VIP · ' : ''}Level {li.level}</Text>
          <View style={{ marginTop: 6 }}><XPBar into={li.into} need={li.need} width={170} /></View>
          <Text style={{ color: th.sub, fontSize: 11, marginTop: 3 }}>{li.into}/{li.need} XP</Text>
          <Text style={{ color: th.text, fontWeight: '800', marginTop: 10, alignSelf: 'flex-start' }}>Avatar</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 }}>
            {CATALOG.filter((i) => i.kind === 'avatar' && p.owned.includes(i.id)).map((i) => (
              <Pressable key={i.id} onPress={() => equip(i.id)} style={{ margin: 3, borderRadius: 20, borderWidth: 2, borderColor: p.avatar === i.id ? th.primary : 'transparent' }}><Avatar avatar={i.id} size={34} animate={false} /></Pressable>
            ))}
          </View>
        </Panel>
        <ScrollView style={{ flex: 1, marginLeft: 12 }} showsVerticalScrollIndicator={false}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {grid.map(([k, v]) => (
              <View key={String(k)} style={{ width: '24%', marginRight: '1%', marginBottom: 8, backgroundColor: th.card, borderRadius: 14, padding: 10, borderWidth: 1, borderColor: th.border }}>
                <Text style={{ color: th.primary, fontWeight: '900', fontSize: 20 }}>{String(v)}</Text>
                <Text style={{ color: th.sub, fontSize: 11, fontWeight: '700' }}>{k}</Text>
              </View>
            ))}
          </View>
          <H>Achievements</H>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {Object.entries(ACHIEVEMENTS).map(([id, a]) => {
              const on = st.achievements.includes(id);
              return (
                <View key={id} style={{ width: 130, marginRight: 8, marginBottom: 8, opacity: on ? 1 : 0.45, backgroundColor: th.card, borderRadius: 14, padding: 8, borderWidth: 1, borderColor: on ? th.gold : th.border }}>
                  <Text style={{ fontSize: 22 }}>{a.emoji}</Text>
                  <Text style={{ color: th.text, fontWeight: '800', fontSize: 12 }}>{a.name}</Text>
                  <Text style={{ color: th.sub, fontSize: 10 }}>{a.desc}</Text>
                </View>
              );
            })}
          </View>
          <H>Recent matches</H>
          {hist.slice(0, 5).map((h) => (
            <View key={h.id} style={{ flexDirection: 'row', paddingVertical: 5 }}>
              <Text style={{ color: th.text, fontWeight: '800', width: 90 }}>{h.rank === 1 ? '🏆 Win' : `#${h.rank}`}</Text>
              <Text style={{ color: th.sub, flex: 1 }}>{h.mode} · {new Date(h.date).toLocaleDateString()}</Text>
              <Text style={{ color: th.primary, fontWeight: '900' }}>{h.totals[0]}</Text>
            </View>
          ))}
          {!hist.length && <Text style={{ color: th.sub }}>No matches yet – play one!</Text>}
        </ScrollView>
      </View>
    </Screen>
  );
}
