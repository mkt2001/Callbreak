import React, { useState } from 'react';
import { Alert, ScrollView, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Screen from '../components/Screen';
import Btn from '../components/Btn';
import Panel from '../components/Panel';
import { H, Seg, Tabs, ToggleRow } from '../components/ui';
import { useTheme } from '../theme/ThemeContext';
import { useApp } from '../store/useApp';
import { CATALOG } from '../theme/catalog';
import { LANGS } from '../services/i18n';
import { syncMusic } from '../services/sound';
import { closeSocket } from '../services/api';

export default function SettingsScreen() {
  const th = useTheme(); const nav = useNavigation<any>();
  const s = useApp((x) => x.settings); const set = useApp((x) => x.set); const p = useApp((x) => x.profile);
  const equip = useApp((x) => x.equip); const signOut = useApp((x) => x.signOut);
  const [server, setServer] = useState(s.server);
  const owned = (k: string) => CATALOG.filter((i) => i.kind === k && p.owned.includes(i.id)).map((i) => ({ id: i.id, label: i.name }));
  const pick = (k: string, cur: string) => <Tabs tabs={owned(k)} value={cur} onChange={equip} />;
  return (
    <Screen title="Settings">
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{ flexDirection: 'row' }}>
          <View style={{ flex: 1, marginRight: 10 }}>
            <Panel style={{ marginBottom: 10 }}>
              <H>Appearance</H>
              <Seg value={s.dark === null ? 'auto' : s.dark ? 'dark' : 'light'} onChange={(v) => set({ dark: v === 'auto' ? null : v === 'dark' })} options={[{ id: 'auto', label: 'System' }, { id: 'light', label: 'Light' }, { id: 'dark', label: 'Dark' }]} />
              <ToggleRow label="Animations" sub="Turn off on budget phones for max speed" value={s.animations} onChange={(v) => set({ animations: v })} />
              <Text style={{ color: th.text, fontWeight: '800', marginTop: 4 }}>Language</Text>
              <Tabs tabs={LANGS.map((l) => ({ id: l.id, label: l.name }))} value={s.lang} onChange={(id) => set({ lang: id })} />
            </Panel>
            <Panel>
              <H>Sound</H>
              <ToggleRow label="Sound effects" value={s.sound} onChange={(v) => set({ sound: v })} />
              <ToggleRow label="Background music" value={s.music} onChange={(v) => { set({ music: v }); setTimeout(syncMusic, 50); }} />
              <ToggleRow label="Vibration" value={s.vibration} onChange={(v) => set({ vibration: v })} />
              <ToggleRow label="Auto-select card" sub="When others lead, a suitable card is pre-selected. You still tap to play." value={s.autoSelect} onChange={(v) => set({ autoSelect: v })} />
              <Text style={{ color: th.text, fontWeight: '800' }}>Card sound pack</Text>
              {pick('sound', s.soundPack)}
            </Panel>
          </View>
          <View style={{ flex: 1 }}>
            <Panel style={{ marginBottom: 10 }}>
              <H>Cards & table</H>
              <Text style={{ color: th.text, fontWeight: '800' }}>Card design</Text>{pick('cardTheme', s.cardTheme)}
              <Text style={{ color: th.text, fontWeight: '800' }}>Card back</Text>{pick('cardBack', s.cardBack)}
              <Text style={{ color: th.text, fontWeight: '800' }}>Table theme</Text>{pick('table', s.table)}
              <Text style={{ color: th.sub, fontSize: 11 }}>Unlock more in the Premium store.</Text>
            </Panel>
            <Panel style={{ marginBottom: 10 }}>
              <H>Privacy & notifications</H>
              <ToggleRow label="Notifications" value={s.notifications} onChange={(v) => set({ notifications: v })} />
              <ToggleRow label="Show online status" value={s.showOnline} onChange={(v) => set({ showOnline: v })} />
              <ToggleRow label="Public profile" value={s.publicProfile} onChange={(v) => set({ publicProfile: v })} />
            </Panel>
            <Panel>
              <H>Account & support</H>
              <Text style={{ color: th.sub, marginBottom: 6 }}>{p.email ?? (p.guest ? 'Guest account' : 'Local account')}</Text>
              <Text style={{ color: th.text, fontWeight: '800' }}>Server URL (online play)</Text>
              <TextInput value={server} onChangeText={setServer} onBlur={() => { set({ server: server.trim() }); closeSocket(); }} autoCapitalize="none" placeholder="https://your-server.example.com" placeholderTextColor={th.sub} style={{ backgroundColor: th.dark ? '#2A2F55' : '#F0F1FA', color: th.text, borderRadius: 12, paddingHorizontal: 12, height: 38, marginVertical: 6 }} />
              <View style={{ flexDirection: 'row' }}>
                <Btn title="Help" size="sm" variant="turq" style={{ marginRight: 8 }} onPress={() => nav.navigate('Help')} />
                <Btn title="History" size="sm" variant="ghost" style={{ marginRight: 8 }} onPress={() => nav.navigate('History')} />
                <Btn title="Sign out" size="sm" variant="ghost" style={{ marginRight: 8 }} onPress={() => { signOut(); closeSocket(); nav.reset({ index: 0, routes: [{ name: 'Login' }] }); }} />
                <Btn title="Reset data" size="sm" variant="danger" onPress={() => Alert.alert('Reset all data?', 'Progress, coins and settings on this device will be erased.', [{ text: 'Cancel' }, { text: 'Erase', style: 'destructive', onPress: async () => { const AS = (await import('@react-native-async-storage/async-storage')).default; await AS.clear(); useApp.persist.rehydrate(); nav.reset({ index: 0, routes: [{ name: 'Splash' }] }); } }])} />
              </View>
            </Panel>
          </View>
        </View>
      </ScrollView>
    </Screen>
  );
}
