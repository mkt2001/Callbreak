import React, { useEffect } from 'react';
import { Platform, Text, View, useWindowDimensions } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as ScreenOrientation from 'expo-screen-orientation';
import Navigator from './src/navigation/Navigator';
import { useApp } from './src/store/useApp';
import { useTheme } from './src/theme/ThemeContext';
import { syncMusic } from './src/services/sound';

/** Web only: friendly hint when the window is too narrow/portrait for comfortable play. */
function RotateHint() {
  const { width, height } = useWindowDimensions();
  if (Platform.OS !== 'web' || (width >= 640 && width > height)) return null;
  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#20243Af2', alignItems: 'center', justifyContent: 'center', zIndex: 999 }}>
      <Text style={{ fontSize: 54 }}>📱↻</Text>
      <Text style={{ color: '#fff', fontWeight: '900', fontSize: 20, marginTop: 10 }}>Rotate your device</Text>
      <Text style={{ color: '#C9CCE8', marginTop: 6, textAlign: 'center', paddingHorizontal: 24 }}>Callbreak Premium plays best in landscape. Turn your phone sideways or widen the window.</Text>
    </View>
  );
}

export default function App() {
  const th = useTheme();
  const music = useApp((s) => s.settings.music);

  // Landscape is enforced at startup, again on every rotation event, and by app.json + the native manifest.
  useEffect(() => {
    const lock = () => ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE).catch(() => {});
    lock();
    const sub = ScreenOrientation.addOrientationChangeListener(() => lock());
    return () => ScreenOrientation.removeOrientationChangeListener(sub);
  }, []);
  useEffect(() => { syncMusic(); }, [music]);

  return (
    <SafeAreaProvider>
      <StatusBar hidden style={th.dark ? 'light' : 'dark'} />
      <Navigator />
      <RotateHint />
    </SafeAreaProvider>
  );
}
