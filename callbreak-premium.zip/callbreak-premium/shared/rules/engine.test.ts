import assert from 'node:assert/strict';
import { test } from 'node:test';
import { newMatch, placeBid, playCard, completeTrick, legalCards, trickWinner, scoreRound, createDeck, nextRound, makeView } from './engine';
import { chooseBid, chooseCard } from './ai';
import { DEFAULT_RULES } from '../constants';
import type { Card, Difficulty } from '../types';

const c = (suit: any, rank: number): Card => ({ id: `${suit}${rank}`, suit, rank });

test('deck has 52 unique cards, 13 each per hand', () => {
  assert.equal(new Set(createDeck().map((x) => x.id)).size, 52);
  const m = newMatch();
  assert.deepEqual(m.hands.map((h) => h.length), [13, 13, 13, 13]);
});
test('trump beats lead suit, highest trump wins', () => {
  assert.equal(trickWinner([{ seat: 0, card: c('H', 14) }, { seat: 1, card: c('S', 2) }, { seat: 2, card: c('H', 13) }, { seat: 3, card: c('S', 5) }]), 3);
});
test('highest of lead suit wins without trump; off-suit never wins', () => {
  assert.equal(trickWinner([{ seat: 2, card: c('D', 5) }, { seat: 3, card: c('C', 14) }, { seat: 0, card: c('D', 9) }, { seat: 1, card: c('D', 7) }]), 0);
});
test('must follow suit, and must beat if able', () => {
  const hand = [c('H', 3), c('H', 12), c('S', 2)];
  const trick = [{ seat: 0, card: c('H', 9) }];
  assert.deepEqual(legalCards(hand, trick).map((x) => x.id), ['H12']);
  assert.deepEqual(legalCards([c('H', 3), c('S', 2)], trick).map((x) => x.id), ['H3']);
});
test('void in lead suit: any card (default), forced trump when configured', () => {
  const hand = [c('D', 3), c('S', 2)];
  const trick = [{ seat: 0, card: c('H', 9) }];
  assert.equal(legalCards(hand, trick, DEFAULT_RULES).length, 2);
  assert.deepEqual(legalCards(hand, trick, { ...DEFAULT_RULES, mustTrump: true }).map((x) => x.id), ['S2']);
});
test('scoring', () => {
  assert.deepEqual(scoreRound([3, 4, 5, 2], [3, 6, 4, 4]), [3, 4.2, -5, 2.2]);
});
test('rejects illegal bids, out-of-turn and illegal plays', () => {
  const m = newMatch();
  assert.equal(placeBid(m, (m.turn + 1) % 4, 3), 'not-your-turn');
  assert.equal(placeBid(m, m.turn, 14), 'invalid-bid');
  assert.equal(placeBid(m, m.turn, 0), 'invalid-bid');
});
for (const level of ['beginner', 'intermediate', 'expert'] as Difficulty[]) {
  test(`full 5-round match with ${level} AI is always legal`, () => {
    const m = newMatch();
    let guard = 0;
    while (m.phase !== 'matchEnd' && guard++ < 5000) {
      if (m.phase === 'bidding') {
        assert.equal(placeBid(m, m.turn, chooseBid(m.hands[m.turn], level, m.bids)), null);
      } else if (m.phase === 'playing') {
        if (m.trickDone) completeTrick(m);
        else {
          const card = chooseCard(m, m.turn, level);
          assert.equal(playCard(m, m.turn, card.id), null);
        }
      } else if (m.phase === 'roundEnd') nextRound(m);
    }
    assert.equal(m.phase, 'matchEnd');
    assert.equal(m.roundScores.length, 5);
    assert.equal(m.tricksTotal.reduce((a, b) => a + b, 0), 65);
  });
}
test('view never leaks other hands', () => {
  const m = newMatch();
  const v = makeView(m, 0, [0, 1, 2, 3].map(() => ({ name: 'x', avatar: 'y', isBot: false, connected: true })));
  assert.equal(v.hand.length, 13);
  assert.ok(!JSON.stringify(v).includes(m.hands[1][0].id + '"}') || v.hand.some((h) => h.id === m.hands[1][0].id) === false);
});
