-- Callbreak Premium schema (PostgreSQL 13+)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(24) NOT NULL,
  email varchar(254) UNIQUE,
  password_hash text,
  google_id text UNIQUE,
  avatar varchar(32) NOT NULL DEFAULT '😎',
  coins integer NOT NULL DEFAULT 1000 CHECK (coins >= 0),
  xp integer NOT NULL DEFAULT 0,
  last_daily date,
  daily_day integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS matches (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rank smallint NOT NULL CHECK (rank BETWEEN 1 AND 4),
  score numeric(6,1) NOT NULL,
  points integer NOT NULL,
  mode varchar(16) NOT NULL,
  tricks integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS matches_user_idx ON matches(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS matches_created_idx ON matches(created_at DESC);
