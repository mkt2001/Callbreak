// Copies /shared into mobile/src/shared and backend/src/shared so both apps build standalone.
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, '..', 'shared');
for (const target of ['mobile/src/shared', 'backend/src/shared']) {
  const dest = path.join(__dirname, '..', target);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.cpSync(src, dest, { recursive: true, filter: (p) => !p.endsWith('.test.ts') });
  console.log('synced ->', target);
}
