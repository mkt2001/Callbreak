export type Suit = 'S' | 'H' | 'D' | 'C';
export type Difficulty = 'beginner' | 'intermediate' | 'expert';
export type Variant = 'normal' | 'super8' | 'blind';
export type Phase = 'bidding' | 'playing' | 'roundEnd' | 'matchEnd';

export interface Card {
  id: string; // e.g. "S14" = Ace of spades
  suit: Suit;
  rank: number; // 2..14 (11=J 12=Q 13=K 14=A)
}
export interface Play {
  seat: number;
  card: Card;
}
export interface RulesConfig {
  rounds: number; // default 5
  minBid: number; // default 1
  maxBid: number; // default 13
  overtrickPoints: number; // default 0.1 per extra trick
  failPenaltyMultiplier: number; // default 1 (lose the bid)
  mustOverPlay: boolean; // must play higher card of led suit / higher trump if able
  mustTrump: boolean; // must trump if void in led suit
  bigBidThreshold: number; // 0 = off. Variant: bids >= threshold, on fail = -bid (no change) 
  redealOnWeakHand: boolean; // variant: no spades or no face cards -> redeal
  variant: Variant; // normal | super8 (everyone bids 8 automatically) | blind (bids hidden until round ends)
  super8Bid: number;
}
export interface MatchState {
  cfg: RulesConfig;
  round: number; // 1-based
  dealer: number;
  phase: Phase;
  hands: Card[][];
  bids: (number | null)[];
  tricksWon: number[];
  trick: Play[];
  trickDone: boolean;
  leader: number;
  turn: number;
  played: Card[]; // every card played this round (for AI card counting)
  roundScores: number[][]; // [round][seat]
  totals: number[];
  lastTrickWinner: number | null;
  tricksTotal: number[]; // across match
}
export interface PlayerView {
  seat: number;
  name: string;
  avatar: string;
  bid: number | null;
  tricksWon: number;
  score: number;
  isBot: boolean;
  connected: boolean;
  cards: number; // cards still in hand (for the fan display)
  bidHidden: boolean; // blind variant: a bid exists but is secret
}
export interface GameView {
  phase: Phase;
  round: number;
  rounds: number;
  variant: Variant;
  mySeat: number;
  hand: Card[];
  legal: string[];
  players: PlayerView[];
  trick: Play[];
  trickDone: boolean;
  turn: number;
  lastTrickWinner: number | null;
  roundScores: number[][];
  totals: number[];
  deadline?: number; // epoch ms – turn timer (online)
}
