import type { Card, MatchState, Play, RulesConfig, Suit, GameView, PlayerView } from '../types';
import { DEFAULT_RULES, SUITS, TRUMP } from '../constants';

export type Rng = () => number;
export const mathRng: Rng = Math.random;

export function cardId(suit: Suit, rank: number) {
  return `${suit}${rank}`;
}
export function createDeck(): Card[] {
  const d: Card[] = [];
  for (const s of SUITS) for (let r = 2; r <= 14; r++) d.push({ id: cardId(s, r), suit: s, rank: r });
  return d;
}
/** Fisher-Yates. Pass a crypto-backed rng on the server. */
export function shuffle<T>(arr: T[], rng: Rng = mathRng): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
const SUIT_ORDER: Record<string, number> = { S: 0, H: 1, D: 2, C: 3 };
export function sortHand(h: Card[]): Card[] {
  return h.slice().sort((a, b) => SUIT_ORDER[a.suit] - SUIT_ORDER[b.suit] || b.rank - a.rank);
}

export function newMatch(cfg: Partial<RulesConfig> = {}, rng: Rng = mathRng, dealer = 0): MatchState {
  const full = { ...DEFAULT_RULES, ...cfg };
  const st: MatchState = {
    cfg: full, round: 0, dealer, phase: 'bidding', hands: [[], [], [], []],
    bids: [null, null, null, null], tricksWon: [0, 0, 0, 0], trick: [], trickDone: false,
    leader: 0, turn: 0, played: [], roundScores: [], totals: [0, 0, 0, 0],
    lastTrickWinner: null, tricksTotal: [0, 0, 0, 0],
  };
  return startRound(st, rng);
}

function weakHand(h: Card[]) {
  const noSpade = !h.some((c) => c.suit === TRUMP);
  const noFace = !h.some((c) => c.rank >= 11);
  return noSpade || noFace;
}

/** Deals a fresh round. Dealer rotates each round. */
export function startRound(st: MatchState, rng: Rng = mathRng): MatchState {
  st.round += 1;
  if (st.round > 1) st.dealer = (st.dealer + 1) % 4;
  let hands: Card[][];
  let guard = 0;
  do {
    const deck = shuffle(createDeck(), rng);
    hands = [0, 1, 2, 3].map((i) => sortHand(deck.slice(i * 13, i * 13 + 13)));
    guard++;
  } while (st.cfg.redealOnWeakHand && hands.some(weakHand) && guard < 20);
  st.hands = hands;
  st.bids = [null, null, null, null];
  st.tricksWon = [0, 0, 0, 0];
  st.trick = [];
  st.trickDone = false;
  st.played = [];
  st.phase = 'bidding';
  st.leader = (st.dealer + 1) % 4;
  st.turn = st.leader;
  st.lastTrickWinner = null;
  return st;
}

export function placeBid(st: MatchState, seat: number, bid: number): string | null {
  if (st.phase !== 'bidding') return 'not-bidding';
  if (seat !== st.turn) return 'not-your-turn';
  if (!Number.isInteger(bid) || bid < st.cfg.minBid || bid > st.cfg.maxBid) return 'invalid-bid';
  st.bids[seat] = bid;
  if (st.bids.every((b) => b !== null)) {
    st.phase = 'playing';
    st.turn = st.leader;
  } else st.turn = (seat + 1) % 4;
  return null;
}

export function trickWinner(plays: Play[]): number {
  const lead = plays[0].card.suit;
  let best = plays[0];
  for (const p of plays.slice(1)) {
    const b = best.card, c = p.card;
    if (c.suit === b.suit) {
      if (c.rank > b.rank) best = p;
    } else if (c.suit === TRUMP && b.suit !== TRUMP) best = p;
  }
  void lead;
  return best.seat;
}

/** Ids of cards the seat may legally play now. */
export function legalCards(hand: Card[], trick: Play[], cfg: RulesConfig = DEFAULT_RULES): Card[] {
  if (trick.length === 0) return hand.slice();
  const lead = trick[0].card.suit;
  const winning = trick.find((p) => p.seat === trickWinner(trick))!.card;
  const follow = hand.filter((c) => c.suit === lead);
  if (follow.length) {
    if (!cfg.mustOverPlay) return follow;
    if (winning.suit === lead) {
      const higher = follow.filter((c) => c.rank > winning.rank);
      return higher.length ? higher : follow;
    }
    return follow; // a trump already wins; any card of lead suit is fine
  }
  const trumps = hand.filter((c) => c.suit === TRUMP);
  if (trumps.length && (cfg.mustTrump || cfg.mustOverPlay)) {
    if (winning.suit === TRUMP) {
      const higher = trumps.filter((c) => c.rank > winning.rank);
      if (higher.length) return higher;
      return cfg.mustTrump ? hand.slice() : hand.slice();
    }
    if (cfg.mustTrump) return trumps;
  }
  return hand.slice();
}

export function playCard(st: MatchState, seat: number, id: string): string | null {
  if (st.phase !== 'playing') return 'not-playing';
  if (st.trickDone) return 'trick-pending';
  if (seat !== st.turn) return 'not-your-turn';
  const card = st.hands[seat].find((c) => c.id === id);
  if (!card) return 'card-not-in-hand';
  const legal = legalCards(st.hands[seat], st.trick, st.cfg);
  if (!legal.some((c) => c.id === id)) return 'illegal-card';
  st.hands[seat] = st.hands[seat].filter((c) => c.id !== id);
  st.trick.push({ seat, card });
  st.played.push(card);
  if (st.trick.length === 4) {
    st.trickDone = true;
    st.lastTrickWinner = trickWinner(st.trick);
  } else st.turn = (seat + 1) % 4;
  return null;
}

/** Call after the UI/server has shown the finished trick. */
export function completeTrick(st: MatchState): number {
  const w = st.lastTrickWinner ?? trickWinner(st.trick);
  st.tricksWon[w] += 1;
  st.tricksTotal[w] += 1;
  st.trick = [];
  st.trickDone = false;
  st.leader = w;
  st.turn = w;
  if (st.hands.every((h) => h.length === 0)) {
    const rs = scoreRound(st.bids as number[], st.tricksWon, st.cfg);
    st.roundScores.push(rs);
    st.totals = st.totals.map((t, i) => round1(t + rs[i]));
    st.phase = st.round >= st.cfg.rounds ? 'matchEnd' : 'roundEnd';
  }
  return w;
}

export const round1 = (n: number) => Math.round(n * 10) / 10;

export function scoreRound(bids: number[], won: number[], cfg: RulesConfig = DEFAULT_RULES): number[] {
  return bids.map((bid, i) => {
    if (won[i] >= bid) return round1(bid + (won[i] - bid) * cfg.overtrickPoints);
    return -bid * cfg.failPenaltyMultiplier;
  });
}

export function nextRound(st: MatchState, rng: Rng = mathRng) {
  if (st.phase === 'roundEnd') startRound(st, rng);
  return st;
}

export function rankOf(totals: number[], seat: number) {
  return 1 + totals.filter((t) => t > totals[seat]).length;
}

/** Builds the per-seat view. Never leaks other hands (server-authoritative). */
export function makeView(
  st: MatchState,
  seat: number,
  info: { name: string; avatar: string; isBot: boolean; connected: boolean }[],
  deadline?: number,
): GameView {
  const hand = st.hands[seat];
  const legal =
    st.phase === 'playing' && st.turn === seat && !st.trickDone
      ? legalCards(hand, st.trick, st.cfg).map((c) => c.id)
      : [];
  const players: PlayerView[] = [0, 1, 2, 3].map((s) => ({
    seat: s, name: info[s].name, avatar: info[s].avatar, isBot: info[s].isBot, connected: info[s].connected,
    bid: st.bids[s], tricksWon: st.tricksWon[s], score: st.totals[s],
  }));
  return {
    phase: st.phase, round: st.round, rounds: st.cfg.rounds, mySeat: seat, hand, legal, players,
    trick: st.trick.slice(), trickDone: st.trickDone, turn: st.turn, lastTrickWinner: st.lastTrickWinner,
    roundScores: st.roundScores.map((r) => r.slice()), totals: st.totals.slice(), deadline,
  };
}
