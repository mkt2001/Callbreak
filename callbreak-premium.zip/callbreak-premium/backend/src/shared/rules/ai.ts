import type { Card, Difficulty, MatchState, Suit } from '../types';
import { legalCards, trickWinner } from './engine';
import { TRUMP } from '../constants';

const bySuit = (h: Card[], s: Suit) => h.filter((c) => c.suit === s);
const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));

/** Heuristic count of tricks a hand should take. */
export function estimateTricks(hand: Card[], expert = false): number {
  let t = 0;
  const spades = bySuit(hand, 'S');
  for (const c of spades) {
    if (c.rank === 14) t += 1;
    else if (c.rank === 13) t += spades.length >= 2 ? 0.9 : 0.4;
    else if (c.rank === 12) t += spades.length >= 3 ? 0.7 : 0.3;
    else if (c.rank === 11 && spades.length >= 4) t += 0.4;
  }
  if (spades.length > 4) t += (spades.length - 4) * 0.8; // long trump suit
  for (const s of ['H', 'D', 'C'] as Suit[]) {
    const cs = bySuit(hand, s);
    if (cs.some((c) => c.rank === 14)) t += 0.9;
    if (cs.some((c) => c.rank === 13)) t += cs.length >= 3 ? 0.6 : 0.2;
    if (cs.some((c) => c.rank === 12) && cs.length >= 4) t += 0.3;
    if (expert && cs.length === 0 && spades.length >= 2) t += 0.8; // void = ruff chances
    if (expert && cs.length === 1 && spades.length >= 3) t += 0.35; // singleton
  }
  return t;
}

export function chooseBid(hand: Card[], level: Difficulty, bidsSoFar: (number | null)[] = [], minBid = 1, maxBid = 13): number {
  let est = estimateTricks(hand, level === 'expert');
  if (level === 'beginner') est = est * 0.85 + (Math.random() * 1.6 - 0.8);
  else if (level === 'intermediate') est = est * 0.95;
  else {
    // Expert: shade bid by what table already claimed (13 tricks total).
    const claimed = bidsSoFar.reduce<number>((a, b) => a + (b ?? 0), 0);
    if (claimed >= 11) est -= 0.5;
    else if (claimed <= 6 && bidsSoFar.filter((b) => b !== null).length === 3) est += 0.4;
  }
  return clamp(Math.floor(est + 0.35), minBid, Math.min(maxBid, 8));
}

const lowest = (cs: Card[]) => cs.slice().sort((a, b) => a.rank - b.rank)[0];
const highest = (cs: Card[]) => cs.slice().sort((a, b) => b.rank - a.rank)[0];
const rnd = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

/** Card is "master" if every higher card of its suit has already been played. */
function isMaster(card: Card, played: Card[], hand: Card[]) {
  for (let r = card.rank + 1; r <= 14; r++) {
    if (!played.some((p) => p.suit === card.suit && p.rank === r) && !hand.some((h) => h.suit === card.suit && h.rank === r)) return false;
  }
  return true;
}

export function chooseCard(st: MatchState, seat: number, level: Difficulty): Card {
  const hand = st.hands[seat];
  const legal = legalCards(hand, st.trick, st.cfg);
  if (legal.length === 1) return legal[0];
  if (level === 'beginner') return rnd(legal);

  const bid = st.bids[seat] ?? 1;
  const need = bid - st.tricksWon[seat];
  const wantWin = need > 0;
  const winNow = (c: Card) => {
    const plays = [...st.trick, { seat, card: c }];
    return trickWinner(plays) === seat;
  };

  if (st.trick.length === 0) {
    // Leading
    if (wantWin) {
      const masters = legal.filter((c) => c.suit !== TRUMP && isMaster(c, st.played, hand));
      if (masters.length) return highest(masters);
      const aces = legal.filter((c) => c.rank === 14 && c.suit !== TRUMP);
      if (aces.length) return aces[0];
      if (level === 'expert') {
        const sp = legal.filter((c) => c.suit === TRUMP && isMaster(c, st.played, hand));
        if (sp.length) return highest(sp);
      }
      const nonTrump = legal.filter((c) => c.suit !== TRUMP);
      return nonTrump.length ? highest(nonTrump) : highest(legal);
    }
    // bid already made: dump low non-trump cards, avoid winning extra
    const nonTrump = legal.filter((c) => c.suit !== TRUMP);
    return lowest(nonTrump.length ? nonTrump : legal);
  }

  const winners = legal.filter(winNow);
  const lastToPlay = st.trick.length === 3;
  if (wantWin && winners.length) {
    // win as cheaply as possible
    if (level === 'expert' && !lastToPlay) {
      const m = winners.filter((c) => isMaster(c, st.played, hand));
      if (m.length) return lowest(m);
    }
    return lowest(winners);
  }
  if (!wantWin) {
    const losers = legal.filter((c) => !winNow(c));
    if (losers.length) return level === 'expert' ? highest(losers.filter((c) => c.suit !== TRUMP).length ? losers.filter((c) => c.suit !== TRUMP) : losers) : lowest(losers);
    return lowest(legal);
  }
  return lowest(legal);
}
