import type { RulesConfig, Suit } from '../types';

export const SUITS: Suit[] = ['S', 'H', 'D', 'C'];
export const SUIT_SYMBOL: Record<Suit, string> = { S: '♠', H: '♥', D: '♦', C: '♣' };
export const RANK_LABEL: Record<number, string> = { 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };
export const TRUMP: Suit = 'S';
export const TURN_SECONDS = 20;
export const BOT_NAMES = ['Aarav', 'Zoya', 'Kabir', 'Mira', 'Rohan', 'Sana', 'Vikram', 'Anaya'];
export const BOT_AVATARS = ['🦁', '🦊', '🐼', '🐯', '🦄', '🐸', '🐙', '🦉'];

export const DEFAULT_RULES: RulesConfig = {
  rounds: 5,
  minBid: 1,
  maxBid: 13,
  overtrickPoints: 0.1,
  failPenaltyMultiplier: 1,
  mustOverPlay: true,
  mustTrump: false,
  bigBidThreshold: 0,
  redealOnWeakHand: false,
  variant: 'normal',
  super8Bid: 8,
};
// Regional presets – pass to newMatch(). Scoring and legality are fully configurable.
export const RULE_PRESETS: Record<string, Partial<RulesConfig>> = {
  standard: {},
  nepal: { mustTrump: true },
  india: { mustTrump: false },
  casual: { mustOverPlay: false },
};
