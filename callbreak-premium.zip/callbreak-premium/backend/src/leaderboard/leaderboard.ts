import { Router } from 'express';
import { repo } from '../database/db';

export const leaderboardRouter = Router();
const SCOPES = ['global', 'weekly', 'monthly', 'friends', 'regional', 'tournament'];
leaderboardRouter.get('/', async (req, res) => {
  const scope = String(req.query.scope || 'global');
  if (!SCOPES.includes(scope)) return res.status(400).json({ error: 'bad-scope' });
  // friends / regional boards need a social graph + geo data; until then they fall back to the global ranking.
  const rows = await repo.leaderboard(scope === 'friends' || scope === 'regional' ? 'global' : scope, 50);
  res.json({ scope, rows });
});
