import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import { Server } from 'socket.io';
import { config } from './config';
import { apiLimiter } from './security/security';
import { authRouter } from './auth/auth';
import { leaderboardRouter } from './leaderboard/leaderboard';
import { rewardsRouter } from './rewards/rewards';
import { attachSockets } from './multiplayer/socket';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: config.corsOrigin }));
app.use(express.json({ limit: '20kb' }));
app.use(apiLimiter);
app.get('/', (_req, res) => res.json({ name: 'callbreak-premium-server', ok: true }));
app.get('/health', (_req, res) => res.json({ ok: true, uptime: process.uptime() }));
app.use('/auth', authRouter);
app.use('/leaderboard', leaderboardRouter);
app.use('/rewards', rewardsRouter);
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[error]', err.message);
  res.status(500).json({ error: 'server-error' });
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: config.corsOrigin }, pingInterval: 10_000, pingTimeout: 8_000, maxHttpBufferSize: 1e4 });
attachSockets(io);
server.listen(config.port, () => console.log(`Callbreak server listening on :${config.port}`));
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
