import type { Server, Socket } from 'socket.io';
import { randomInt, randomUUID } from 'crypto';
import { verify } from '../auth/auth';
import { repo } from '../database/db';
import { guardSocket } from '../security/security';
import { bind, cleanOptions, createRoom, getRoom, quickCancel, quickJoin, roomOfUser, unbind } from '../matchmaking/registry';

type Ack = ((r: { ok: boolean; room?: unknown; error?: string }) => void) | undefined;
const reply = (ack: Ack, r: { ok: boolean; room?: unknown; error?: string }) => { if (typeof ack === 'function') ack(r); };

export function attachSockets(io: Server) {
  io.use((socket, next) => {
    const u = verify(socket.handshake.auth?.token);
    socket.data.user = u ?? { id: 'anon-' + randomUUID(), name: `Guest${randomInt(1000, 9999)}` };
    socket.data.persist = !!u;
    next();
  });

  io.on('connection', async (socket: Socket) => {
    const guard = guardSocket(socket);
    const base = socket.data.user as { id: string; name: string };
    const persist = socket.data.persist as boolean;
    let avatar = '😎';
    if (persist) { try { avatar = (await repo.findById(base.id))?.avatar ?? avatar; } catch { /* keep default */ } }
    const me = { id: base.id, name: base.name, avatar, persist };

    // reconnection: put the player straight back in their seat
    roomOfUser(me.id)?.reconnect(me.id, socket.id);

    socket.on('sync', () => { const r = roomOfUser(me.id); if (!r) return; r.started ? r.sendState(me.id) : r.broadcastRoom(); });

    socket.on('quick:join', (p: { ranked?: boolean; variant?: string; rounds?: number } = {}) => {
      const existing = roomOfUser(me.id);
      if (existing) return existing.reconnect(me.id, socket.id);
      quickJoin(io, me, socket.id, !!p?.ranked, p);
    });
    socket.on('quick:cancel', () => quickCancel(me.id));

    socket.on('room:create', (p: unknown, ack: Ack) => {
      const existing = roomOfUser(me.id);
      if (existing?.started) return reply(ack, { ok: false, error: 'already-in-a-game' });
      if (existing) { existing.leave(me.id); unbind(me.id); }
      const room = createRoom(io, false, me.id, cleanOptions(p));
      room.join(me, socket.id); bind(me.id, room);
      reply(ack, { ok: true, room: room.info(me.id) });
    });
    socket.on('room:join', (p: { code?: string }, ack: Ack) => {
      const room = getRoom(String(p?.code ?? ''));
      if (!room) return reply(ack, { ok: false, error: 'Room not found' });
      const existing = roomOfUser(me.id);
      if (existing && existing !== room) { if (existing.started) return reply(ack, { ok: false, error: 'You are in another game' }); existing.leave(me.id); unbind(me.id); }
      if (room.join(me, socket.id) < 0) return reply(ack, { ok: false, error: room.started ? 'Game already started' : 'Room is full' });
      bind(me.id, room);
      reply(ack, { ok: true, room: room.info(me.id) });
    });
    socket.on('room:start', () => {
      const r = roomOfUser(me.id);
      if (!r || r.started) return;
      if (r.hostId !== me.id) return guard.strike('start-not-host');
      r.start();
    });
    socket.on('room:leave', () => { const r = roomOfUser(me.id); if (r) { r.leave(me.id); unbind(me.id); } });

    // game intents – every move is validated by the shared engine on the server
    socket.on('bid', (p: { value?: unknown }) => {
      const r = roomOfUser(me.id); if (!r) return;
      const v = Number(p?.value);
      const err = Number.isInteger(v) ? r.bid(me.id, v) : 'invalid-bid';
      if (err) { guard.strike(err); socket.emit('error:move', err); r.sendState(me.id); }
    });
    socket.on('play', (p: { cardId?: unknown }) => {
      const r = roomOfUser(me.id); if (!r) return;
      const err = typeof p?.cardId === 'string' ? r.play(me.id, p.cardId.slice(0, 4)) : 'invalid-card';
      if (err) { guard.strike(err); socket.emit('error:move', err); r.sendState(me.id); }
    });

    socket.on('disconnect', () => { roomOfUser(me.id)?.disconnect(socket.id); });
  });
}
