import { Router } from 'express';
import { repo, DAILY } from '../database/db';
import { requireAuth } from '../auth/auth';

export const rewardsRouter = Router();
rewardsRouter.get('/schedule', (_req, res) => res.json({ daily: DAILY }));
rewardsRouter.post('/daily', requireAuth, async (req, res) => {
  const r = await repo.claimDaily((req as any).user.id);
  if (!r) return res.status(409).json({ error: 'already-claimed' });
  res.json(r);
});
