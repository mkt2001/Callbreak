import { Router, Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { OAuth2Client } from 'google-auth-library';
import { randomInt } from 'crypto';
import { config } from '../config';
import { repo, UserRow } from '../database/db';
import { authLimiter } from '../security/security';

export interface AuthUser { id: string; name: string }
export const sign = (u: UserRow) => jwt.sign({ sub: u.id, name: u.name }, config.jwtSecret, { expiresIn: '30d' });
export function verify(token?: string | null): AuthUser | null {
  if (!token) return null;
  try { const p = jwt.verify(token, config.jwtSecret) as { sub: string; name: string }; return { id: p.sub, name: p.name }; } catch { return null; }
}
const pub = (u: UserRow) => ({ id: u.id, name: u.name, email: u.email, avatar: u.avatar, coins: u.coins, xp: u.xp });
const clean = (s: unknown, max: number) => String(s ?? '').trim().slice(0, max);
const emailOk = (e: string) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e);

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const u = verify((req.headers.authorization || '').replace('Bearer ', ''));
  if (!u) return res.status(401).json({ error: 'unauthorized' });
  (req as any).user = u; next();
}

export const authRouter = Router();
authRouter.use(authLimiter);

authRouter.post('/register', async (req, res) => {
  const name = clean(req.body?.name, 24), email = clean(req.body?.email, 254).toLowerCase(), pw = String(req.body?.password ?? '');
  if (name.length < 2 || !emailOk(email) || pw.length < 6 || pw.length > 100) return res.status(400).json({ error: 'invalid-input' });
  if (await repo.findByEmail(email)) return res.status(409).json({ error: 'email-already-registered' });
  const user = await repo.createUser({ name, email, passwordHash: await bcrypt.hash(pw, 10) });
  res.json({ token: sign(user), user: pub(user) });
});
authRouter.post('/login', async (req, res) => {
  const email = clean(req.body?.email, 254).toLowerCase(), pw = String(req.body?.password ?? '');
  const user = await repo.findByEmail(email);
  const ok = user?.password_hash ? await bcrypt.compare(pw, user.password_hash) : false;
  if (!user || !ok) return res.status(401).json({ error: 'wrong-email-or-password' });
  res.json({ token: sign(user), user: pub(user) });
});
authRouter.post('/guest', async (_req, res) => {
  const user = await repo.createUser({ name: `Guest${randomInt(1000, 9999)}` });
  res.json({ token: sign(user), user: pub(user) });
});
authRouter.post('/google', async (req, res) => {
  if (!config.googleClientId) return res.status(501).json({ error: 'google-login-not-configured' });
  try {
    const t = await new OAuth2Client(config.googleClientId).verifyIdToken({ idToken: String(req.body?.idToken ?? ''), audience: config.googleClientId });
    const p = t.getPayload(); if (!p?.sub) throw new Error('bad token');
    let user = await repo.findByGoogle(p.sub);
    if (!user) user = await repo.createUser({ name: clean(p.name || 'Player', 24), email: p.email ?? null, googleId: p.sub });
    res.json({ token: sign(user), user: pub(user) });
  } catch { res.status(401).json({ error: 'invalid-google-token' }); }
});
authRouter.get('/me', requireAuth, async (req, res) => {
  const user = await repo.findById((req as any).user.id);
  if (!user) return res.status(404).json({ error: 'not-found' });
  res.json({ user: pub(user) });
});
