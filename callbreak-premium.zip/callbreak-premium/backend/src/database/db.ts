import { Pool } from 'pg';
import { randomUUID } from 'crypto';
import { config } from '../config';

export interface UserRow { id: string; name: string; email: string | null; password_hash: string | null; google_id: string | null; avatar: string; coins: number; xp: number }
export interface BoardRow { id: string; name: string; avatar: string; level: number; points: number }
export interface Repo {
  createUser(u: { name: string; email?: string | null; passwordHash?: string | null; googleId?: string | null }): Promise<UserRow>;
  findByEmail(email: string): Promise<UserRow | null>;
  findByGoogle(gid: string): Promise<UserRow | null>;
  findById(id: string): Promise<UserRow | null>;
  recordMatch(userId: string, r: { rank: number; score: number; mode: string; tricks: number }): Promise<{ coins: number; xp: number }>;
  leaderboard(scope: string, limit: number): Promise<BoardRow[]>;
  claimDaily(userId: string): Promise<{ coins: number; day: number } | null>;
}
export const MATCH_POINTS = [25, 12, 5, 1];
export const DAILY = [100, 150, 200, 300, 400, 500, 1000];
export const levelOf = (xp: number) => { let l = 1, r = xp; while (r >= 100 + (l - 1) * 60) { r -= 100 + (l - 1) * 60; l++; } return l; };
const REWARD = { coins: [300, 150, 80, 40], xp: [120, 80, 50, 30] };
const sinceFor = (scope: string) => {
  const d = new Date();
  if (scope === 'weekly' || scope === 'tournament') { d.setDate(d.getDate() - 7); return d; }
  if (scope === 'monthly') { d.setDate(d.getDate() - 30); return d; }
  return new Date(0);
};

/* ---------------- Postgres ---------------- */
class PgRepo implements Repo {
  constructor(private pool: Pool) {}
  async createUser(u: { name: string; email?: string | null; passwordHash?: string | null; googleId?: string | null }) {
    const r = await this.pool.query('INSERT INTO users (name,email,password_hash,google_id) VALUES ($1,$2,$3,$4) RETURNING *', [u.name, u.email?.toLowerCase() ?? null, u.passwordHash ?? null, u.googleId ?? null]);
    return r.rows[0];
  }
  async findByEmail(e: string) { return (await this.pool.query('SELECT * FROM users WHERE email=$1', [e.toLowerCase()])).rows[0] ?? null; }
  async findByGoogle(g: string) { return (await this.pool.query('SELECT * FROM users WHERE google_id=$1', [g])).rows[0] ?? null; }
  async findById(id: string) { return (await this.pool.query('SELECT * FROM users WHERE id=$1', [id])).rows[0] ?? null; }
  async recordMatch(userId: string, r: { rank: number; score: number; mode: string; tricks: number }) {
    const coins = REWARD.coins[r.rank - 1], xp = REWARD.xp[r.rank - 1];
    const c = await this.pool.connect();
    try {
      await c.query('BEGIN');
      await c.query('INSERT INTO matches (user_id,rank,score,points,mode,tricks) VALUES ($1,$2,$3,$4,$5,$6)', [userId, r.rank, r.score, MATCH_POINTS[r.rank - 1], r.mode, r.tricks]);
      await c.query('UPDATE users SET coins=coins+$2, xp=xp+$3 WHERE id=$1', [userId, coins, xp]);
      await c.query('COMMIT');
    } catch (e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
    return { coins, xp };
  }
  async leaderboard(scope: string, limit: number) {
    const r = await this.pool.query(
      `SELECT u.id, u.name, u.avatar, u.xp, COALESCE(SUM(m.points),0)::int AS points
       FROM users u LEFT JOIN matches m ON m.user_id=u.id AND m.created_at >= $1
       GROUP BY u.id ORDER BY points DESC, u.xp DESC LIMIT $2`, [sinceFor(scope), limit]);
    return r.rows.map((x: any) => ({ id: x.id, name: x.name, avatar: x.avatar, level: levelOf(x.xp), points: x.points }));
  }
  async claimDaily(userId: string) {
    const u = (await this.pool.query('SELECT last_daily, daily_day FROM users WHERE id=$1', [userId])).rows[0];
    if (!u) return null;
    const today = new Date().toISOString().slice(0, 10);
    const last = u.last_daily ? new Date(u.last_daily).toISOString().slice(0, 10) : null;
    if (last === today) return null;
    const y = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const day = last === y ? u.daily_day % 7 : 0; const coins = DAILY[day];
    await this.pool.query('UPDATE users SET coins=coins+$2, last_daily=$3, daily_day=$4 WHERE id=$1', [userId, coins, today, day + 1]);
    return { coins, day: day + 1 };
  }
}

/* ---------------- In-memory (dev fallback, no DATABASE_URL) ---------------- */
class MemRepo implements Repo {
  users = new Map<string, UserRow & { last_daily?: string; daily_day?: number }>();
  matches: { userId: string; points: number; at: number }[] = [];
  async createUser(u: { name: string; email?: string | null; passwordHash?: string | null; googleId?: string | null }) {
    const row = { id: randomUUID(), name: u.name, email: u.email?.toLowerCase() ?? null, password_hash: u.passwordHash ?? null, google_id: u.googleId ?? null, avatar: '😎', coins: 1000, xp: 0 };
    this.users.set(row.id, row); return row;
  }
  async findByEmail(e: string) { return [...this.users.values()].find((x) => x.email === e.toLowerCase()) ?? null; }
  async findByGoogle(g: string) { return [...this.users.values()].find((x) => x.google_id === g) ?? null; }
  async findById(id: string) { return this.users.get(id) ?? null; }
  async recordMatch(userId: string, r: { rank: number }) {
    const u = this.users.get(userId); const coins = REWARD.coins[r.rank - 1], xp = REWARD.xp[r.rank - 1];
    if (u) { u.coins += coins; u.xp += xp; }
    this.matches.push({ userId, points: MATCH_POINTS[r.rank - 1], at: Date.now() });
    return { coins, xp };
  }
  async leaderboard(scope: string, limit: number) {
    const since = +sinceFor(scope);
    return [...this.users.values()].map((u) => ({ id: u.id, name: u.name, avatar: u.avatar, level: levelOf(u.xp), points: this.matches.filter((m) => m.userId === u.id && m.at >= since).reduce((a, m) => a + m.points, 0) }))
      .sort((a, b) => b.points - a.points).slice(0, limit);
  }
  async claimDaily(userId: string) {
    const u = this.users.get(userId); if (!u) return null;
    const today = new Date().toISOString().slice(0, 10);
    if (u.last_daily === today) return null;
    const y = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const day = u.last_daily === y ? (u.daily_day ?? 0) % 7 : 0; const coins = DAILY[day];
    u.coins += coins; u.last_daily = today; u.daily_day = day + 1;
    return { coins, day: day + 1 };
  }
}

export const pool = config.databaseUrl ? new Pool({ connectionString: config.databaseUrl, ssl: config.databaseUrl.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined }) : null;
export const repo: Repo = pool ? new PgRepo(pool) : new MemRepo();
if (!pool) console.warn('[db] DATABASE_URL not set – using in-memory storage (data is lost on restart)');
