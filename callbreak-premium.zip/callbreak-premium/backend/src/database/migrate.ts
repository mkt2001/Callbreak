import fs from 'fs';
import path from 'path';
import { pool } from './db';

async function main() {
  if (!pool) throw new Error('DATABASE_URL is required to run migrations');
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz DEFAULT now())');
  const dir = path.resolve(__dirname, '../../../database/migrations');
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
    const done = await pool.query('SELECT 1 FROM schema_migrations WHERE name=$1', [f]);
    if (done.rowCount) continue;
    console.log('applying', f);
    await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    await pool.query('INSERT INTO schema_migrations (name) VALUES ($1)', [f]);
  }
  console.log('migrations up to date');
  await pool.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
