import type { Server } from 'socket.io';
import type { MatchState, RulesConfig } from '../shared/types';
import { chooseBid, chooseCard, completeTrick, makeView, newMatch, nextRound, placeBid, playCard, rankOf } from '../shared/rules';
import { BOT_AVATARS, BOT_NAMES, RULE_PRESETS } from '../shared/constants';
import { config } from '../config';
import { secureRng } from '../security/security';
import { repo } from '../database/db';

export interface Seat {
  userId: string | null; name: string; avatar: string; isBot: boolean; socketId: string | null; connected: boolean; timeouts: number; persist: boolean;
}
export interface RoomInfo { code: string; players: { name: string; avatar: string; isHost: boolean; isBot: boolean }[]; host: boolean }

/** One server-authoritative table. Clients only ever receive their own hand (see makeView). */
export class GameRoom {
  seats: (Seat | null)[] = [null, null, null, null];
  state: MatchState | null = null;
  started = false;
  deadline?: number;
  private timer?: ReturnType<typeof setTimeout>;
  private abandon?: ReturnType<typeof setTimeout>;
  private destroyed = false;
  lobbyTimer?: ReturnType<typeof setTimeout>;

  constructor(private io: Server, public code: string, public ranked: boolean, public hostId: string, private onDestroy: (r: GameRoom) => void, public cfg: Partial<RulesConfig> = {}) {}

  seatOf(userId: string) { return this.seats.findIndex((s) => s?.userId === userId); }
  humans() { return this.seats.filter((s): s is Seat => !!s && !!s.userId); }

  join(u: { id: string; name: string; avatar: string; persist: boolean }, socketId: string): number {
    const existing = this.seatOf(u.id);
    if (existing >= 0) { this.reconnect(u.id, socketId); return existing; }
    if (this.started) return -1;
    const i = this.seats.findIndex((s) => !s);
    if (i < 0) return -1;
    this.seats[i] = { userId: u.id, name: u.name, avatar: u.avatar, isBot: false, socketId, connected: true, timeouts: 0, persist: u.persist };
    this.broadcastRoom();
    return i;
  }
  reconnect(userId: string, socketId: string) {
    const s = this.seats[this.seatOf(userId)];
    if (!s) return;
    s.socketId = socketId; s.connected = true; s.isBot = false; s.timeouts = 0;
    if (this.abandon) { clearTimeout(this.abandon); this.abandon = undefined; }
    this.started ? this.broadcastState() : this.broadcastRoom();
  }
  disconnect(socketId: string) {
    const s = this.seats.find((x) => x?.socketId === socketId);
    if (!s) return;
    s.connected = false; s.socketId = null;
    if (!this.started) return this.leave(s.userId!);
    this.broadcastState();
    if (!this.humans().some((h) => h.connected) && !this.abandon) {
      this.abandon = setTimeout(() => this.destroy(), 60_000); // everyone gone → match abandoned
    }
  }
  leave(userId: string) {
    const i = this.seatOf(userId);
    if (i < 0) return;
    if (!this.started) {
      this.seats[i] = null;
      if (this.hostId === userId) { const next = this.humans()[0]; if (next) this.hostId = next.userId!; }
      if (!this.humans().length) return this.destroy();
      return this.broadcastRoom();
    }
    // mid-game: an AI takes over the seat so the others can finish
    const s = this.seats[i]!;
    s.isBot = true; s.connected = true; s.socketId = null; s.userId = null; s.persist = false;
    if (!this.humans().length) return this.destroy();
    this.broadcastState();
  }

  info(forUser: string): RoomInfo {
    return {
      code: this.code, host: forUser === this.hostId,
      players: this.seats.filter((s): s is Seat => !!s).map((s) => ({ name: s.name, avatar: s.avatar, isHost: s.userId === this.hostId, isBot: s.isBot })),
    };
  }
  broadcastRoom() {
    for (const s of this.humans()) if (s.socketId) this.io.to(s.socketId).emit('room', this.info(s.userId!));
  }
  private infoArr() {
    return this.seats.map((s) => ({ name: s!.name, avatar: s!.avatar, isBot: s!.isBot, connected: s!.connected }));
  }
  sendState(userId: string) {
    const i = this.seatOf(userId); const s = this.seats[i];
    if (!this.state || !s?.socketId) return;
    this.io.to(s.socketId).emit('state', makeView(this.state, i, this.infoArr(), this.deadline));
  }
  broadcastState() {
    if (!this.state) return;
    this.seats.forEach((s, i) => { if (s?.socketId) this.io.to(s.socketId).emit('state', makeView(this.state!, i, this.infoArr(), this.deadline)); });
  }

  start() {
    if (this.started || this.destroyed) return;
    if (this.lobbyTimer) clearTimeout(this.lobbyTimer);
    const used = new Set(this.seats.filter(Boolean).map((s) => s!.name));
    for (let i = 0; i < 4; i++) {
      if (this.seats[i]) continue;
      let k = Math.floor(secureRng() * BOT_NAMES.length);
      while (used.has(BOT_NAMES[k])) k = (k + 1) % BOT_NAMES.length;
      used.add(BOT_NAMES[k]);
      this.seats[i] = { userId: null, name: BOT_NAMES[k], avatar: BOT_AVATARS[k], isBot: true, socketId: null, connected: true, timeouts: 0, persist: false };
    }
    this.state = newMatch({ ...RULE_PRESETS.standard, ...this.cfg }, secureRng, Math.floor(secureRng() * 4));
    this.started = true;
    for (const s of this.humans()) if (s.socketId) this.io.to(s.socketId).emit('game:start');
    this.step();
  }

  private actFor(seat: number) {
    const st = this.state!;
    if (st.phase === 'bidding' && st.turn === seat) placeBid(st, seat, chooseBid(st.hands[seat], 'intermediate', st.bids, st.cfg.minBid, st.cfg.maxBid));
    else if (st.phase === 'playing' && !st.trickDone && st.turn === seat) playCard(st, seat, chooseCard(st, seat, 'intermediate').id);
    this.step();
  }

  /** Decides what happens next and (re)arms the right timer. Always ends by broadcasting state. */
  private step() {
    if (this.destroyed || !this.state) return;
    if (this.timer) clearTimeout(this.timer);
    const st = this.state;
    this.deadline = undefined;
    if (st.phase === 'matchEnd') { this.broadcastState(); void this.finish(); return; }
    if (st.phase === 'roundEnd') {
      this.timer = setTimeout(() => { nextRound(st, secureRng); this.step(); }, 6000);
    } else if (st.phase === 'playing' && st.trickDone) {
      this.timer = setTimeout(() => { completeTrick(st); this.step(); }, 1600);
    } else {
      const seat = st.turn; const s = this.seats[seat]!;
      if (s.isBot) this.timer = setTimeout(() => this.actFor(seat), 700 + Math.floor(secureRng() * 500));
      else {
        const ms = config.turnSeconds * 1000;
        this.deadline = Date.now() + ms;
        this.timer = setTimeout(() => { // turn timer: auto-play, and hand the seat to AI after two timeouts
          s.timeouts++; if (s.timeouts >= 2) s.isBot = true;
          this.actFor(seat);
        }, ms);
      }
    }
    this.broadcastState();
  }

  bid(userId: string, value: number): string | null {
    const i = this.seatOf(userId);
    if (!this.state || i < 0) return 'not-in-game';
    const err = placeBid(this.state, i, value);
    if (err) return err;
    this.seats[i]!.timeouts = 0; this.step(); return null;
  }
  play(userId: string, cardId: string): string | null {
    const i = this.seatOf(userId);
    if (!this.state || i < 0) return 'not-in-game';
    const err = playCard(this.state, i, cardId);
    if (err) return err;
    this.seats[i]!.timeouts = 0; this.step(); return null;
  }

  private async finish() {
    const st = this.state!;
    this.seats.forEach(async (s, i) => {
      if (!s?.userId || !s.socketId) return;
      const rank = rankOf(st.totals, i);
      let coins = 0, xp = 0;
      if (s.persist) { try { ({ coins, xp } = await repo.recordMatch(s.userId, { rank, score: st.totals[i], mode: this.ranked ? 'tournament' : 'quick', tricks: st.tricksTotal[i] })); } catch (e) { console.error('[finish]', e); } }
      this.io.to(s.socketId).emit('game:end', { totals: st.totals, rank, coins, xp });
    });
    this.timer = setTimeout(() => this.destroy(), 20_000);
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    [this.timer, this.abandon, this.lobbyTimer].forEach((t) => t && clearTimeout(t));
    if (this.started && this.state?.phase !== 'matchEnd') for (const s of this.humans()) if (s.socketId) this.io.to(s.socketId).emit('game:abandoned');
    this.onDestroy(this);
  }
}
