import type { Server } from 'socket.io';
import { randomInt } from 'crypto';
import { GameRoom } from '../game-engine/room';
import { cache } from '../security/cache';
import { config } from '../config';
import type { RulesConfig } from '../shared/types';

/** Only whitelisted game options ever reach the engine. */
export function cleanOptions(o: any): Partial<RulesConfig> {
  const variant = ['normal', 'super8', 'blind'].includes(o?.variant) ? o.variant : 'normal';
  const rounds = Number(o?.rounds) === 3 ? 3 : 5;
  return { variant, rounds };
}

const rooms = new Map<string, GameRoom>();
const userRoom = new Map<string, string>();
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => { let c = ''; do { c = Array.from({ length: 6 }, () => ALPHABET[randomInt(ALPHABET.length)]).join(''); } while (rooms.has(c)); return c; };

export function createRoom(io: Server, ranked: boolean, hostId: string, cfg: Partial<RulesConfig> = {}) {
  const room = new GameRoom(io, newCode(), ranked, hostId, (r) => {
    rooms.delete(r.code);
    for (const [u, c] of userRoom) if (c === r.code) { userRoom.delete(u); void cache.del('userRoom:' + u); }
    for (const [k, v] of open) if (v === r) open.delete(k);
  }, cfg);
  rooms.set(room.code, room);
  return room;
}
export const getRoom = (code: string) => rooms.get(code.toUpperCase());
export const roomOfUser = (userId: string) => { const c = userRoom.get(userId); return c ? rooms.get(c) : undefined; };
export function bind(userId: string, room: GameRoom) { userRoom.set(userId, room.code); void cache.set('userRoom:' + userId, room.code, 7200); }
export function unbind(userId: string) { userRoom.delete(userId); void cache.del('userRoom:' + userId); }

/* ---- quick matchmaking: one open lobby per queue; AI fills after the wait time ---- */
const open = new Map<string, GameRoom>();
export function quickJoin(io: Server, user: { id: string; name: string; avatar: string; persist: boolean }, socketId: string, ranked: boolean, opts: any = {}) {
  const cfg = cleanOptions(opts);
  const key = `${ranked}|${cfg.variant}|${cfg.rounds}`;
  let room = open.get(key);
  if (!room) {
    room = createRoom(io, ranked, user.id, cfg);
    open.set(key, room);
    const r = room;
    room.lobbyTimer = setTimeout(() => { open.delete(key); r.start(); }, config.matchmakingWaitMs);
  }
  const seat = room.join(user, socketId);
  if (seat < 0) return null;
  bind(user.id, room);
  if (room.seats.every(Boolean)) { open.delete(key); room.start(); }
  return room;
}
export function quickCancel(userId: string) {
  const r = roomOfUser(userId);
  if (r && !r.started) { r.leave(userId); unbind(userId); }
}
