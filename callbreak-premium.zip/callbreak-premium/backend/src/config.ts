import 'dotenv/config';

export const config = {
  port: Number(process.env.PORT || 3000),
  env: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET || 'dev-only-secret-change-me',
  databaseUrl: process.env.DATABASE_URL || '',
  redisUrl: process.env.REDIS_URL || '',
  googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  turnSeconds: Number(process.env.TURN_SECONDS || 20),
  matchmakingWaitMs: Number(process.env.MATCHMAKING_WAIT_MS || 8000),
};
if (config.env === 'production' && config.jwtSecret === 'dev-only-secret-change-me') {
  throw new Error('Set JWT_SECRET in production');
}
