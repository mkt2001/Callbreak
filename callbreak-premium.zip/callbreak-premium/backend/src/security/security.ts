import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import type { Socket } from 'socket.io';
import type { Rng } from '../shared/rules';

/** Cryptographically secure RNG for shuffling (never Math.random on the server). */
export const secureRng: Rng = () => crypto.randomInt(0, 2 ** 30) / 2 ** 30;

export const apiLimiter = rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false });
export const authLimiter = rateLimit({ windowMs: 60_000, limit: 15, standardHeaders: true, legacyHeaders: false, message: { error: 'too-many-attempts' } });

/** Token-bucket per socket + strike counter for invalid moves (duplicate/illegal/out-of-turn). */
export function guardSocket(socket: Socket) {
  let tokens = 20; let last = Date.now(); let strikes = 0;
  socket.use((_packet, next) => {
    const now = Date.now();
    tokens = Math.min(20, tokens + ((now - last) / 1000) * 10); last = now;
    if (tokens < 1) { strikes++; if (strikes > 30) { console.warn('[security] flooding, disconnect', socket.id); socket.disconnect(true); } return next(new Error('rate-limited')); }
    tokens -= 1; next();
  });
  return {
    strike(reason: string) {
      strikes++;
      if (strikes % 5 === 0) console.warn(`[security] suspicious activity (${reason}) socket=${socket.id} strikes=${strikes}`);
      if (strikes >= 25) socket.disconnect(true);
    },
  };
}
