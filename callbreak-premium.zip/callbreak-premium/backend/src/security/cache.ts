import Redis from 'ioredis';
import { config } from '../config';

/** Thin cache: Redis when REDIS_URL is set (multi-instance reconnect lookups), in-memory otherwise. */
const mem = new Map<string, string>();
const redis = config.redisUrl ? new Redis(config.redisUrl, { maxRetriesPerRequest: 2, lazyConnect: false }) : null;
if (redis) redis.on('error', (e) => console.warn('[redis]', e.message));

export const cache = {
  async set(k: string, v: string, ttlSec = 3600) { if (redis) await redis.set(k, v, 'EX', ttlSec).catch(() => {}); else mem.set(k, v); },
  async get(k: string) { if (redis) return redis.get(k).catch(() => null); return mem.get(k) ?? null; },
  async del(k: string) { if (redis) await redis.del(k).catch(() => {}); else mem.delete(k); },
};
