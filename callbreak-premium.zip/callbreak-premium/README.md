# Callbreak Premium – landscape card game (Android + Web)

Expo / React Native / TypeScript app + Node.js / Socket.IO / PostgreSQL / Redis backend.
The shared Callbreak rules engine (`shared/rules`) is used by the offline game, the AI and the server.

## Quick start: GitHub → APK (Hindi/English)
1. GitHub par naya repository banao (Public ya Private).
2. **Is zip file ko repo ke root me upload karo** (Add file → Upload files) *aur* `.github/workflows/build-apk.yml` bhi upload karo
   (zip ke andar bhi hai; agar zip extract karke upload kar rahe ho to apne aap aa jayegi).
3. Commit karo. **Actions** tab me "Build Android APK and publish Release" chalega (~10–20 min).
4. Khatam hone par **Releases** me `Callbreak-Premium.apk` milegi. Phone me download → install.
   Workflow zip ko khud unzip karta hai; kuch manually extract karne ki zarurat nahi.

The APK is signed with the default debug key (fine for sharing/testing). For Play Store create your own keystore.

## Run locally
```bash
node scripts/sync-shared.js        # copies /shared into mobile and backend
cd mobile && npm install && npx expo start      # press "a" for Android, "w" for web
```
Offline play (AI), rewards, store, missions and profile work without any server.

## Backend (online multiplayer, accounts, leaderboards)
```bash
cd backend && cp ../.env.example .env && npm install
npm run migrate      # needs DATABASE_URL (PostgreSQL)
npm run dev          # http://localhost:3000   (without DATABASE_URL it uses in-memory storage)
npm test             # runs the Callbreak engine tests
```
Deploy with `backend/Dockerfile` (Render, Railway, Fly.io, a VPS …). Then in the app: **Settings → Server URL**
(or set `EXPO_PUBLIC_SERVER_URL` at build time). Use `https://`. Run a single instance, or use sticky sessions
(rooms are held in server memory; Redis stores the user→room mapping).

### Google login
Backend verifies Google ID tokens (`POST /auth/google`, set `GOOGLE_CLIENT_ID`). The app button is a placeholder until you add
`expo-auth-session` with your own OAuth client IDs.

## Features
- **Landscape only**: `app.json` (`orientation: landscape`, Android `screenOrientation`), `expo-screen-orientation` lock at startup and on every rotation event, native manifest after prebuild. Web shows a rotate hint when the window is narrow.
- 20 screens: splash, onboarding, login, register, home, game modes, matchmaking, private room, join room, bidding (on the table), table, round results, match results, leaderboard, profile, rewards & missions, store, settings, history, help (+ tournaments).
- Rules: 4 players, 52 cards, 13 each, 5 rounds, bids 1–13, spades trump, follow suit, must beat if able, configurable (`shared/constants` `RULE_PRESETS`, `RulesConfig`: overtrick points, fail penalty, forced trump, redeal…).
- AI: beginner / intermediate / expert (card counting, master-card tracking, void/ruff estimates, bid shading by table total).
- Online: quick match (AI fills empty seats), private rooms with code + share link, host controls, 20 s turn timer with auto-play, AI takeover after two timeouts, reconnection back into your seat, abandonment cleanup.
- Security: server-authoritative engine, `crypto.randomInt` shuffling, per-seat views (opponent hands never sent), move validation, rate limits (REST + sockets), strike counter for suspicious activity, JWT auth, bcrypt.
- Progression: XP/levels, daily login rewards, daily/weekly missions, win-streak bonuses, achievements, tournaments (daily/weekly points).
- Premium customization (cosmetic only, **virtual coins only – no real money, no cash-out**): card faces, backs, table themes, animated avatars, frames, badges, sound packs, VIP perks (ad-free, premium tournaments, advanced stats).

## Layout
```
mobile/   Expo app (src/components, screens, navigation, game, animations, hooks, services, store, theme)
backend/  Node server (auth, matchmaking, game-engine, multiplayer, database, leaderboard, rewards, security)
shared/   types, constants, rules (engine + AI + tests)
database/ schema.sql, migrations/
scripts/  sync-shared.js
.github/workflows/build-apk.yml
```
